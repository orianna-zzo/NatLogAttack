import argparse
from tqdm import tqdm
import os
os.environ["CUDA_VISIBLE_DEVICES"]='3'
import numpy as np
import pandas as pd
from config.data_config import *

import torch
import transformers
from transformers import (
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    # BertConfig, BertForSequenceClassification, BertTokenizer,
    # RobertaConfig, RobertaForSequenceClassification, RobertaTokenizer,
)
from transformers import InputExample, InputFeatures
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset


def examples2fea(examples, tokenizer, label_list,
                 max_length=512,
                 # pad_on_left=False,
                 # pad_token=0,
                 # pad_token_segment_id=0,
                 mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """

    pad_token = tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0]
    pad_token_segment_id = 0
    pad_on_left = False

    # logger.info("Using label list %s" % (label_list))

    features = []
    for (ex_index, example) in enumerate(examples):
        # if ex_index % 10000 == 0:
            # logger.info("Converting example %d" % (ex_index))


        inputs = tokenizer.encode_plus(
            example['text_a'],
            example['text_b'],
            add_special_tokens=True,
            # return_token_type_ids=True,
            max_length=max_length,
        )

        input_ids = inputs["input_ids"]
        if 'token_type_ids' in inputs.keys():
            token_type_ids = inputs["token_type_ids"]
        else:
            len_a = len(tokenizer.encode(example['text_a']))
            token_type_ids = [0] * len_a + [1] * (len(input_ids) - len_a)
        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_mask

            token_type_ids = ([pad_token_segment_id] * padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)

            token_type_ids = token_type_ids + ([pad_token_segment_id] * padding_length)

        assert len(input_ids) == max_length, "Error with input length {} vs {}".format(len(input_ids), max_length)
        assert len(attention_mask) == max_length, "Error with input length {} vs {}".format(len(attention_mask), max_length)
        assert len(token_type_ids) == max_length, "Error with input length {} vs {}".format(len(token_type_ids), max_length)

        label = example['label']

        # if ex_index < 3:
        #     logger.info("*** Example ***")
        #     logger.info("text: %s, %s" % (example['text_a'], example['text_b']))
        #     logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
        #     logger.info("attention_mask: %s" % " ".join([str(x) for x in attention_mask]))
        #     logger.info("token_type_ids: %s" % " ".join([str(x) for x in token_type_ids]))
        #     if label is not None:
        #         logger.info("label: %s" % (label))

        features.append(
            InputFeatures(input_ids=input_ids,
                          attention_mask=attention_mask,
                          token_type_ids=token_type_ids,
                          label=label))

    return features


def text2examples(texts):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """

    examples = []
    ex_sample = texts[0][0]
    if type(ex_sample) == str:
        no_b = True
    else:
        no_b = False
    for (idx, text) in enumerate(texts):
        if no_b:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0], "text_b": '', "label": text[-1]}
            )
        else:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0][0], "text_b": text[0][1], "label": text[-1]}
            )
    return examples



def predict_from_texts(texts, model, tokenizer, args):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """
    examples = text2examples(texts)
    features = examples2fea(examples, tokenizer, args.label_list, args.max_seq_length)

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)

    all_labels = torch.tensor([f.label for f in features], dtype=torch.long)

    dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)

    # evaluate
    eval_sampler = SequentialSampler(dataset)
    eval_dataloader = DataLoader(dataset, sampler=eval_sampler, batch_size=16)

    # eval_loss = 0.0
    # nb_eval_steps = 0
    pred_logits = None
    gt_label_ids = None
    for batch in tqdm(eval_dataloader, desc="Evaluating"):
        model.eval()
        batch = tuple(t.to(args.device) for t in batch)

        with torch.no_grad():
            inputs = {"input_ids": batch[0],
                      "attention_mask": batch[1],
                      'token_type_ids': batch[2] if args.model_type in ['bert'] else None,
                      "labels": batch[3]}

            outputs = model(**inputs)
            # tmp_eval_loss, logits = outputs[:2]
            logits = outputs[1]

            # eval_loss += tmp_eval_loss.mean().item()
        # nb_eval_steps += 1
        if pred_logits is None:
            pred_logits = logits.detach().cpu().numpy()
            gt_label_ids = inputs["labels"].detach().cpu().numpy()
        else:
            pred_logits = np.append(pred_logits, logits.detach().cpu().numpy(), axis=0)
            gt_label_ids = np.append(gt_label_ids, inputs["labels"].detach().cpu().numpy(), axis=0)

    # eval_loss = eval_loss / nb_eval_steps

    preds = np.argmax(pred_logits, axis=1)
    # pred_probs = torch.softmax(torch.tensor(pred_logits), 1).numpy()
    #
    # return pred_logits, pred_probs, preds, gt_label_ids
    return pred_logits, preds, gt_label_ids

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # attack_model = "bertattack"  #"clare", "textfooler", "ga", "pso", "pwws"
    # victim_model = "bert"  # "roberta"
    # dataset = "snli" #med"
    parser.add_argument("--attack_model", type=str, default="natlog10")   #"bertattack", "clare", "textfooler", "ga", "pso", "pwws", "natlog"
    # parser.add_argument("--victim_model_name", type=str, default="roberta-base_snli")
    parser.add_argument("--model_type", type=str, default="roberta") # "bert", "roberta"
    parser.add_argument("--dataset", type=str, default="med")    #"snli", "med"
    args = parser.parse_args()
    if args.dataset == 'snli':
        args.victim_model_name = args.model_type+'-base_snli'
    elif args.dataset == 'med':
        args.victim_model_name = args.model_type+'-base_snlimix'
    print("Attack Model: {}".format(args.attack_model))
    print("Victim Model Name: {}".format(args.victim_model_name))
    print("Model Type: {}".format(args.model_type))
    print("Dataset: {}".format(args.dataset))


    args.device = "cuda"

    # Get examples
    dir_name = os.path.join(HUMAN_DIR, args.attack_model, "Turk")
    if args.model_type == "roberta":
        run_name = '_'.join(["bert", args.attack_model, args.dataset])
    elif args.model_type == "bert":
        run_name = '_'.join(["roberta", args.attack_model, args.dataset])
    data_path = os.path.join(dir_name, run_name+'_ppl_error.csv')
    output_file_path = os.path.join(dir_name, run_name+'_ppl_error_trans.csv')

    data_df = pd.read_csv(data_path)
    #   change name
    data_df = data_df.rename(columns={
        "ori_label": "original_output", "query_num": "num_queries", "new_label": "ground_truth_output"
    })
    data_df['result_type'] = data_df['success'].apply(lambda x: "Successful" if x == 1 else "Failed")
    input_text = data_df.apply(lambda x: ((x.s1, x.s2), x.ground_truth_output), axis=1).to_list()

    # Get Victim Model
    # NLI_3_LABEL = {'entailment': 0, 'neutral': 1, 'contradiction': 2}
    # num_labels = len(NLI_3_LABEL)
    args.label_list = ['entailment', 'neutral', 'contradiction']
    num_labels = len(args.label_list)
    args.max_seq_length = 128
    model_path = os.path.join(VICTIM_MODEL_DIR, args.victim_model_name)
    config = AutoConfig.from_pretrained(model_path, num_labels=num_labels)
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_path,
        from_tf=bool(".ckpt" in model_path),
        config=config
    ).to(args.device)

    # predict
    pred_logits, preds, _ = predict_from_texts(input_text, model, tokenizer, args)

    data_df['trans2other'] = preds

    data_df.to_csv(output_file_path)

