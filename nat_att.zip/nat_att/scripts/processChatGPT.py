import os
import dill as pickle
import numpy as np
import pandas as pd
import re

from config import *

data = "med"
group_n = 50
file_name = 'out_med_sample_up_50_tb_04-05-04-27.pkl'
output_dir = os.path.join(DATA_BASE_DIR, 'openai', data)

with open(os.path.join(output_dir, file_name),'rb') as f:
    [response, answers] = pickle.load(f)

output_ans = []
output_idx = []
for idx, i in enumerate(answers):
    # if ":" not in i and "." not in i:
    #     l = i.split(',')
    #     if len(l) != group_n:
    #         print("idx: {} num: {}\n{}".format(idx, len(l), l))
    #     output_ans.extend(l)
    # else:
    #     l = i.split('\n')
    #     if len(l) != group_n:
    #         print("idx: {} num: {}\n{}".format(idx, len(l), l))
    #     for j in l:
    #         if "Neutral" in j:
    #             output_ans.append('Neutral')
    #         elif "Entailment" in j:
    #             output_ans.append('Entailment')
    l = i.split('\n')
    if len(l) == 1:
        l = i.split(',')
    if len(l) != group_n:
        print("idx: {} num: {}\n{}".format(idx, len(l), l))
    for j in l:
        if "Neutral" in j:
            output_ans.append('Neutral')
        elif "Entailment" in j:
            output_ans.append('Entailment')
        output_idx.append(re.search(r"\d+", j)[0])
output_pd = pd.DataFrame([output_idx,output_ans]).T
output_pd.to_csv(os.path.join(output_dir, file_name[:-4] + '_res.csv'))

print(1)