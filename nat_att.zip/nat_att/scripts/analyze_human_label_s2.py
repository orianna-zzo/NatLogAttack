import argparse
import os
import numpy as np
import pandas as pd
from config.data_config import *
from collections import Counter

if __name__ == '__main__':
    version = "v13s2"
    victim_model = "roberta"
    attack_model = "natlog12s2"
    dataset = "mnli"
    s2_type = "c2e" # e2c e2n, c2e
    dir = "all"

    # print("========= Read File =========")
    dir_name = os.path.join(HUMAN_DIR, "human_evaluation_original_files", version + '_processed')
    run_name = "_".join([victim_model, attack_model, dataset])
    # dir_name = os.path.join(HUMAN_DIR, attack_model)
    # run_name = "_".join([victim_model, dataset, attack_model])
    data_df = pd.read_csv(os.path.join(dir_name, run_name + '.csv'))

    data_df['result_type'] = data_df['success'].apply(lambda x: "Successful" if x == 1 else "Failed")
    # data_df['num_queries'] = data_df['Input.query_num']

    if dataset == "med" and dir in ["up", "down"]:
        data_df = data_df[data_df.dir == dir]

    if dataset == "med":
        data_df['freq_label'] = data_df['freq_label2']

    data_df = data_df[data_df.s2type == s2_type]
    data_df['freq_label'] = data_df['freq_label'].map({'entailment': 0, 'neutral': 1, 'contradiction': 2, 'None': -1}).apply(int)
    data_df['ori_label'] = data_df['label'].apply(int)
    data_df['predict'] = data_df['predict'].apply(int)
    data_df['num_queries'] = data_df['num_queries'].apply(int)
    # data_500_df = data_df[(data_df.num_queries <= 500) & (data_df.result_type == 'Successful')]

    data_df['label'] = -1
    if dataset == "med":
        data_df.loc[data_df.s2type == "e2c", 'label'] = 1
    else:
        data_df.loc[data_df.s2type == "e2c", 'label'] = 2
    data_df.loc[data_df.s2type == "e2n", 'label'] = 1
    data_df.loc[data_df.s2type == "c2e", 'label'] = 0

    data_500_df = data_df[(data_df.num_queries <= 500)]
    if dataset == "med":

        data_500_sucess_df = pd.concat([data_500_df[(data_500_df.label == 0) & (data_500_df.predict > 0)],
                                       data_500_df[(data_500_df.label > 0) & (data_500_df.predict == 0)]
                                 ])
    else:
        data_500_sucess_df = data_500_df[data_500_df.predict != data_500_df.freq_label]



    print("========= All =========")
    D_all_len = len(data_df)
    E_freq_len = len(data_df[data_df.freq_label >= 0])
    F_label_right_len = len(data_df[data_df.freq_label == data_df.label])
    # G_label_right_ratio = F_label_right_len / D_all_len
    H_500_label_right_len = len(data_df[data_df.freq_label == data_df.label])
    # I_500_label_right_ratio = H_500_label_right_len / D_all_len
    J_500_attack_right_len = len(data_500_df[(data_500_df.freq_label == data_500_df.label)])
    # K_500_attack_ratio = J_500_attack_right_len / D_all_len
    L_500_model_right_len = len(data_500_sucess_df[data_500_sucess_df.freq_label == data_500_sucess_df.predict])
    # M_500_model_right_ratio = L_500_model_right_len / D_all_len
    print("D_all_len: ", D_all_len)
    print("E_freq_len: ", E_freq_len)
    print("F_label_right_len: ", F_label_right_len)
    # print("G_label_right_ratio: ", G_label_right_ratio)
    print("H_500_label_right_len: ", H_500_label_right_len)
    # print("I_500_label_right_ratio: ", I_500_label_right_ratio)
    print("J_500_attack_right_len: ", J_500_attack_right_len)
    # print("K_500_attack_ratio: ", K_500_attack_ratio)
    print("L_500_model_right_len: ", L_500_model_right_len)
    # print("M_500_model_right_ratio: ", M_500_model_right_ratio)
    print("")

    # print("========= E =========")
    # ent_df = data_df[data_df.label == 0]
    #
    # ent_500_df = ent_df[(ent_df.num_queries <= 500) & (ent_df.result_type == 'Successful')]
    # O_ent_len = len(ent_df)
    # P_freq_len = len(ent_df[ent_df.freq_label >= 0])
    # Q_label_right_len = len(ent_df[ent_df.freq_label == ent_df.label])
    # # R_label_right_ratio = Q_label_right_len / O_ent_len
    # S_500_label_right_len = len(ent_500_df[ent_500_df.freq_label == ent_500_df.label])
    # # T_500_label_right_ratio = S_500_label_right_len / O_ent_len
    # U_500_attack_right_len = len(ent_500_df[(ent_500_df.freq_label == ent_500_df.label) & (ent_500_df.predict != ent_500_df.freq_label)])
    # # V_500_attack_ratio = U_500_attack_right_len / O_ent_len
    # W_500_model_right_len = len(ent_500_df[ent_500_df.freq_label == ent_500_df.predict])
    # # X_model_right_ratio = W_500_model_right_len / O_ent_len
    # print("O_ent_len: ", O_ent_len)
    # print("P_freq_len: ", P_freq_len)
    # print("Q_label_right_len: ", Q_label_right_len)
    # # print("R_label_right_ratio: ", R_label_right_ratio)
    # print("S_500_label_right_len: ", S_500_label_right_len)
    # # print("T_500_label_right_ratio: ", T_500_label_right_ratio)
    # print("U_500_attack_right_len: ", U_500_attack_right_len)
    # # print("V_500_attack_ratio: ", V_500_attack_ratio)
    # print("W_500_model_right_len: ", W_500_model_right_len)
    # # print("X_model_right_ratio: ", X_model_right_ratio)
    # print("")
    #
    # print("========= N =========")
    # neu_df = data_df[data_df.label == 1]
    # if dataset == "med":
    #     neu_500_df = neu_df[(neu_df.num_queries <= 500)]
    #     neu_500_df = pd.concat([neu_500_df[(neu_500_df.label == 0) & (neu_500_df.predict > 0)],
    #                             neu_500_df[(neu_500_df.label > 0) & (neu_500_df.predict == 0)]])
    # else:
    #     neu_500_df = neu_df[(neu_df.num_queries <= 500) & (neu_df.result_type == 'Successful')]
    # Z_neu_len = len(neu_df)
    # AA_freq_len = len(neu_df[neu_df.freq_label >= 0])
    # AB_label_right_len = len(neu_df[neu_df.freq_label == neu_df.label])
    # # AC_label_right_ratio = AB_label_right_len / Z_neu_len
    # AD_500_label_right_len = len(neu_500_df[neu_500_df.freq_label == neu_500_df.label])
    # # AE_500_label_right_ratio = AD_500_label_right_len / Z_neu_len
    # AF_500_attack_right_len = len(neu_500_df[(neu_500_df.freq_label == neu_500_df.label) & (neu_500_df.predict != neu_500_df.freq_label)])
    # # AG_500_attack_ratio = AF_500_attack_right_len / Z_neu_len
    # AH_500_model_right_len = len(neu_500_df[neu_500_df.freq_label == neu_500_df.predict])
    # # AI_model_right_ratio = AH_500_model_right_len / Z_neu_len
    # print("Z_neu_len: ", Z_neu_len)
    # print("AA_freq_len: ", AA_freq_len)
    # print("AB_label_right_len: ", AB_label_right_len)
    # # print("AC_label_right_ratio: ", AC_label_right_ratio)
    # print("AD_500_label_right_len: ", AD_500_label_right_len)
    # # print("AE_500_label_right_ratio: ", AE_500_label_right_ratio)
    # print("AF_500_attack_right_len: ", AF_500_attack_right_len)
    # # print("AG_500_attack_ratio: ", AG_500_attack_ratio)
    # print("AH_500_model_right_len: ", AH_500_model_right_len)
    # # print("AI_model_right_ratio: ", AI_model_right_ratio)
    # print("")
    #
    # if dataset != 'med':
    #     print("========= C =========")
    #     con_df = data_df[data_df.label == 2]
    #     con_500_df = con_df[(con_df.num_queries <= 500) & (con_df.result_type == 'Successful')]
    #     AK_con_len = len(con_df)
    #     AL_freq_len = len(con_df[con_df.freq_label >= 0])
    #     AM_label_right_len = len(con_df[con_df.freq_label == con_df.label])
    #     # AN_label_right_ratio = AM_label_right_len / AK_con_len
    #     AO_500_label_right_len = len(con_500_df[con_500_df.freq_label == con_500_df.label])
    #     # AP_500_label_right_ratio = AO_500_label_right_len / AK_con_len
    #     AQ_500_attack_right_len = len(con_500_df[(con_500_df.freq_label == con_500_df.label) & (con_500_df.predict != con_500_df.freq_label)])
    #     # AR_500_attack_ratio = AQ_500_attack_right_len / AK_con_len
    #     AS_500_model_right_len = len(con_500_df[con_500_df.freq_label == con_500_df.predict])
    #     # AT_model_right_ratio = AS_500_model_right_len / AK_con_len
    #     print("AK_con_len: ", AK_con_len)
    #     print("AL_freq_len: ", AL_freq_len)
    #     print("AM_label_right_len: ", AM_label_right_len)
    #     # print("AN_label_right_ratio: ", AN_label_right_ratio)
    #     print("AO_500_label_right_len: ", AO_500_label_right_len)
    #     # print("AP_500_label_right_ratio: ", AP_500_label_right_ratio)
    #     print("AQ_500_attack_right_len: ", AQ_500_attack_right_len)
    #     # print("AR_500_attack_ratio: ", AR_500_attack_ratio)
    #     print("AS_500_model_right_len: ", AS_500_model_right_len)
    #     # print("AT_model_right_ratio: ", AT_model_right_ratio)
    #     print("")

    print("done!")










