import os
os.environ["CUDA_VISIBLE_DEVICES"]='1'

import torch
import numpy as np
import pandas as pd
import argparse
from tqdm import tqdm
tqdm.pandas()
from transformers import GPT2LMHeadModel, GPT2TokenizerFast
import language_tool_python
from config.data_config import HUMAN_DIR


def get_error_num(language_tool, text):
    return len(lang_tool.check(text))

def get_ppl(model_args, text):
    encodings = model_args.tokenizer('\n\n'.join(text), return_tensors='pt')
    # encodings = model_args.tokenizer(text, return_tensors='pt')
    nlls = []
    for i in tqdm(range(0, encodings.input_ids.size(1), model_args.stride)):
        begin_loc = max(i + model_args.stride - model_args.max_length, 0)
        end_loc = min(i + model_args.stride, encodings.input_ids.size(1))
        trg_len = end_loc - i    # may be different from stride on last loop
        input_ids = encodings.input_ids[:,begin_loc:end_loc].to(model_args.device)
        target_ids = input_ids.clone()
        target_ids[:,:-trg_len] = -100

        with torch.no_grad():
            outputs = model_args.model(input_ids, labels=target_ids)
            neg_log_likelihood = outputs[0] * trg_len

        nlls.append(neg_log_likelihood)

    ppl = torch.exp(torch.stack(nlls).sum() / end_loc)
    return round(ppl.item(),4)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # attack_model = "bertattack"  #"clare", "textfooler", "ga", "pso", "pwws"
    # victim_model = "bert"  # "roberta"
    # dataset = "snli" #med"
    parser.add_argument("--attack_model", type=str, default="natlog12s2")   #"bertattack", "clare", "textfooler", "pso", "pwws", "natlog12"
    parser.add_argument("--victim_model", type=str, default="bert") # "bert", "roberta"
    parser.add_argument("--dataset", type=str, default="sick")    #"snli", "med"
    args = parser.parse_args()
    dir_name = os.path.join(HUMAN_DIR, 'natlog12s2')
    run_name = '_'.join([args.victim_model, args.dataset, args.attack_model])
    file_path = os.path.join(dir_name, run_name+'.csv')

    # dir_name = os.path.join(HUMAN_DIR, 'newdataset_final', args.dataset)
    # run_name = '_'.join([args.victim_model, args.dataset, args.attack_model])
    # file_path = os.path.join(dir_name, run_name+'.csv')

    # run_name = '_'.join(["same_label", args.victim_model, args.dataset])
    # file_path = os.path.join(dir_name, 'same_label_roberta_sick_chosen12_success.csv')

    run_name = '_'.join([args.victim_model, args.dataset, args.attack_model])
    file_path = os.path.join(dir_name, run_name+'.csv')



    output_file_path = os.path.join(dir_name, run_name+'_ppl_error.csv')
    print("Attack Model: {}".format(args.attack_model))
    print("Victim Model: {}".format(args.victim_model))
    print("Dataset: {}".format(args.dataset))

    # GPT-2
    print("========= Load Model =========")
    model_args = argparse.Namespace()
    model_args.device = 'cuda'
    model_id = 'gpt2'
    model_args.model = GPT2LMHeadModel.from_pretrained(model_id).to(model_args.device)
    model_args.tokenizer = GPT2TokenizerFast.from_pretrained(model_id)
    model_args.max_length = model_args.model.config.n_positions
    model_args.stride = 512

    # language-tool
    lang_tool = language_tool_python.LanguageTool('en-US')

    print("========= Read CSV =========")
    data_df = pd.read_csv(file_path)

    # data_df['s1'] = data_df["new_p"]
    # data_df['s2'] = data_df["new_h"]

    data_df['s1'].fillna(data_df['ori_p'], inplace=True)
    data_df['s2'].fillna(data_df['ori_h'], inplace=True)


    # compute ppl
    print("========= Compute PPL =========")
    data_df['new_p_ppl'] = data_df['s1'].progress_apply(lambda x: get_ppl(model_args, x))
    data_df['new_h_ppl'] = data_df['s2'].progress_apply(lambda x: get_ppl(model_args, x))
    data_df['ppl_sum'] = data_df['new_p_ppl'] + data_df['new_h_ppl']

    # # compute grammer
    # print("========= Compute Grammer =========")
    # data_df['new_p_error'] = data_df['s1'].progress_apply(lambda x: get_error_num(lang_tool, x))
    # data_df['new_h_error'] = data_df['s2'].progress_apply(lambda x: get_error_num(lang_tool, x))
    # data_df['p_error'] = data_df['ori_p'].progress_apply(lambda x: get_error_num(lang_tool, x))
    # data_df['h_error'] = data_df['ori_h'].progress_apply(lambda x: get_error_num(lang_tool, x))
    # data_df['new_error'] = data_df['new_p_error']+data_df['new_h_error']
    # data_df['ori_error'] = data_df['p_error']+data_df['h_error']
    # # data_df['error_rate'] = (data_df['new_error']-data_df['ori_error']).apply(float)/data_df['ori_error']
    print("avg: ", data_df['ppl_sum'].mean())

    print("========= Write CSV =========")
    data_df.to_csv(output_file_path)






