import os
os.environ["CUDA_VISIBLE_DEVICES"]='3'

import torch
import argparse
import logging
import numpy as np
from tqdm import tqdm

from config import DATASET_DIR, VICTIM_MODEL_DIR, SNLI_DIR

from utils.data_utils import SnliReader
from utils.text.parse import find_specific_subsentence

from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset
import transformers
from transformers import InputExample, InputFeatures
from transformers import (
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    # BertConfig, BertForSequenceClassification, BertTokenizer,
    # RobertaConfig, RobertaForSequenceClassification, RobertaTokenizer,
)

logger = logging.getLogger(__name__)
logger.setLevel("INFO")

def config_param():
    parser = argparse.ArgumentParser()
    # Required parameters

    parser.add_argument(
        "--data_dir",
        default=DATASET_DIR,
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )

    parser.add_argument(
        "--victim_model_name",
        default='roberta-base_snli', # 'bert-base_snlimix', 'roberta-base_snlimix', 'bert-base_snli', 'roberta-base_snli'
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )
    parser.add_argument(
        "--model_type",
        default='roberta', #roberta, bert
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )
    parser.add_argument(
        "--max_seq_length",
        default=128,
        type=int,
        help="The maximum total input sequence length after tokenization. Sequences longer "
             "than this will be truncated, sequences shorter will be padded.",
    )

    parser.add_argument("--no_cuda", action="store_true", help="Avoid using CUDA when available")

    return parser.parse_args()

def examples2fea(examples, tokenizer, label_list,
                 max_length=512,
                 # pad_on_left=False,
                 # pad_token=0,
                 # pad_token_segment_id=0,
                 mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """

    pad_token = tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0]
    pad_token_segment_id = 0
    pad_on_left = False

    logger.info("Using label list %s" % (label_list))

    features = []
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Converting example %d" % (ex_index))


        inputs = tokenizer.encode_plus(
            example['text_a'],
            example['text_b'],
            add_special_tokens=True,
            # return_token_type_ids=True,
            max_length=max_length,
        )

        input_ids = inputs["input_ids"]
        if 'token_type_ids' in inputs.keys():
            token_type_ids = inputs["token_type_ids"]
        else:
            len_a = len(tokenizer.encode(example['text_a']))
            token_type_ids = [0] * len_a + [1] * (len(input_ids) - len_a)
        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_mask

            token_type_ids = ([pad_token_segment_id] * padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)

            token_type_ids = token_type_ids + ([pad_token_segment_id] * padding_length)

        assert len(input_ids) == max_length, "Error with input length {} vs {}".format(len(input_ids), max_length)
        assert len(attention_mask) == max_length, "Error with input length {} vs {}".format(len(attention_mask), max_length)
        assert len(token_type_ids) == max_length, "Error with input length {} vs {}".format(len(token_type_ids), max_length)

        label = example['label']

        if ex_index < 3:
            logger.info("*** Example ***")
            logger.info("text: %s, %s" % (example['text_a'], example['text_b']))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_mask: %s" % " ".join([str(x) for x in attention_mask]))
            logger.info("token_type_ids: %s" % " ".join([str(x) for x in token_type_ids]))
            if label is not None:
                logger.info("label: %s" % (label))

        features.append(
            InputFeatures(input_ids=input_ids,
                          attention_mask=attention_mask,
                          token_type_ids=token_type_ids,
                          label=label))

    return features


def text2examples(texts):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """

    examples = []
    ex_sample = texts[0][0]
    if type(ex_sample) == str:
        no_b = True
    else:
        no_b = False
    for (idx, text) in enumerate(texts):
        if no_b:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0], "text_b": '', "label": text[-1]}
            )
        else:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0][0], "text_b": text[0][1], "label": text[-1]}
            )
    return examples

def predict_from_texts(texts, model, tokenizer, args):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """
    examples = text2examples(texts)
    features = examples2fea(examples, tokenizer, args.label_list, args.max_seq_length)

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)

    all_labels = torch.tensor([f.label for f in features], dtype=torch.long)

    dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)

    # evaluate
    eval_sampler = SequentialSampler(dataset)
    eval_dataloader = DataLoader(dataset, sampler=eval_sampler, batch_size=16)

    # eval_loss = 0.0
    # nb_eval_steps = 0
    pred_logits = None
    gt_label_ids = None
    for batch in tqdm(eval_dataloader, desc="Evaluating"):
        model.eval()
        batch = tuple(t.to(args.device) for t in batch)

        with torch.no_grad():
            inputs = {"input_ids": batch[0],
                      "attention_mask": batch[1],
                      'token_type_ids': batch[2] if args.model_type in ['bert'] else None,
                      "labels": batch[3]}

            outputs = model(**inputs)
            # tmp_eval_loss, logits = outputs[:2]
            logits = outputs[1]

            # eval_loss += tmp_eval_loss.mean().item()
        # nb_eval_steps += 1
        if pred_logits is None:
            pred_logits = logits.detach().cpu().numpy()
            gt_label_ids = inputs["labels"].detach().cpu().numpy()
        else:
            pred_logits = np.append(pred_logits, logits.detach().cpu().numpy(), axis=0)
            gt_label_ids = np.append(gt_label_ids, inputs["labels"].detach().cpu().numpy(), axis=0)

    # eval_loss = eval_loss / nb_eval_steps

    preds = np.argmax(pred_logits, axis=1)
    # pred_probs = torch.softmax(torch.tensor(pred_logits), 1).numpy()
    #
    # return pred_logits, pred_probs, preds, gt_label_ids
    return pred_logits, preds, gt_label_ids


if __name__ == "__main__":
    # victim model params
    args = config_param()

    # Setup CUDA, GPU
    if args.no_cuda:
        device = torch.device("cpu")
    else:
        device = torch.device("cuda")
    args.device = device

    reader = SnliReader()
    args.label_list = reader.label2id_dict.keys()
    data = reader.get_test_examples(args.data_dir) # should be train

    # Get Victim Model
    model_path = os.path.join(VICTIM_MODEL_DIR, args.victim_model_name)
    config = AutoConfig.from_pretrained(model_path, num_labels=len(args.label_list))
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_path,
        from_tf=bool(".ckpt" in model_path),
        config=config
    ).to(device)

    p = 'Three girls blow out the candles of a cake made of Peeps'
    h = 'There are three girls and a cake'

    p_n = ['for festival', 'in front of vehicle']
    p_c = ['with cat and two bunnies', 'on wood platform']

    text = [((p, h), 0), ((p+' '+p_n[0], h),0), ((p+' '+p_n[1], h),0),
            ((p+' '+p_c[0], h),0), ((p+' '+p_c[1], h),0)]

    pred_logits, preds, gt_label_ids = predict_from_texts(text, model, tokenizer, args)
    print(preds)
    # print(pred_probs)
    print(1)



