import os
# os.environ["CUDA_VISIBLE_DEVICES"] = '3'

import argparse
import logging
import shutil
import torch
import numpy as np

import transformers
from transformers import (
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    # BertConfig, BertForSequenceClassification, BertTokenizer,
    # RobertaConfig, RobertaForSequenceClassification, RobertaTokenizer,
)

from config import STANFORD_CORENLP_HOME
os.environ['CORENLP_HOME'] = STANFORD_CORENLP_HOME
from stanza.server import CoreNLPClient

from tqdm import tqdm # tqdm provides us a nice progress bar.
import csv
from datetime import datetime
from transformers import InputExample, InputFeatures
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset
from utils.data_utils import SnliReader, MedReader, SickReader, MnliReader
from config import *
from utils.metrics import acc_and_pr
from utils.logger import print_and_log
from utils.attack_utils import Natlog_Attack
from utils.data_utils import NatlogWordNet

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class NliProcessor(object):
    def __init__(self, reader):
        self.reader = reader

    def get_test_examples(self, data_dir, file_name):
        return self._bert_examples(self.reader.get_test_examples(data_dir, file_name))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

    def _bert_examples(self, ex_list):
        """
        Change SnliReader examples to Bert examples
        Delete -1 label ('-')
        :param ex_list: output list of SnliReader
        :return:
        """
        bert_examples = []
        for ex in ex_list:

            guid = ex['guid']
            idx = ex['index']
            text_a = ex['premise'].strip()
            text_b = ex['hypothesis'].strip()
            if 'gold_label_id' in ex.keys():
                label = ex['gold_label_id']
            else:
                label = ex['label_id']
            bert_examples.append(
                {"guid": guid, "idx": idx, "text_a": text_a, "text_b": text_b, "label": label}
            )
        return bert_examples

# def load_and_cache_natlog_examples_with_wordnet(processor, args):
#
#     cached_file = os.path.join(args.data_dir, "cached-{}-{}-wordnet".format(os.path.splitext(args.datafile_name)[0],
#                                                                             args.victim_model_name))
#     if os.path.exists(cached_file) and not args.overwrite_cache:
#         logger.info("Loading features from cached file %s", cached_file)
#         examples = torch.load(cached_file)
#     else:
#         logger.info("Creating features from dataset file %s", args.datafile_name)
#         # label_list = self.get_labels()
#         examples = processor.get_test_examples(args.data_dir, args.datafile_name)
#
#         map_project_dir = {"up": 1, "down": 2, 'flat': 0}
#         # feature_keys = ['guids', 'label_ids', 'premise', 'hypothesis', "p_tokens", "p_token_ids", "p_polarities",
#         #                 "p_polarity_dirs", "p_operators", "p_project_matrix", "p_length",
#         #                 "h_tokens", "h_token_ids", "h_polarities", "h_polarity_dirs", "h_operators",
#         #                 "h_project_matrix", "h_length"]
#
#         wordnet = NatlogWordNet(WORDNET_DIR)
#
#         with CoreNLPClient(annotators=['parse', 'natlog'], timeout=60000, memory='16G', threads=64) as client:
#             for ex in examples:
#                 ex.update(_analyze_example_with_corenlp(ex, client, map_project_dir))
#                 ex.update(_find_wordnet_relations(ex, wordnet))
#
#
#         logger.info("Saving features into cached file %s", cached_file)
#         torch.save(examples, cached_file)
#         print(1)
#
#
#     # # Convert to Tensors and build dataset
#     # all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
#     # all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
#     # all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)
#     # if output_mode == "classification":
#     #     all_labels = torch.tensor([f.label for f in features], dtype=torch.long)
#     # else:
#     #     raise ValueError("No other `output_mode` for XNLI.")
#     #
#     # dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)
#     # return dataset
#     return examples
#
# def _find_wordnet_relations(example, wordnet):
#     relations = []
#     for (postag, token, lemma, polarity, project_matrix, op) in zip(example['h_pos'],
#                                                                     example['h_tokens'],
#                                                                     example['h_lemma'],
#                                                                     example['h_polarity_dirs'],
#                                                                     example['h_project_matrix'],
#                                                                     example['h_operators']):
#         if postag[0:2] in ['NN', 'JJ', 'RB', 'VB']:  # n, adj, adv, v
#             pos_map = {'NN': 'n', 'JJ': 'a', 'RB': 'r', 'VB': 'v'}
#             eq = wordnet.get_eq(lemma, pos_map[postag[0:2]])
#             ent_f = wordnet.get_ent_f(lemma, pos_map[postag[0:2]], stack=2)
#             ent_r = wordnet.get_ent_r(lemma, pos_map[postag[0:2]], stack=2)
#             neg = wordnet.get_neg(lemma, pos_map[postag[0:2]])
#             alt = wordnet.get_alt(lemma, pos_map[postag[0:2]], stack=1)
#             relations.append({'eq': eq, 'ent_f': ent_f, 'ent_r': ent_r, 'neg': neg, 'alt': alt})
#
#             # search the wn
#         elif postag[0:2] == 'IN': # before, after, inside, outside, with, within, without
#             if lemma == 'before':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['after'], 'alt': []})
#             elif lemma == 'after':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['before'], 'alt': []})
#             elif lemma == 'inside':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['outside'], 'alt': []})
#             elif lemma == 'outside':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['inside'], 'alt': []})
#             elif lemma == 'within':
#                 relations.append({'eq': ['with'], 'ent_f': [], 'ent_r': [], 'neg': ['without'], 'alt': []})
#             elif lemma == 'with':
#                 relations.append({'eq': ['within'], 'ent_f': [], 'ent_r': [], 'neg': ['without'], 'alt': []})
#             elif lemma == 'without':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['with', 'within'], 'alt': []})
#             else:
#                 relations.append(None)
#
#         elif postag[0:2] == 'CD': # cardinal number
#             relations.append(None)
#         elif postag[0:2] == 'DT': # determinator
#             relations.append(None)
#         else:
#             if lemma == 'he':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['she'], 'alt': []})
#             elif lemma == 'she':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['he'], 'alt': []})
#             elif lemma == 'his':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['her'], 'alt': []})
#             elif lemma == 'her':
#                 relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['his'], 'alt': []})
#             else:
#                 relations.append(None)
#
#     return {'h_natlog_relations': relations}
#
# def _analyze_example_with_corenlp(example, client, map_project_dir):
#     def parseTree2str(tree):
#         tree_str = ''
#         stack = [tree]
#         token_num = 0
#         assess = 0
#         while len(stack) > 0:
#             node = stack.pop()
#             if node == ')':
#                 tree_str += ')'
#                 assess -= 1
#                 continue
#             if len(node.child) == 0:
#                 # leaf node
#                 tree_str += node.value + ' ' + str(token_num)
#                 token_num += 1
#             else:
#                 tree_str += '(' + node.value + ' '
#                 assess += 1
#             if len(node.child) > 0:
#                 # reverse add to stack
#                 stack.append(')')
#                 stack.extend(node.child[::-1])
#
#
#         assert assess == 0
#         return tree_str
#
#     feature = dict()
#     feature['h_parseTree'] = None
#     feature["h_tokens"] = []
#     feature["h_lemma"] = []
#     feature["h_pos"] = []
#     # feature["h_polarities"] = []
#     feature["h_polarity_dirs"] = []
#     feature["h_operators"] = []
#     feature["h_project_matrix"] = []
#     for s in client.annotate(example["text"]).sentence:
#         feature['h_parseTree'] = parseTree2str(s.parseTree)
#         feature["h_tokens"].extend([t.word for t in s.token])
#         feature["h_lemma"].extend([t.lemma for t in s.token])
#         feature["h_pos"].extend([t.pos for t in s.token])
#         feature["h_polarity_dirs"].extend([map_project_dir[t.polarity_dir] for t in s.token])
#
#         for t in s.token:
#             op = dict()
#             polarity = dict()
#             project_matrix = list()
#             op["name"] = t.operator.name
#             op["quant_span_s"] = t.operator.quantifierSpanBegin
#             op["quant_span_e"] = t.operator.quantifierSpanEnd
#             op["sub_span_s"] = t.operator.subjectSpanBegin
#             op["sub_span_e"] = t.operator.subjectSpanEnd
#             op["obj_span_s"] = t.operator.objectSpanBegin
#             op["obj_span_e"] = t.operator.objectSpanEnd
#
#             polarity["project_eq"] = t.polarity.projectEquivalence
#             polarity["project_ent_f"] = t.polarity.projectForwardEntailment
#             polarity["project_ent_r"] = t.polarity.projectReverseEntailment
#             polarity["project_neg"] = t.polarity.projectNegation
#             polarity["project_alt"] = t.polarity.projectAlternation
#             polarity["project_cov"] = t.polarity.projectCover
#             polarity["project_ind"] = t.polarity.projectIndependence
#
#             if op["name"] == '':
#                 op = {}
#             # else:
#             #     op["quant_span_s"] += feature["h_length"]
#             #     op["quant_span_e"] += feature["h_length"]
#             #     op["sub_span_s"] += feature["h_length"]
#             #     op["sub_span_e"] += feature["h_length"]
#             #     op["obj_span_s"] += feature["h_length"]
#             #     op["obj_span_e"] += feature["h_length"]
#
#             for key in ["project_eq", "project_ent_f", "project_ent_r",
#                         "project_neg", "project_alt", "project_cov", "project_ind"]:
#                 project_matrix.append(polarity[key])
#
#             feature["h_operators"].append(op)
#             # feature['h_polarities'].append(polarity)
#             feature["h_project_matrix"].append(project_matrix)
#
#         return feature


def config_param():
    parser = argparse.ArgumentParser()
    # Required parameters need to change
    parser.add_argument(
        "--attack_setting", default=1, type=int, help="attack setting"
    )
    parser.add_argument(
        "--datafile_name",
        default="med_down_chosen.txt",  #snli_chosen.txt, med_up_chosen_other.txt med_down_chosen.txt, med_up_chosen.txt
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )
    parser.add_argument(
        "--victim_model_name",
        default='roberta-base_snlimix', # 'bert-base_snlimix', 'roberta-base_snlimix', 'bert-base_snli', 'roberta-base_snli'
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )
    parser.add_argument(
        "--model_type",
        default='roberta', #roberta, bert
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )

    parser.add_argument(
        "--max_queries", default=500, type=int, help="attack setting"
    )
    parser.add_argument(
        "--method_pp", default=True, type=bool, help="attack method"
    )
    parser.add_argument(
        "--method_insert_delete", default=True, type=bool, help="attack method"
    )
    parser.add_argument(
        "--method_natlog", default=True, type=bool, help="attack method"
    )
    parser.add_argument(
        "--data_dir",
        default=ATTACK_SAMPLE_DIR,
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )
    parser.add_argument(
        "--pp_file_dir",
        default=DATASET_DIR,
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )

    parser.add_argument(
        "--max_seq_length",
        default=128,
        type=int,
        help="The maximum total input sequence length after tokenization. Sequences longer "
             "than this will be truncated, sequences shorter will be padded.",
    )

    parser.add_argument("--no_cuda", action="store_true", help="Avoid using CUDA when available")

    parser.add_argument(
        "--overwrite_cache", action="store_true", help="Overwrite the cached datasets"
    )

    parser.add_argument(
        "--log_dir",
        default=os.path.join(LOG_DIR, 'natattack'),
        type=str,
        # required=True,
        help="The output log directory where the model predictions and checkpoints will be written.",
    )
    parser.add_argument("--run_name", default="natattack_" + datetime.now().strftime("%m-%d_%H-%M"),
                        type=str, help="Name this run. run_name wil be used in tensorboard log and log file")

    return parser.parse_args()


def examples2fea(examples, tokenizer, label_list,
                 max_length=512,
                 # pad_on_left=False,
                 # pad_token=0,
                 # pad_token_segment_id=0,
                 mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """

    pad_token = tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0]
    pad_token_segment_id = 0
    pad_on_left = False

    logger.info("Using label list %s" % (label_list))

    features = []
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Converting example %d" % (ex_index))


        inputs = tokenizer.encode_plus(
            example['text_a'],
            example['text_b'],
            add_special_tokens=True,
            # return_token_type_ids=True,
            max_length=max_length,
        )

        input_ids = inputs["input_ids"]
        if 'token_type_ids' in inputs.keys():
            token_type_ids = inputs["token_type_ids"]
        else:
            len_a = len(tokenizer.encode(example['text_a']))
            token_type_ids = [0] * len_a + [1] * (len(input_ids) - len_a)
        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_mask

            token_type_ids = ([pad_token_segment_id] * padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)

            token_type_ids = token_type_ids + ([pad_token_segment_id] * padding_length)

        assert len(input_ids) == max_length, "Error with input length {} vs {}".format(len(input_ids), max_length)
        assert len(attention_mask) == max_length, "Error with input length {} vs {}".format(len(attention_mask), max_length)
        assert len(token_type_ids) == max_length, "Error with input length {} vs {}".format(len(token_type_ids), max_length)

        label = example['label']

        # if ex_index < 3:
        #     logger.info("*** Example ***")
        #     logger.info("text: %s, %s" % (example['text_a'], example['text_b']))
        #     logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
        #     logger.info("attention_mask: %s" % " ".join([str(x) for x in attention_mask]))
        #     logger.info("token_type_ids: %s" % " ".join([str(x) for x in token_type_ids]))
        #     if label is not None:
        #         logger.info("label: %s" % (label))

        features.append(
            InputFeatures(input_ids=input_ids,
                          attention_mask=attention_mask,
                          token_type_ids=token_type_ids,
                          label=label))

    return features


def text2examples(texts):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """

    examples = []
    ex_sample = texts[0][0]
    if type(ex_sample) == str:
        no_b = True
    else:
        no_b = False
    for (idx, text) in enumerate(texts):
        if no_b:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0], "text_b": '', "label": text[-1]}
            )
        else:
            examples.append(
                {"guid": idx, "idx": idx, "text_a": text[0][0], "text_b": text[0][1], "label": text[-1]}
            )
    return examples



def predict_from_texts(texts, model, tokenizer, args):
    """

    :param texts: texts should be [((s1, s2), label), ((s1, s2), label),...] for nli
    :return:
    """
    examples = text2examples(texts)
    features = examples2fea(examples, tokenizer, args.label_list, args.max_seq_length)

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)

    all_labels = torch.tensor([f.label for f in features], dtype=torch.long)

    dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)

    # evaluate
    eval_sampler = SequentialSampler(dataset)
    eval_dataloader = DataLoader(dataset, sampler=eval_sampler, batch_size=16)

    # eval_loss = 0.0
    # nb_eval_steps = 0
    pred_logits = None
    gt_label_ids = None
    for batch in tqdm(eval_dataloader, desc="Evaluating"):
        model.eval()
        batch = tuple(t.to(args.device) for t in batch)

        with torch.no_grad():
            inputs = {"input_ids": batch[0],
                      "attention_mask": batch[1],
                      'token_type_ids': batch[2] if args.model_type in ['bert'] else None,
                      "labels": batch[3]}

            outputs = model(**inputs)
            # tmp_eval_loss, logits = outputs[:2]
            logits = outputs[1]

            # eval_loss += tmp_eval_loss.mean().item()
        # nb_eval_steps += 1
        if pred_logits is None:
            pred_logits = logits.detach().cpu().numpy()
            gt_label_ids = inputs["labels"].detach().cpu().numpy()
        else:
            pred_logits = np.append(pred_logits, logits.detach().cpu().numpy(), axis=0)
            gt_label_ids = np.append(gt_label_ids, inputs["labels"].detach().cpu().numpy(), axis=0)

    # eval_loss = eval_loss / nb_eval_steps

    preds = np.argmax(pred_logits, axis=1)
    # pred_probs = torch.softmax(torch.tensor(pred_logits), 1).numpy()
    #
    # return pred_logits, pred_probs, preds, gt_label_ids
    return pred_logits, preds, gt_label_ids



def main():
    args = config_param()

    # Setup CUDA, GPU
    if args.no_cuda:
        device = torch.device("cpu")
    else:
        device = torch.device("cuda")
    args.device = device

    # Setup logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    log_path = os.path.join(args.log_dir, args.run_name + ".log")
    logger = print_and_log(logger, log_path)
    logger = logging.getLogger(__name__)

    # Basic imformation
    logger.info("Sample File: %s", args.datafile_name)
    logger.info("Victim Model: %s", args.victim_model_name)
    logger.info("Run Name: %s", args.run_name)
    logger.info("======================================================")

    # # Copy file
    # bk_dir = os.path.join(BK_DIR, args.run_name)
    # if not os.path.exists(bk_dir):
    #     os.mkdir(bk_dir)
    # filelist = ["scripts", "utils", "config"]
    # for file_dir in filelist:
    #     shutil.copytree(os.path.join(BASE_DIR, file_dir), os.path.join(bk_dir, file_dir))


    # Setup processor
    assert args.datafile_name in ["med_up_chosen_other.txt", "snli_chosen.txt", "med_up_chosen.txt", "med_down_chosen.txt",
                                  "sick_chosen.txt", "mnli_m_chosen.txt", "sick_chosen2.txt"], "Undefined File Name"
    if args.datafile_name == "snli_chosen.txt":
        reader = SnliReader()
    elif args.datafile_name in ["med_up_chosen.txt", "med_down_chosen.txt", "med_up_chosen_other.txt", "med_up_chosen_natlog.txt"]:
        reader = MedReader()
    elif args.datafile_name in  ["sick_chosen.txt", "sick_chosen2.txt"]:
        reader = SickReader()
    elif args.datafile_name == "mnli_m_chosen.txt":
        reader = MnliReader(tsv=False)

    processor = NliProcessor(reader)
    args.id2label_dict = processor.reader.id2label_dict
    args.label2id_dict = processor.reader.label2id_dict
    args.label_list = processor.get_labels()
    num_labels = len(args.label_list)

    # Get Victim Model
    model_path = os.path.join(VICTIM_MODEL_DIR, args.victim_model_name)
    config = AutoConfig.from_pretrained(model_path, num_labels=num_labels)
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_path,
        from_tf=bool(".ckpt" in model_path),
        config=config
    ).to(args.device)

    # Get data
    # attack_examples = load_and_cache_natlog_examples_with_wordnet(processor, args)
    attack_examples = [
        # {'guid': 't0', 'idx': '0', 'text_a': 'two women in lingerie with green feathers around waist',
        #  'text_b': "Two women don't wear much clothing", 'label': 0},
        # {'guid': 't1', 'idx': '1', 'text_a': 'People seated at long tables all facing the same direction, some writing and some watching',
        #  'text_b': "A group of people are sitting at tables", 'label': 0},
        # {'guid': 't2', 'idx': '2', 'text_a': "I don't eat the core of an apple",
        #  'text_b': "I don't eat the core of a red apple", 'label': 0},
        # {'guid': 't3', 'idx': '3', 'text_a': "A white dog bit her leg",
        #  'text_b': "A dog bit her leg", 'label': 0},
        # {'guid': 't3', 'idx': '3', 'text_a': "Tom and Mary don't eat meat anymore",
        #  'text_b': "Tom and Mary don't eat lamb meat anymore", 'label': 0},  #> wrong polarity
        # {'guid': 'e2n-test', 'idx': '4', 'text_a': "A woman is being massaged by a man",
        #  'text_b': "A man is massaging a woman", 'label': 0},   #1254
        {'guid': 'test', 'idx': '0', 'text_a': "A white dog bit her leg",
         'text_b': "A dog bit her leg", 'label': 0}

    ]
    # attack_examples = processor.get_test_examples(args.data_dir, args.datafile_name)


    # Attack methods
    tag = args.model_type+'_'+args.datafile_name[:-4]
    attacker = Natlog_Attack(model, tokenizer, args, predict_from_texts, args.max_queries, args.pp_file_dir,
                             args.method_pp, args.method_insert_delete, args.method_natlog, tag=tag, device=args.device)
    result = attacker.attack(attack_examples, setting=args.attack_setting)

    # for ex in attack_examples:
    #     print(1)
    # print(1)



if __name__ == "__main__":
    main()