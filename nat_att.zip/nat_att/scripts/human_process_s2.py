import argparse
import os
import numpy as np
import pandas as pd
from config.data_config import *
from collections import Counter

def freq_label(x):
    freq = Counter(x).most_common()
    if len(freq) > 1 and freq[0][1] == freq[1][1]:
        return "None"
    return freq[0][0]

if __name__ == '__main__':
    version = "v13s2"
    ori_csv_name = 'roberta_mnli_natlog12s2_2.csv'
    victim_model = "roberta"
    attack_model = "natlog12s2"
    dataset = "mnli"
    # s2_type = "e2c" # e2n, c2e
    # polarity = "up"

    print("========= Read File =========")
    dir_name = os.path.join(HUMAN_DIR, "human_evaluation_original_files", version)
    output_dir = dir_name + '_processed'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    run_name = "_".join([victim_model, attack_model, dataset])
    # if dataset == "med":
    #     run_name = run_name + "_" + polarity
    output_csv_name = run_name + '.csv'
    data_df = pd.read_csv(os.path.join(dir_name, ori_csv_name))

    # cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
    #                  "Input.s1", "Input.s2", "Input.ori_label", "Input.new_label", "Input.predit",
    #                  "Input.query_num", "Input.dataset", "Input.victim_model"
    #                  "Input.dir", "Input.method", "Input.done", "Input.success", "Answer.nli.label", "Input.s2type"]
    cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
                 "Input.s1", "Input.s2", "Input.ori_label", "Input.new_label", "Input.predit",
                 "Input.query_num", "Input.dataset", "Input.victim_model",
                 "Input.dir",  "Input.done", "Input.success", "Answer.nli.label", "Input.s2type"]

    # if attack_model == 'natlog2s2':
    #     cols_name += ["Input.s2type"]
    data_df = data_df[cols_name]
    # data_df = data_df.rename(columns={
    #     "AssignmentStatus": "status", "Input.idx": "idx", "Input.ori_p": "ori_p", "Input.ori_h": "ori_h",
    #     "Input.s1": "s1", "Input.s2": "s2", "Input.ground_truth_output": "label", "Input.perturbed_output": "predict",
    #     "Input.num_queries": "num_queries", "Input.result_type": "result_type",
    #     "Input.dataset": "dataset", "Input.victim_model": "victim_model",
    #     "Input.dir": "dir", "Input.method": "method",
    #     "Input.done": "done", "Input.success": "success", "Answer.nli.label": "human_label", "Input.s2type": "s2type"
    # })
    data_df = data_df.rename(columns={
        "AssignmentStatus": "status", "Input.idx": "idx", "Input.ori_p": "ori_p", "Input.ori_h": "ori_h",
        "Input.s1": "s1", "Input.s2": "s2", "Input.new_label": "label", "Input.predit": "predict",
        "Input.query_num": "num_queries",
        "Input.dataset": "dataset", "Input.victim_model": "victim_model",
        "Input.dir": "dir",
        "Input.done": "done", "Input.success": "success", "Answer.nli.label": "human_label", "Input.s2type": "s2type"
    })

    data_df = data_df[data_df.status != "Rejected"]
    if dataset == "med":
        data_df["human_label2"] = data_df["human_label"].apply(lambda x: x if x == 'entailment' else 'neutral')
        data_df["freq_label2"] = data_df[["idx", "dir", "s2type", "human_label"]].groupby(["idx", "dir", "s2type"])["human_label"].transform(lambda x: freq_label(x))
        data_df["freq_label"] = data_df[["idx", "dir", "s2type", "human_label2"]].groupby(["idx", "dir", "s2type"])["human_label2"].transform(lambda x: freq_label(x))
        data_df = data_df.drop(['human_label2'], axis=1)
    else:
        data_df["freq_label"] = data_df[["idx", "s2type", "human_label"]].groupby(["idx", "s2type"])["human_label"].transform(lambda x: freq_label(x))

    print("========= Write CSV =========")
    output_df = data_df.drop(['status', 'human_label'], axis=1).drop_duplicates().reset_index(drop=True)
    output_df.to_csv(os.path.join(output_dir, output_csv_name))

    print(len(output_df))