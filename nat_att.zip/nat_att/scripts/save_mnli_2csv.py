from utils.data import read_tsv
import os
from config import *
import csv
import numpy as np
import pandas as pd

data_dir = os.path.join(MNLI_DIR)
file_path = os.path.join(data_dir, "multinli_1.0_dev_matched.txt")

# with open(file_path, "r", encoding="utf-8") as f:
#     data = csv.reader(f, delimiter='\t')

data = read_tsv(file_path,delimiter='\t')
df = pd.DataFrame(data[1:], columns=data[0])
df.to_csv(os.path.join(MNLI_DIR, "mnli_m.csv"))
print(1)