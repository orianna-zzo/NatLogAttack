import torch
import os
os.environ["CUDA_VISIBLE_DEVICES"]='0'
import numpy as np

# from config import WORDNET_DIR, STANFORD_CORENLP_HOME

import transformers
from transformers import (
    DistilBertConfig, DistilBertForMaskedLM, DistilBertTokenizer
)

# os.environ['CORENLP_HOME'] = STANFORD_CORENLP_HOME
# from stanza.server import CoreNLPClient



def lm_predict(sentence, lm_tokenizer, lm_model):
    with torch.no_grad():
        inputs = lm_tokenizer.encode(sentence, return_tensors='pt')
        idx = torch.where((inputs == lm_tokenizer.encode('[MASK]')[1])>0)[-1].numpy()[0]
        pred_logits = lm_model(inputs)['logits'].detach().cpu().numpy()
        pred = np.argsort(pred_logits.squeeze()[idx])[::-1][:100]
        return [s.replace(' ', '') for s in lm_tokenizer.batch_decode(pred.tolist())]

def lm_score(sentence, lm_tokenizer, lm_model):
    with torch.no_grad():
        tensor_input = lm_tokenizer.encode(sentence, return_tensors='pt')
        repeat_input = tensor_input.repeat(tensor_input.size(-1)-2, 1)
        mask = torch.ones(tensor_input.size(-1) - 1).diag(1)[:-2]
        masked_input = repeat_input.masked_fill(mask == 1, lm_tokenizer.encode('[MASK]')[1])
        labels = repeat_input.masked_fill(masked_input != lm_tokenizer.encode('[MASK]')[1], -100)

        loss = lm_model(masked_input, labels=labels)['loss']
        result = np.exp(loss.item())
        return result

def lm_score2(sentence, lm_tokenizer, lm_model):
    with torch.no_grad():
        tensor_input = lm_tokenizer.encode(sentence, return_tensors='pt')

        with torch.no_grad():
            loss=lm_model(tensor_input, labels=tensor_input)[0]
        return np.exp(loss.detach().numpy())

def lm_test_score(sentence, lm_tokenizer, lm_model):
    with torch.no_grad():
        tensor_input = lm_tokenizer.encode(sentence, return_tensors='pt')

        output = lm_model(tensor_input, output_hidden_states=True)
        hidden_states = output["hidden_states"][-1].squeeze(0)
        res1 = torch.det(hidden_states.mm(hidden_states.T))
        res2 = torch.ones(hidden_states.size()[-1])
        for i in range(hidden_states.size()[0]):
            res2 = res2 * hidden_states[i,:]
        res2 = torch.dot(res2, torch.ones(hidden_states.size()[-1]))
        prob = torch.nn.functional.softmax(output.logits.squeeze(0))
        res3 = 1
        tokens = tensor_input.squeeze(0)[1:-1]
        for i in range(len(tokens)):
            res3 = res3 * prob[i+1][tokens[i]]

        return res1, res2, res3






if __name__ == '__main__':




    adv_ex =["n't", 'not', 'no']

    lm_model_name = "distilbert-base-uncased"
    lm_config = DistilBertConfig.from_pretrained(lm_model_name)
    lm_tokenizer = DistilBertTokenizer.from_pretrained(lm_model_name)
    lm_model = DistilBertForMaskedLM.from_pretrained(lm_model_name, config=lm_config)

    text = 'Pedestrians wait  for the  tram  to  pass  before  crossing  the [MASK] street'

    ins_token = [i for i in lm_predict(text, lm_tokenizer, lm_model) if i not in adv_ex]
    new_text_list = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+i+' street' for i in ins_token]

    # lm_true score
    lm_scores = [lm_score(i, lm_tokenizer, lm_model) for i in new_text_list]
    lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)

    test_scores2 = [lm_score2(i, lm_tokenizer, lm_model) for i in new_text_list]
    scores2_idx = sorted(range(len(test_scores2)), key=lambda k: test_scores2[k], reverse=False)
    test_scores = [lm_test_score(i, lm_tokenizer, lm_model) for i in new_text_list]
    t1 = [i[0] for i in test_scores]
    t2 = [i[1] for i in test_scores]
    t3 = [i[2] for i in test_scores]
    t1_idx = sorted(range(len(t1)), key=lambda k: t1[k], reverse=False)
    t2_idx = sorted(range(len(t2)), key=lambda k: t2[k], reverse=False)
    t3_idx = sorted(range(len(t3)), key=lambda k: t3[k], reverse=False)

    s0 = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+ins_token[i]+' street' for i in lm_scores_idx]
    s02 = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+ins_token[i]+' street' for i in scores2_idx]
    s1 = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+ins_token[i]+' street' for i in t1_idx]
    s2 = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+ins_token[i]+' street' for i in t2_idx]
    s3 = ['Pedestrians wait  for the  tram  to  pass  before  crossing  the '+ins_token[i]+' street' for i in t3_idx]

    print(1)

