import argparse
import os
import numpy as np
import pandas as pd
from config.data_config import *
from collections import Counter

def freq_label(x):
    freq = Counter(x).most_common()
    if len(freq) > 1 and freq[0][1] == freq[1][1]:
        return "None"
    return freq[0][0]

# def freq_label(x): # 3 个label
#     freq = Counter(x).most_common()
#     if len(freq) > 1 and freq[0][1] < 3:
#         return "None"
#     return freq[0][0]

if __name__ == '__main__':
    version = "v13"
    ori_csv_name = 'roberta_sick_natlog12_all.csv'
    victim_model = "roberta"
    attack_model = "natlog12"
    dataset = "sick"
    # polarity = "up"

    print("========= Read File =========")
    dir_name = os.path.join(HUMAN_DIR, "human_evaluation_original_files", version)
    output_dir = dir_name + '_processed'
    run_name = "_".join([victim_model, attack_model, dataset])
    # if dataset == "med":
    #     run_name = run_name + "_" + polarity
    output_csv_name = run_name + '.csv'

    if not os.path.exists(os.path.join(dir_name, output_dir)):
        os.mkdir(os.path.join(dir_name, output_dir))

    data_df = pd.read_csv(os.path.join(dir_name, ori_csv_name))
    if attack_model[0:3] == "nat":
        # cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
        #              "Input.s1", "Input.s2", "Input.ground_truth_output", "Input.perturbed_output",
        #              "Input.num_queries", "Input.result_type", "Input.dataset", "Input.victim_model",
        #              "Input.dir", "Input.method", "Input.done", "Input.success", "Answer.nli.label"]
        # cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
        #              "Input.s1", "Input.s2", "Input.ori_label", "Input.new_label", "Input.predit",
        #              "Input.query_num", "Input.dataset", "Input.victim_model",
        #              "Input.dir", "Input.method", "Input.done", "Input.success", "Answer.nli.label"]

        cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
                     "Input.s1", "Input.s2", "Input.ori_label", "Input.new_label", "Input.predit",
                     "Input.query_num", "Input.dataset", "Input.victim_model",
                     "Input.dir", "Input.method", "Input.success", "Answer.nli.label"]


    else:
        cols_name = ["AssignmentStatus", "Input.idx", "Input.ori_p", "Input.ori_h",
                     "Input.s1", "Input.s2", "Input.ground_truth_output", "Input.perturbed_output",
                     "Input.num_queries", "Input.result_type", "Input.dataset", "Input.victim_model",
                     "Input.dir", "Input.method", "Answer.nli.label"]

    data_df = data_df[cols_name]
    # data_df = data_df.rename(columns={
    #     "AssignmentStatus": "status", "Input.idx": "idx", "Input.ori_p": "ori_p", "Input.ori_h": "ori_h",
    #     "Input.s1": "s1", "Input.s2": "s2", "Input.ground_truth_output": "label", "Input.perturbed_output": "predict",
    #     "Input.num_queries": "num_queries", "Input.result_type": "result_type",
    #     "Input.dataset": "dataset", "Input.victim_model": "victim_model",
    #     "Input.dir": "dir", "Input.method": "method",
    #     "Input.done": "done", "Input.success": "success", "Answer.nli.label": "human_label"
    # })

    if attack_model[0:3] == "nat":
        data_df = data_df.rename(columns={
            "AssignmentStatus": "status", "Input.idx": "idx", "Input.ori_p": "ori_p", "Input.ori_h": "ori_h",
            "Input.s1": "s1", "Input.s2": "s2", "Input.new_label": "label", "Input.predit": "predict",
            "Input.query_num": "num_queries",
            "Input.dataset": "dataset", "Input.victim_model": "victim_model",
            "Input.dir": "dir", "Input.method": "method",
            "Input.done": "done", "Input.success": "success", "Answer.nli.label": "human_label"
        })
    else:
        data_df = data_df.rename(columns={
            "AssignmentStatus": "status", "Input.idx": "idx", "Input.ori_p": "ori_p", "Input.ori_h": "ori_h",
            "Input.s1": "s1", "Input.s2": "s2", "Input.ground_truth_output": "label", "Input.perturbed_output": "predict",
            "Input.num_queries": "num_queries", "Input.result_type": "result_type",
            "Input.dataset": "dataset", "Input.victim_model": "victim_model",
            "Input.dir": "dir", "Input.method": "method",
            "Input.done": "done", "Input.success": "success", "Answer.nli.label": "human_label"
        })

    data_df = data_df[data_df.status != "Rejected"]
    data_df["freq_label"] = data_df[["idx", "dir", "human_label"]].groupby("idx")["human_label"].transform(lambda x: freq_label(x))
    # data_df["freq_label"] = data_df[["idx", "dir", "human_label"]].groupby("idx")["human_label"].transform(lambda x: freq_label(x))


    if dataset == "med":
        data_df["freq_label"] = data_df[["idx", "dir", "human_label"]].groupby(["idx", "dir"])["human_label"].transform(lambda x: freq_label(x))
    else:
        data_df["freq_label"] = data_df[["idx", "human_label"]].groupby(["idx"])["human_label"].transform(lambda x: freq_label(x))


    print("========= Write CSV =========")
    output_df = data_df.drop(['status', 'human_label'], axis=1).drop_duplicates().reset_index(drop=True)
    output_df.to_csv(os.path.join(output_dir, output_csv_name))

    print(len(output_df))