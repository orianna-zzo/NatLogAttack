import random
import pandas as pd
from scipy import stats
from config.data_config import HUMAN_DIR
import os

def compute_paired_ttest_oneside(d1, d2, h0_rel, sample_n, sample_times):
    assert len(d1) == len(d2)
    ori_sample_n = len(d1)
    x1 = list()
    x2 = list()

    # Sample the data $sample_times$ times
    for i in range(sample_times):
        sample_idx = random.sample(range(len(d1)), sample_n)
        x1 += [d1[idx] for idx in sample_idx]
        x2 += [d2[idx] for idx in sample_idx]

    # Compute t test
    p_value = ttest_rel_onside(x1, x2, h0_rel)

    return p_value

def ttest_rel_onside(d1, d2, h0_rel = "gt"):
    assert h0_rel in ["gt", "st"]
    if h0_rel == "gt":
        # H0: d1>d2
        (t, p) = stats.ttest_rel(d1, d2)
        if t > 0:
            p_oneside = 1-p/2.0
        else:
            p_oneside = p/2.0
            t = t*(-1)
    elif h0_rel == "st":
        # H0: d1<d2
        (t, p) = stats.ttest_rel(d1, d2)
        if t <0:
            p_oneside = 1-p/2.0
            t = t*(-1)
        else:
            p_oneside = p/2.0
    return (t, p_oneside)





if __name__ == "__main__":
    attack_model_1 = "natlog2"  # ours
    attack_model_2 = "textfooler"   # compared
    victim_model = "roberta"
    dataset = "snli"
    dir = "up"
    target = "human"   # ppl     query  human
    human_version = "v22"

    if target in ["ppl", "query"]:
        h0_rel = "gt"
    else:
        h0_rel = "st"

    if dataset == "med":
        sample_n = 300
    elif dataset == "snli":
        sample_n = 600

    # read data
    if target == "human":
        dir_name = os.path.join(HUMAN_DIR, "human_evaluation_original_files", human_version + '_processed')
        run_name_1 = "_".join([victim_model, attack_model_1, dataset])
        data1 = pd.read_csv(os.path.join(dir_name, run_name_1 + '.csv'))

        run_name_2 = "_".join([victim_model, attack_model_2, dataset])
        data2 = pd.read_csv(os.path.join(dir_name, run_name_2 + '.csv'))

    else:
        dir_name_1 = os.path.join(HUMAN_DIR, attack_model_1)
        run_name_1 = '_'.join([victim_model, attack_model_1, dataset])
        file_path_1 = os.path.join(dir_name_1, run_name_1+'_ppl_error.csv')

        data1 = pd.read_csv(file_path_1)

        dir_name_2 = os.path.join(HUMAN_DIR, attack_model_2)
        run_name_2 = '_'.join([victim_model, attack_model_2, dataset])
        file_path_2 = os.path.join(dir_name_2, run_name_2+'_ppl_error.csv')

        data2 = pd.read_csv(file_path_2)

    if dataset == "med" and dir in ["up", "down"]:
        data1 = data1[data1.dir == dir]
        data2 = data2[data2.dir == dir]

    # get compared data
    if target == "ppl":
        d1 = data1["ppl_sum"].tolist()
        d2 = data2["ppl_sum"].tolist()
    elif target == "query":
        d1 = data1["num_queries"].tolist()
        d2 = data2["num_queries"].tolist()
    elif target == "human":
        data1['freq_label'] = data1['freq_label'].map({'entailment': 0, 'neutral': 1, 'contradiction': 2, 'None': -1}).apply(int)
        data1['label'] = data1['label'].apply(int)
        data1['predict'] = data1['predict'].apply(int)
        data1['num_queries'] = data1['num_queries'].apply(int)

        data2['freq_label'] = data2['freq_label'].map({'entailment': 0, 'neutral': 1, 'contradiction': 2, 'None': -1}).apply(int)
        data2['label'] = data2['label'].apply(int)
        data2['predict'] = data2['predict'].apply(int)
        data2['num_queries'] = data2['num_queries'].apply(int)

        if dataset == "med":
            d1 = ((data1.num_queries <= 500) & (data1.freq_label == data1.label) & (((data1.label == 0) & (data1.predict > 0)) | ((data1.label > 0) & (data1.predict == 0)))).apply(int).tolist()
            d2 = ((data2.num_queries <= 500) & (data2.freq_label == data2.label) & (((data2.label == 0) & (data2.predict > 0)) | ((data2.label > 0) & (data2.predict == 0)))).apply(int).tolist()

        else:
            d1 = ((data1.num_queries <= 500) & (data1.freq_label == data1.label) & (data1.predict != data1.freq_label)).apply(int).tolist()
            d2 = ((data2.num_queries <= 500) & (data2.freq_label == data2.label) & (data2.predict != data2.freq_label)).apply(int).tolist()


    p_value = compute_paired_ttest_oneside(d1, d2, h0_rel, sample_n, 1000)
    print(p_value)