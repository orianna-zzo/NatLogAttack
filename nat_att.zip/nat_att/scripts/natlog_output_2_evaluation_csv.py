import os
import numpy as np
import pandas as pd
from utils.data_utils import SnliReader, MedReader

from config.data_config import *

victim_model = "bert"
method = "natlog4"

nat_output_files = [os.path.join(HUMAN_DIR, "natlog4", "same_label_bert_med_up_chosen4.txt"),
                    os.path.join(HUMAN_DIR, "natlog4", "same_label_bert_med_down_chosen4.txt")]
dataset = "med"
input_data_files = ["med_up_chosen.txt", "med_down_chosen.txt"]
reader = MedReader()

# nat_output_files = [os.path.join(HUMAN_DIR, "natlog4", "same_label_bert_snli_chosen4.txt")]
# dataset = "snli"
# input_data_files = ["snli_chosen.txt"]
# reader = SnliReader()

output_df = pd.DataFrame()

for nat_output_file, file_name in zip(nat_output_files, input_data_files):
    input_data = reader.get_test_examples(ATTACK_SAMPLE_DIR, file_name)
    nat_output = pd.read_csv(nat_output_file, delimiter='\t')
    # this_out_df = pd.DataFrame()
    nat_output['idx'] = nat_output['idx'].apply(lambda x:input_data[x]["index"])
    nat_output['s1'] = nat_output['new_p']
    nat_output['s2'] = nat_output['new_h']
    nat_output['original_output'] = nat_output['ori_label']
    nat_output['ground_truth_output'] = nat_output['new_label']
    nat_output['perturbed_output'] = nat_output['predit']
    nat_output['num_queries'] = nat_output['query_num']
    nat_output['result_type'] = nat_output['success'].apply(lambda x: "Successful" if x==1 else "Failed")
    nat_output['dataset'] = dataset
    nat_output['victim_model'] = victim_model
    nat_output['done'] = nat_output['method']
    nat_output = nat_output.reindex(columns=nat_output.columns.tolist() + ["original_score", "perturbed_score", 'dir'])
    if dataset == "med":
        if "up" in file_name:
            nat_output['dir'] = "up"
        elif "down" in file_name:
            nat_output['dir'] = "down"

    this_out_df = nat_output[["idx", "ori_p", "ori_h", "s1", "s2", "original_score", "perturbed_score",
                              "original_output", "perturbed_output", "ground_truth_output", "num_queries", "result_type",
                              "dataset", "victim_model", "dir", "method", "done", "success"]]
    output_df = pd.concat([output_df, this_out_df])

print(1)
output_df.to_csv(os.path.join(HUMAN_DIR, method, victim_model+"_"+method+"_"+dataset+".csv"))



