import os
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from config import HUMAN_DIR
# sns.set_theme(style="whitegrid")

# dataset = "snli" #med
victim_model = "bert"  #roberta

query_data = pd.DataFrame()

############################## snli
datasets = ["snli", "med"]
models = ["bert", "roberta"]
for victim_model in models:
    for dataset in datasets:
        pwws = pd.read_csv(os.path.join(HUMAN_DIR, "pwws", '_'.join([victim_model, "pwws", dataset])+".csv"))
        if dataset =="med":
            pwws = pwws[pwws.original_output == 0]
        pwws = pwws[["num_queries"]]
        pwws["Model"] = "PWWS"
        pwws["Dataset"] = dataset.upper()
        pwws["victim"] = victim_model

        textfooler = pd.read_csv(os.path.join(HUMAN_DIR, "textfooler", '_'.join([victim_model, "textfooler", dataset])+".csv"))
        if dataset =="med":
            textfooler = textfooler[textfooler.original_output == 0]
        textfooler = textfooler[["num_queries"]]
        textfooler["Model"] = "Textfooler"
        textfooler["Dataset"] = dataset.upper()
        textfooler["victim"] = victim_model

        pso = pd.read_csv(os.path.join(HUMAN_DIR, "pso", '_'.join([victim_model, "pso", dataset])+".csv"))
        if dataset =="med":
            pso = pso[pso.original_output == 0]
        pso = pso[["num_queries"]]
        pso["Model"] = "PSO"
        pso["Dataset"] = dataset.upper()
        pso["victim"] = victim_model

        bertattack = pd.read_csv(os.path.join(HUMAN_DIR, "bertattack", '_'.join([victim_model, "bertattack", dataset])+".csv"))
        if dataset =="med":
            bertattack = bertattack[bertattack.original_output == 0]
        bertattack = bertattack[["num_queries"]]
        bertattack["Model"] = "BertAttack"
        bertattack["Dataset"] = dataset.upper()
        bertattack["victim"] = victim_model

        clare = pd.read_csv(os.path.join(HUMAN_DIR, "clare", '_'.join([victim_model, "clare", dataset])+".csv"))
        if dataset =="med":
            clare = clare[clare.original_output == 0]
        clare = clare[["num_queries"]]
        clare["Model"] = "Clare"
        clare["Dataset"] = dataset.upper()
        clare["victim"] = victim_model

        natlog = pd.read_csv(os.path.join(HUMAN_DIR, "natlog2", '_'.join([victim_model, "natlog2", dataset])+".csv"))
        if dataset =="med":
            natlog = natlog[natlog.original_output == 0]
        natlog = natlog[["num_queries"]]
        print(natlog.describe())
        natlog["Model"] = "NatLogAttack"
        natlog["Dataset"] = dataset.upper()
        natlog["victim"] = victim_model
        snli_data = pd.concat([pwws, textfooler, pso, bertattack, clare, natlog], axis=0)

        query_data = pd.concat([query_data, pwws, textfooler, pso, bertattack, clare, natlog])

############################## med

query_data.loc[query_data.num_queries >800, 'num_queries'] = 800

ax = sns.catplot(x="Model", y="num_queries", hue="victim", dodge=False, col="Dataset", cut=0, bw=.2, #, scale="width"
                    data=query_data, kind="violin", split=True, legend=False, legend_out=False)
# legend_labels, _= ax.get_legend_handles_labels()
# ax.legend(legend_labels, labels=['BERT', 'RoBERTa'], bbox_to_anchor=(1.26,1), title='Victim Model')

hue_labels = ['BERT', 'RoBERTa']

ax.add_legend(title='Victim Model', loc='upper left', fontsize=14, legend_data={
    key: value for key, value in zip(hue_labels, ax._legend_data.values())
})


ax.set_ylabels(fontsize=17)
ax.set_xlabels(fontsize=17)
ax.set_titles(fontsize=17)

ax.set(xlabel='Attack Models', ylabel='Query Number')
# ax.fig.suptitle(fontsize=14, t=0.5)
ax.set_titles(size=17)
plt.setp(ax._legend.get_title(), fontsize=14)

# =========================================

# ax.xaxis.get_label().set_fontsize(20)
# plt.legend(title='Victim Model', labels=['BERT', 'RoBERTa'])

# sns.histplot(data=query_num[["bert_medup_bertattack",
#                              "bert_medup_nat",
#                              # "bert_medup_clare"
#                              ]],  multiple="stack")

# sns.histplot(data=query_num,  multiple="stack")
# sns.show()
# print(1)
#
#
#
#
# plt.plot(range(10))
# plt.show()