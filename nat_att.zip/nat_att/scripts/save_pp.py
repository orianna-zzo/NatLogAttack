import os

from config import DATASET_DIR

from utils.data_utils import SnliReader
from utils.text.parse import find_node_and_parent
from collections import Counter
from operator import itemgetter

if __name__ == "__main__":

    p_e = []
    p_n = []
    p_c = []
    h_e = []
    h_n = []
    h_c = []

    reader = SnliReader()
    label_list = reader.label2id_dict.keys()
    data = reader.get_train_examples(DATASET_DIR) # should be train

    for ex in data:
        if ex['gold_label_id'] == -1:
            continue
        p_pp = list(find_node_and_parent(ex['premise_p'], 'PP '))
        h_pp = list(find_node_and_parent(ex['hypothesis_p'], 'PP '))
        label = reader.id2label_dict[ex['gold_label_id']]
        if label == 'entailment':
            p_e.extend(p_pp)
            h_e.extend(h_pp)
        elif label == 'neutral':
            p_n.extend(p_pp)
            h_n.extend(h_pp)
        elif label == 'contradiction':
            p_c.extend(p_pp)
            h_c.extend(h_pp)


    # # p e
    # print("p e start")
    # p_e = Counter(p_e)
    # p_e = sorted(p_e.items(), key=itemgetter(1), reverse=True)
    # print(len(p_e))
    # with open(os.path.join(DATASET_DIR, "p_e_pp.txt"), "w") as writer:
    #     for k in p_e:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('p e done')
    #
    # # p n
    # print("p n start")
    # p_n = Counter(p_n)
    # p_n = sorted(p_n.items(), key=itemgetter(1), reverse=True)
    # print(len(p_n))
    # with open(os.path.join(DATASET_DIR, "p_n_pp.txt"), "w") as writer:
    #     for k in p_n:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('p n done')
    #
    # # p c
    # print("p c start")
    # p_c = Counter(p_c)
    # p_c = sorted(p_c.items(), key=itemgetter(1), reverse=True)
    # print(len(p_c))
    # with open(os.path.join(DATASET_DIR, "p_c_pp.txt"), "w") as writer:
    #     for k in p_c:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('p c done')
    #
    # # h e
    # print("h e start")
    # h_e = Counter(h_e)
    # h_e = sorted(h_e.items(), key=itemgetter(1), reverse=True)
    # print(len(h_e))
    # with open(os.path.join(DATASET_DIR, "h_e_pp.txt"), "w") as writer:
    #     for k in h_e:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('h e done')
    #
    # # h n
    # print("h n start")
    # h_n = Counter(h_n)
    # h_n = sorted(h_n.items(), key=itemgetter(1), reverse=True)
    # print(len(h_n))
    # with open(os.path.join(DATASET_DIR, "h_n_pp.txt"), "w") as writer:
    #     for k in h_n:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('h n done')
    #
    # # h c
    # print("h c start")
    # h_c = Counter(h_c)
    # h_c = sorted(h_c.items(), key=itemgetter(1), reverse=True)
    # print(len(h_c))
    # with open(os.path.join(DATASET_DIR, "h_c_pp.txt"), "w") as writer:
    #     for k in h_c:
    #         if ' ' not in k[0][0] or k[0][0] == '':
    #             continue
    #         writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    # print('h c done')

    # all
    print("all start")
    all = p_e + p_n + p_c + h_e + h_n + h_c
    all = Counter(all)
    all = sorted(all.items(), key=itemgetter(1), reverse=True)
    print(len(all))
    with open(os.path.join(DATASET_DIR, "all_pp.txt"), "w") as writer:
        for k in all:
            if ' ' not in k[0][0] or k[0][0] == '':
                continue
            writer.write("%s\t%s\t%s\n" % (k[0][0], k[0][1], k[1]))
    print('all done')


