# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors and The HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""" Finetuning BERT on SNLI.
    source from `https://github.com/huggingface/transformers/blob/master/examples/run_xnli.py`"""


import argparse
import glob
import logging
import random
import shutil
import os
# os.environ["CUDA_VISIBLE_DEVICES"] = '0'

import numpy as np
import torch
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset
from torch.utils.data.distributed import DistributedSampler
from utils.torch import set_seed, save_model_seperately #, load_features, save_features
from utils.metrics import acc_and_pr
from utils.torch.sampler import BalancedSampler
from tqdm import tqdm, trange
from datetime import datetime

from transformers import (
    WEIGHTS_NAME,
    AdamW,
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    BertConfig, BertForSequenceClassification, BertTokenizer,
    # RobertaConfig, RobertaForSequenceClassification, RobertaTokenizer,
    get_linear_schedule_with_warmup,
)

from transformers import InputExample, InputFeatures
from utils.data_utils import SnliReader, HelpReader, MedReader, MnliReader, SickReader
from config import *
from utils.metrics import acc_and_pr
from utils.logger import print_and_log
# from utils.torch import save_model_seperately

try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    from tensorboardX import SummaryWriter


logger = logging.getLogger(__name__)

# MODEL_CLASSES = {
#     "bert": (BertConfig, BertForSequenceClassification, BertTokenizer),
#     }

class nliProcessor(object):
    def __init__(self):
        pass

    def _bert_examples(self, ex_list):
        """
        Change SnliReader examples to Bert examples
        Delete -1 label ('-')
        :param ex_list: output list of SnliReader
        :return:
        """
        bert_examples = []
        for ex in ex_list:
            if 'gold_label_id' in ex.keys():
                if ex['gold_label_id'] == -1:
                    continue
            guid = ex['guid']
            text_a = ex['premise'].strip()
            text_b = ex['hypothesis'].strip()
            if 'gold_label_id' in ex.keys():
                label = ex['gold_label_id']
            else:
                label = ex['label_id']
            bert_examples.append(
                InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
        return bert_examples


class SnliProcessor(nliProcessor):
    def __init__(self):
        self.reader = SnliReader()

    # def _bert_examples(self, ex_list):
    #     """
    #     Change SnliReader examples to Bert examples
    #     Delete -1 label ('-')
    #     :param ex_list: output list of SnliReader
    #     :return:
    #     """
    #     bert_examples = []
    #     for ex in ex_list:
    #         if 'gold_label_id' in ex.keys():
    #             if ex['gold_label_id'] == -1:
    #                 continue
    #         guid = ex['guid']
    #         text_a = ex['premise'].strip()
    #         text_b = ex['hypothesis'].strip()
    #         if 'gold_label_id' in ex.keys():
    #             label = ex['gold_label_id']
    #         else:
    #             label = ex['label_id']
    #         bert_examples.append(
    #             InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
    #     return bert_examples


    def get_train_examples(self, data_dir):
        return self._bert_examples(self.reader.get_train_examples(data_dir))

    def get_dev_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir))

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()


class SnliMixProcessor(nliProcessor):
    def __init__(self):
        self.reader = SnliReader()
        self.help_reader = HelpReader()
        # self.med_reader = MedReader()

    # def _bert_examples(self, ex_list):
    #     """
    #     Change SnliReader examples to Bert examples
    #     Delete -1 label ('-')
    #     :param ex_list: output list of SnliReader
    #     :return:
    #     """
    #     bert_examples = []
    #     for ex in ex_list:
    #         if 'gold_label_id' in ex.keys():
    #             if ex['gold_label_id'] == -1:
    #                 continue
    #         guid = ex['guid']
    #         text_a = ex['premise'].strip()
    #         text_b = ex['hypothesis'].strip()
    #         if 'gold_label_id' in ex.keys():
    #             label = ex['gold_label_id']
    #         else:
    #             label = ex['label_id']
    #         bert_examples.append(
    #             InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
    #     return bert_examples
    #

    def get_train_examples(self, data_dir):
        return self._bert_examples(self.reader.get_train_examples(data_dir)) \
               + self._bert_examples(self.help_reader.get_test_examples(data_dir))

    def get_dev_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir))

    def get_test_examples(self, data_dir):
        # return self._bert_examples(self.med_reader.get_test_examples(data_dir))
        return self._bert_examples(self.reader.get_test_examples(data_dir))


    def get_labels(self):
        return self.reader.label2id_dict.keys()


class MnliProcessor(nliProcessor):
    def __init__(self):
        self.reader = MnliReader()

    # def _bert_examples(self, ex_list):
    #     """
    #     Change SnliReader examples to Bert examples
    #     Delete -1 label ('-')
    #     :param ex_list: output list of SnliReader
    #     :return:
    #     """
    #     bert_examples = []
    #     for ex in ex_list:
    #         if 'gold_label_id' in ex.keys():
    #             if ex['gold_label_id'] == -1:
    #                 continue
    #         guid = ex['guid']
    #         text_a = ex['premise'].strip()
    #         text_b = ex['hypothesis'].strip()
    #         if 'gold_label_id' in ex.keys():
    #             label = ex['gold_label_id']
    #         else:
    #             label = ex['label_id']
    #         bert_examples.append(
    #             InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
    #     return bert_examples


    def get_train_examples(self, data_dir):
        return self._bert_examples(self.reader.get_train_examples(data_dir))

    def get_dev_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir))

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class SickProcessor(nliProcessor):
    def __init__(self):
        self.reader = SickReader()
        # self.sick_reader = SickReader()
        # self.med_reader = MedReader()

    # def _bert_examples(self, ex_list):
    #     """
    #     Change SnliReader examples to Bert examples
    #     Delete -1 label ('-')
    #     :param ex_list: output list of SnliReader
    #     :return:
    #     """
    #     bert_examples = []
    #     for ex in ex_list:
    #         if 'gold_label_id' in ex.keys():
    #             if ex['gold_label_id'] == -1:
    #                 continue
    #         guid = ex['guid']
    #         text_a = ex['premise'].strip()
    #         text_b = ex['hypothesis'].strip()
    #         if 'gold_label_id' in ex.keys():
    #             label = ex['gold_label_id']
    #         else:
    #             label = ex['label_id']
    #         bert_examples.append(
    #             InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
    #     return bert_examples
    #

    def get_train_examples(self, data_dir):
        return self._bert_examples(self.reader.get_train_examples(data_dir))

    def get_dev_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir))

    def get_test_examples(self, data_dir):
        # return self._bert_examples(self.med_reader.get_test_examples(data_dir))
        return self._bert_examples(self.reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()


class SickMixProcessor(nliProcessor):
    def __init__(self):
        self.reader = SnliReader()
        self.sick_reader = SickReader()
        # self.med_reader = MedReader()

    # def _bert_examples(self, ex_list):
    #     """
    #     Change SnliReader examples to Bert examples
    #     Delete -1 label ('-')
    #     :param ex_list: output list of SnliReader
    #     :return:
    #     """
    #     bert_examples = []
    #     for ex in ex_list:
    #         if 'gold_label_id' in ex.keys():
    #             if ex['gold_label_id'] == -1:
    #                 continue
    #         guid = ex['guid']
    #         text_a = ex['premise'].strip()
    #         text_b = ex['hypothesis'].strip()
    #         if 'gold_label_id' in ex.keys():
    #             label = ex['gold_label_id']
    #         else:
    #             label = ex['label_id']
    #         bert_examples.append(
    #             InputExample(guid=guid, text_a=text_a, text_b=text_b, label=label))
    #     return bert_examples
    #

    def get_train_examples(self, data_dir):
        return self._bert_examples(self.reader.get_train_examples(data_dir)) \
               + self._bert_examples(self.sick_reader.get_test_examples(data_dir))

    def get_dev_examples(self, data_dir):
        return self._bert_examples(self.reader.get_dev_examples(data_dir)) \
               + self._bert_examples(self.sick_reader.get_dev_examples(data_dir))

    def get_test_examples(self, data_dir):
        # return self._bert_examples(self.med_reader.get_test_examples(data_dir))
        return self._bert_examples(self.sick_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class MedProcessor(nliProcessor):
    def __init__(self):
        self.reader = MedReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_test_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class MedUpProcessor(nliProcessor):
    def __init__(self):
        self.reader = MedReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_up_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class MedDownProcessor(nliProcessor):
    def __init__(self):
        self.reader = MedReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_down_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()


class HelpProcessor(nliProcessor):
    def __init__(self):
        self.reader = HelpReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_test_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class HelpUpProcessor(nliProcessor):
    def __init__(self):
        self.reader = HelpReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_up_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()

class HelpDownProcessor(nliProcessor):
    def __init__(self):
        self.reader = HelpReader()

    def get_test_examples(self, data_dir):
        return self._bert_examples(self.reader.get_down_examples(data_dir))
        # return self._bert_examples(self.snli_reader.get_test_examples(data_dir))

    def get_labels(self):
        return self.reader.label2id_dict.keys()


processors = {
    'snli': SnliProcessor,
    'snlimix': SnliMixProcessor,
    'med': MedProcessor,
    'medup': MedUpProcessor,
    'meddown': MedDownProcessor,
    'help': HelpProcessor,
    'helpup': HelpUpProcessor,
    'helpdown': HelpDownProcessor,
    'sick': SickProcessor,
    'sickmix': SickMixProcessor,
    'mnli': MnliProcessor
}

output_modes= {
    "snli": "classification",
    'snlimix': "classification",
    'med': "classification",
    'medup': "classification",
    'meddown': "classification",
    'help': "classification",
    'helpup': "classification",
    'helpdown': "classification",
    'sick': "classification",
    "sickmix": "classification",
    'mnli': "classification"
}

three_label_datasets = ['snli', 'snlimix', 'sick', 'sickmix', 'mnli']

def get_performance(preds, label_ids, id2label_dict):
    results = {}
    result = acc_and_pr(preds, label_ids, id2label_dict)
    # result = simple_accuracy(preds, label_ids)
    results.update(result)
    return results

def convert_examples_to_features(examples, tokenizer,
                                 max_length=512,
                                 task=None,
                                 label_list=None,
                                 output_mode=None,
                                 pad_on_left=False,
                                 pad_token=0,
                                 pad_token_segment_id=0,
                                 mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``

    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)

    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.

    """

    if task is not None:
        processor = processors[task]()
        if label_list is None:
            label_list = processor.get_labels()
            logger.info("Using label list %s for task %s" % (label_list, task))
        if output_mode is None:
            output_mode = output_modes[task]
            logger.info("Using output mode %s for task %s" % (output_mode, task))

    # label_map = {label: i for i, label in enumerate(label_list)}

    features = []
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Writing example %d" % (ex_index))


        inputs = tokenizer.encode_plus(
            example.text_a,
            example.text_b,
            add_special_tokens=True,
            # return_token_type_ids=True,
            max_length=max_length,
        )

        input_ids = inputs["input_ids"]
        if 'token_type_ids' in inputs.keys():
            token_type_ids = inputs["token_type_ids"]
        else:
            len_a = len(tokenizer.encode(example.text_a))
            if len_a < max_length:
                token_type_ids = [0] * len_a + [1] * (len(input_ids) - len_a)
            else:
                token_type_ids = [0] * max_length
        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        attention_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_mask

            token_type_ids = ([pad_token_segment_id] * padding_length) + token_type_ids
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)

            token_type_ids = token_type_ids + ([pad_token_segment_id] * padding_length)

        assert len(input_ids) == max_length, "Error with input length {} vs {}".format(len(input_ids), max_length)
        assert len(attention_mask) == max_length, "Error with input length {} vs {}".format(len(attention_mask), max_length)
        assert len(token_type_ids) == max_length, "Error with input length {} vs {}".format(len(token_type_ids), max_length)

        # if output_mode == "classification":
        #     label = label_map[example.label]
        # elif output_mode == "regression":
        #     label = float(example.label)
        # else:
        #     raise KeyError(output_mode)
        label = example.label

        if ex_index < 5:
            logger.info("*** Example ***")
            logger.info("guid: %s" % (example.guid))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_mask: %s" % " ".join([str(x) for x in attention_mask]))
            logger.info("token_type_ids: %s" % " ".join([str(x) for x in token_type_ids]))
            logger.info("label: %s (id = %d)" % (example.label, label))

        # if ex_index == 84:
        #     print(ex_index)
        features.append(
            InputFeatures(input_ids=input_ids,
                          attention_mask=attention_mask,
                          token_type_ids=token_type_ids,
                          label=label))

    return features
#
# def set_seed(args):
#     random.seed(args.seed)
#     np.random.seed(args.seed)
#     torch.manual_seed(args.seed)
#     if args.n_gpu > 0:
#         torch.cuda.manual_seed_all(args.seed)



# def train(args, model, train_dataset, dev_dataset=None, test_dataset=None, aux_dataset=None):
def train(args, model, tokenizer, train_dataset, dev_dataset=None, test_dataset=None):
    # Check params value
    if args.do_dev and dev_dataset is None:
        raise ValueError("Missing dev dataset while do eval")
    if args.do_test and test_dataset is None:
        raise ValueError("Missing test dataset while do test")

    tb_writer = SummaryWriter(log_dir=args.tensorboard_log_path)
    # tb_writer = SummaryWriter()

    # args.train_batch_size = args.train_batch_size_per_gpu * max(1, args.n_gpu)
    train_dataloader = DataLoader(train_dataset, batch_size=args.train_batch_size, shuffle=True)
    # if aux_dataset is not None:
    #     sampler = BalancedSampler(aux_dataset, aux_dataset.get_classed_index(), max_n=3, max_ratio=1)
    #     aux_dataloader = DataLoader(aux_dataset, batch_size=args.aux_batch_size, sampler=sampler)

    if args.warmup_steps > 0:
        warmup_steps = args.warmup_steps
    elif args.warmup_ratio > 0:
        warmup_steps = int(len(train_dataloader) * args.warmup_ratio)
    else:
        warmup_steps = 0

    if args.max_steps > 0:
        t_total = args.max_steps
        args.num_train_epochs = args.max_steps // (len(train_dataloader) // args.gradient_accumulation_steps) + 1
    else:
        t_total = len(train_dataloader) // args.gradient_accumulation_steps * args.num_train_epochs

    # Prepare optimizer and schedule (linear warmup and decay)
    # optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate,
    #                              eps=args.adam_epsilon, weight_decay=args.weight_decay)
    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
        },
        {"params": [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], "weight_decay": 0.0},
    ]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)

    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=warmup_steps, num_training_steps=t_total
    )

    # multi-gpu training (should be after apex fp16 initialization)
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)

    # Train
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_dataset))
    logger.info("  Num Epochs = %d", args.num_train_epochs)
    logger.info("  Train batch size = %d", args.train_batch_size)
    logger.info("  Gradient Accumulation steps = %d", args.gradient_accumulation_steps)
    logger.info("  Total optimization steps = %d", t_total)

    global_step = 0
    epochs_trained = 0
    steps_trained_in_current_epoch = 0

    # Check if continuing training from a checkpoint
    if args.train_from_checkpoint is not None:
        if os.path.exists(args.train_from_checkpoint):
            # set global_step to gobal_step of last saved checkpoint from model path
            global_step = int(args.train_from_checkpoint.split("-")[-1].split("/")[0])
            epochs_trained = global_step // (len(train_dataloader) // args.gradient_accumulation_steps)
            steps_trained_in_current_epoch = global_step % (len(train_dataloader) // args.gradient_accumulation_steps)

            logger.info("  Continuing training from checkpoint, will skip to saved global_step")
            logger.info("  Continuing training from epoch %d", epochs_trained)
            logger.info("  Continuing training from global step %d", global_step)
            logger.info("  Will skip the first %d steps in the first epoch", steps_trained_in_current_epoch)

            # Check if saved optimizer or scheduler states exist
            if (os.path.isfile(os.path.join(args.train_from_checkpoint, "optimizer.pt")) and
                    os.path.isfile(os.path.join(args.train_from_checkpoint, "scheduler.pt"))):
                # Load in optimizer and scheduler states
                optimizer.load_state_dict(torch.load(os.path.join(args.model_name_or_path, "optimizer.pt")))
                scheduler.load_state_dict(torch.load(os.path.join(args.model_name_or_path, "scheduler.pt")))
                logger.info("  Loading saved optimizer and scheduler")
            else:
                raise ValueError("Not find the optimizer and scheduler from %s" % args.train_from_checkpoint)

            if os.path.isfile(os.path.join(args.train_from_checkpoint, "pytorch_model.bin")):
                model.load_state_dict(torch.load(os.path.join(args.train_from_checkpoint, "pytorch_model.bin")))
            else:
                raise ValueError("Not find the saved model from %s" % args.train_from_checkpoint)

        else:
            raise ValueError("Not find the checkpoint from %s" % args.train_from_checkpoint)

    tr_loss, logging_loss = 0.0, 0.0
    model.zero_grad()
    train_iterator = trange(epochs_trained, int(args.num_train_epochs), desc="Epoch")
    set_seed(args.seed)  # Added here for reproductibility

    patience_counter = 0
    best_score = 0


    for _ in train_iterator:
        epoch_iterator = tqdm(train_dataloader, desc="Iteration")
        preds = None
        label_ids = None
        for step, batch in enumerate(epoch_iterator):
            # Skip past any already trained steps if resuming training
            if steps_trained_in_current_epoch > 0:
                steps_trained_in_current_epoch -= 1
                continue

            # if args.loss_method == "mixed":
            #     if global_step > args.start_mixed and np.random.random() < min(global_step/args.max_mixed, args.focus):
            #         method = "max"
            #     else:
            #         method = "sum"
            # else:
            #     method = args.loss_method
            # # method = "max"

            model.train()
            # loss_aux = (0,0,0,0,0)
            # if aux_dataset is not None and np.random.random() > min(global_step / t_total, args.focus):
            #
            #     aux_batch = iter(aux_dataloader).__next__()
            #     # model.train()
            #
            #     inputs_aux = {"premise_ids": aux_batch["word_a_token_ids"].to(args.device),
            #                   "premise_lengths": aux_batch["word_a_lengths"].to(args.device),
            #                   "premise_masks": get_mask_by_sequence_length(aux_batch["word_a_token_ids"], aux_batch["word_a_lengths"]).to(args.device),
            #                   "hypothesis_ids": aux_batch["word_b_token_ids"].to(args.device),
            #                   "hypothesis_lengths": aux_batch["word_b_lengths"].to(args.device),
            #                   "hypothesis_masks": get_mask_by_sequence_length(aux_batch["word_b_token_ids"], aux_batch["word_b_lengths"]).to(args.device),
            #                   "label_ids": torch.tensor(aux_batch["label_ids"], dtype=int).to(args.device),
            #                   "basic_rel": True}
            #     outputs_aux = model(**inputs_aux)
            #     loss_aux = outputs_aux[0]
            batch = tuple(t.to(args.device) for t in batch)
            inputs = {"input_ids": batch[0],
                      "attention_mask": batch[1],
                      'token_type_ids': batch[2] if args.model_type in ['bert'] else None,
                      "labels": batch[3]}
            # if args.model_type != "distilbert":
            #     inputs["token_type_ids"] = (
            #         batch[2] if args.model_type in ["bert"] else None
            #     )  # XLM and DistilBERT don't use segment_ids


            outputs = model(**inputs)
            # loss_main = outputs[0]
            # loss_all = loss_aux[0] + loss_main[0]
            loss = outputs[0]  # model outputs are always tuple in transformers (see doc)

            if args.n_gpu > 1:
                loss = loss.mean()  # mean() to average on multi-gpu parallel training
            if args.gradient_accumulation_steps > 1:
                # loss_all = loss_all / args.gradient_accumulation_steps
                loss = loss / args.gradient_accumulation_steps

            # loss_all.backward()
            loss.backward()

            # tr_loss += loss_all.item()
            tr_loss += loss.item()

            # train set eval
            logits = outputs[1]
            # if preds is None:
            #     preds = outputs[-1].detach().cpu().numpy()
            #     label_ids = inputs["label_ids"].detach().cpu().numpy()
            # else:
            #     preds = np.append(preds, outputs[-1].detach().cpu().numpy(), axis=0)
            #     label_ids = np.append(label_ids, inputs["label_ids"].detach().cpu().numpy(), axis=0)
            if preds is None:
                preds = logits.detach().cpu().numpy()
                out_label_ids = inputs["labels"].detach().cpu().numpy()
            else:
                preds = np.append(preds, logits.detach().cpu().numpy(), axis=0)
                out_label_ids = np.append(out_label_ids, inputs["labels"].detach().cpu().numpy(), axis=0)


            if (step + 1) % args.gradient_accumulation_steps == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

                optimizer.step()
                scheduler.step()  # Update learning rate schedule
                model.zero_grad()
                global_step += 1

            if args.logging_steps > 0 and global_step % args.logging_steps == 0:
                # Log metrics
                # train set eval
                preds = np.argmax(preds, axis=1)
                # results = get_performance(preds, label_ids.squeeze(), args.id2label_dict)
                results = get_performance(preds, out_label_ids, args.id2label_dict)
                for key, value in results.items():
                    if key == "f1":
                        continue
                    tb_writer.add_scalar("train_{}".format(key), value, global_step)
                # scheduler.step(results["acc"])

                if args.do_dev:
                    # if args.evaluate_during_training:
                    # dev set eval
                    logger.info("=> DEV")
                    results_dev = evaluate(args, model, tokenizer, "dev", prefix=str(global_step))
                    for key, value in results_dev.items():
                        if key == "f1":
                            continue
                        tb_writer.add_scalar("dev_{}".format(key), value, global_step)
                    # tb_writer.add_scalar("dev_loss", eval_loss, global_step)
                    dev_score = results_dev["acc"]

                if args.do_test:
                    # test set eval
                    logger.info("=> TEST")
                    results_test = evaluate(args, model, tokenizer, "test", prefix=str(global_step))
                    for key, value in results_test.items():
                        if key == "f1":
                            continue
                        tb_writer.add_scalar("test_{}".format(key), value, global_step)
                    # tb_writer.add_scalar("test_loss", eval_loss, global_step)

                # lr = scheduler.optimizer.param_groups[0]['lr']
                lr = scheduler.get_lr()[0]
                tb_writer.add_scalar("lr", lr, global_step)
                tb_writer.add_scalar("train_loss", (tr_loss - logging_loss) / args.logging_steps, global_step)

                tb_writer.add_scalar("train_ce_loss", loss, global_step)

                logger.info("========== global step {}, lr {} ==========".format(global_step, lr))
                logger.info("    loss: {}".format(loss))
                logger.info("")
                logging_loss = tr_loss
                preds = None

                # Early stopping on validation f1.
                if args.do_dev and args.early_stop > 0:
                    if dev_score < best_score:
                        patience_counter += 1
                    else:
                        best_score = dev_score
                        patience_counter = 0
                    if patience_counter >= args.early_stop:
                        logger.info(
                            "-> Early stopping: patience limit {} reached, stopping...".format(args.early_stop))

                        # Save the best model and return
                        output_dir = os.path.join(args.output_dir, "checkpoint-{}".format(global_step))
                        save_model_seperately(model, output_dir, args, optimizer, scheduler)
                        epoch_iterator.close()
                        train_iterator.close()
                        tb_writer.close()
                        return global_step, tr_loss / global_step

            if args.save_steps > 0 and global_step % args.save_steps == 0:
                # Save model checkpoint
                output_dir = os.path.join(args.output_dir, "checkpoint-{}".format(global_step))
                save_model_seperately(model, output_dir, args, optimizer, scheduler)

            if args.max_steps > 0 and global_step > args.max_steps:
                epoch_iterator.close()
                break

        if args.max_steps > 0 and global_step > args.max_steps:
            train_iterator.close()
            break

    tb_writer.close()

    return global_step, tr_loss / global_step



def evaluate(args, model, tokenizer, stage_dataset, prefix=""):
    assert stage_dataset in ["train", "dev", "test"]
    eval_task_names = (args.task_name,)
    eval_outputs_dirs = (args.output_dir,)

    # results = {}
    for eval_task, eval_output_dir in zip(eval_task_names, eval_outputs_dirs):
        eval_dataset = load_and_cache_examples(args, eval_task, tokenizer, stage_dataset)

        if not os.path.exists(eval_output_dir) and args.local_rank in [-1, 0]:
            os.makedirs(eval_output_dir)

        # args.eval_batch_size = args.per_gpu_eval_batch_size * max(1, args.n_gpu)
        # Note that DistributedSampler samples randomly
        eval_sampler = SequentialSampler(eval_dataset)
        eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler, batch_size=args.eval_batch_size)

        # multi-gpu eval
        if args.n_gpu > 1:
            model = torch.nn.DataParallel(model)

        # Eval!
        logger.info("***** Running evaluation on {}: {} *****".format(stage_dataset, prefix))
        logger.info("  Num examples = %d", len(eval_dataset))
        logger.info("  Batch size = %d", args.eval_batch_size)
        eval_loss = 0.0
        nb_eval_steps = 0
        preds = None
        out_label_ids = None
        for batch in tqdm(eval_dataloader, desc="Evaluating"):
            model.eval()
            batch = tuple(t.to(args.device) for t in batch)

            with torch.no_grad():
                inputs = {"input_ids": batch[0],
                          "attention_mask": batch[1],
                          'token_type_ids': batch[2] if args.model_type in ['bert'] else None,
                          "labels": batch[3]}

                outputs = model(**inputs)
                tmp_eval_loss, logits = outputs[:2]

                eval_loss += tmp_eval_loss.mean().item()
            nb_eval_steps += 1
            if preds is None:
                preds = logits.detach().cpu().numpy()
                out_label_ids = inputs["labels"].detach().cpu().numpy()
            else:
                preds = np.append(preds, logits.detach().cpu().numpy(), axis=0)
                out_label_ids = np.append(out_label_ids, inputs["labels"].detach().cpu().numpy(), axis=0)

        eval_loss = eval_loss / nb_eval_steps
        if args.output_mode == "classification":
            preds = np.argmax(preds, axis=1)
        else:
            raise ValueError("No other `output_mode` for XNLI.")
        # result = {"acc": simple_accuracy(preds, out_label_ids)}
        # results.update(result)
        if args.task_name not in three_label_datasets:
            # only two labels
            preds = [0 if int(i)==0 else 1 for i in preds]

        results = get_performance(preds, out_label_ids, args.id2label_dict)
        results.update({"loss": eval_loss})

        output_eval_file = os.path.join(eval_output_dir, prefix, stage_dataset + "eval_results.txt")
        if not os.path.exists(os.path.join(eval_output_dir, prefix)):
            os.makedirs(os.path.join(eval_output_dir, prefix))

        np.savetxt(os.path.join(eval_output_dir, prefix, args.run_name + "_"+ args.task_name + "_eval_id.csv"),
                   np.append(np.expand_dims(preds, axis=1),np.expand_dims(out_label_ids, axis=1), axis=1), fmt="%d", delimiter="\t")

        with open(output_eval_file, "w") as writer:
            logger.info("***** Eval results on {}: {} *****".format(stage_dataset, prefix))
            for key in sorted(results.keys()):
                logger.info("  %s = %s", key, str(results[key]))
                writer.write("%s = %s\n" % (key, str(results[key])))

    return results


def load_and_cache_examples(args, task, tokenizer, stage):
    assert stage in ["train", "dev", "test"]
    if args.local_rank not in [-1, 0] and stage == "train":
        torch.distributed.barrier()  # Make sure only the first process in distributed training process the dataset, and the others will use the cache

    processor = processors[task]()
    output_mode = output_modes[task]
    # Load data features from cache or dataset file
    cached_features_file = os.path.join(
        args.data_dir,
        "cached_{}_{}_{}_{}".format(
            stage,
            list(filter(None, args.model_name_or_path.split("/"))).pop(),
            str(args.max_seq_length),
            str(task)
        )
    )
    if os.path.exists(cached_features_file) and not args.overwrite_cache:
        logger.info("Loading features from cached file %s", cached_features_file)
        features = torch.load(cached_features_file)
    else:
        logger.info("Creating features from dataset file at %s", args.data_dir)
        label_list = processor.get_labels()
        if stage == "train":
            examples = processor.get_train_examples(args.data_dir)
        elif stage == "dev":
            examples = processor.get_dev_examples(args.data_dir)
        elif stage == "test":
            examples = processor.get_test_examples(args.data_dir)

        features = convert_examples_to_features(
            examples,
            tokenizer,
            label_list=label_list,
            max_length=args.max_seq_length,
            output_mode=output_mode,
            pad_on_left=False,
            pad_token=tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0],
            pad_token_segment_id=0,
        )
        if args.local_rank in [-1, 0]:
            logger.info("Saving features into cached file %s", cached_features_file)
            torch.save(features, cached_features_file)

    if args.local_rank == 0 and not stage == "train":
        torch.distributed.barrier()  # Make sure only the first process in distributed training process the dataset, and the others will use the cache

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    all_token_type_ids = torch.tensor([f.token_type_ids for f in features], dtype=torch.long)
    if output_mode == "classification":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.long)
    else:
        raise ValueError("No other `output_mode` for XNLI.")

    dataset = TensorDataset(all_input_ids, all_attention_mask, all_token_type_ids, all_labels)
    return dataset


def main():
    parser = argparse.ArgumentParser()

    # Required parameters
    parser.add_argument(
        "--data_dir",
        default=os.path.join(DATASET_DIR),
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )
    parser.add_argument(
        "--model_name_or_path",
        default='roberta-base', #os.path.join(BERT_BASE_CASED_DIR, 'bert-base-cased-pytorch_model.bin'), bert-base-uncased
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )
    parser.add_argument(
        "--model_type",
        default='roberta', #os.path.join(BERT_BASE_CASED_DIR, 'bert-base-cased-pytorch_model.bin'), bert-base-uncased
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )
    # parser.add_argument(
    #     "--config_name", default=os.path.join(BERT_BASE_CASED_DIR, 'bert-base-cased-config.json'), type=str, help="Pretrained config name or path if not the same as model_name"
    # )
    parser.add_argument(
        "--config_name", default='roberta-base', type=str, help="Pretrained config name or path if not the same as model_name"
    )# roberta-base   'bert-base-uncased'
    # parser.add_argument(
    #     "--tokenizer_name",
    #     default=os.path.join(BERT_BASE_CASED_DIR, 'bert-base-cased-vocab.txt'),
    #     type=str,
    #     help="Pretrained tokenizer name or path if not the same as model_name",
    # )
    parser.add_argument(
        "--tokenizer_name",
        default='roberta-base',  #  bert-base-uncased
        type=str,
        help="Pretrained tokenizer name or path if not the same as model_name",
    )
    parser.add_argument(
        "--output_dir",
        default=os.path.join(CHECKPOINT_DIR, 'mnli', 'roberta'),
        type=str,
        # required=True,
        help="The output directory where the model predictions and checkpoints will be written.",
    )
    parser.add_argument(
        "--log_dir",
        default=os.path.join(LOG_DIR, 'running_log', 'mnli'),
        type=str,
        # required=True,
        help="The output log directory where the model predictions and checkpoints will be written.",
    )
    parser.add_argument(
        "--tensorboard_dir", default=TENSORBOARD_DIR, type=str,
        help="tensorboard log directory"
    )

    # Other parameters

    parser.add_argument(
        "--cache_dir",
        default=CACHE_DIR,
        type=str,
        help="Where do you want to store the pre-trained bert models downloaded from s3",
    )
    parser.add_argument(
        "--max_seq_length",
        default=128,
        type=int,
        help="The maximum total input sequence length after tokenization. Sequences longer "
             "than this will be truncated, sequences shorter will be padded.",
    )
    parser.add_argument("--task_name", default="mnli", help="snli, snlimix, mnli, sick" )
    parser.add_argument("--do_train", action="store_true", help="Whether to run training.")
    parser.add_argument("--do_dev", action="store_true", help="Whether to run eval on the dev set.")
    parser.add_argument("--do_test", action="store_true", help="Whether to run eval on the test set.")
    # parser.add_argument(
    #     "--evaluate_during_training", action="store_true", help="Run evaluation during training at each logging step."
    # )
    parser.add_argument("--early_stop", default=30, help="How many eval times doing early stop, 0 means no early stop")

    # parser.add_argument(
    #     "--do_lower_case", action="store_true", help="Set this flag if you are using an uncased model."
    # )
    parser.add_argument("--train_from_checkpoint", default=None, help="Start training from an existing checkpoint")
    parser.add_argument("--train_batch_size", default=64, type=int, help="Batch size for training.")
    parser.add_argument("--eval_batch_size", default=64, type=int, help="Batch size for dev/test.")

    # parser.add_argument("--train_batch_size_per_gpu", default=32, type=int, help="Batch size per GPU/CPU for training.")
    # parser.add_argument(
    #     "--eval_batch_size_per_gpu", default=32, type=int, help="Batch size per GPU/CPU for evaluation."
    # )
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=1,
        help="Number of updates steps to accumulate before performing a backward/update pass.",
    )
    parser.add_argument("--learning_rate", default=3e-5, type=float, help="The initial learning rate for Adam.")
    parser.add_argument("--dropout", default=0.1, type=float, help="Dropout rate for training.")

    parser.add_argument("--weight_decay", default=0.0, type=float, help="Weight deay if we apply some.")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float, help="Epsilon for Adam optimizer.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")
    parser.add_argument(
        "--num_train_epochs", default=5.0, type=float, help="Total number of training epochs to perform."
    )
    parser.add_argument(
        "--max_steps",
        default=-1,
        type=int,
        help="If > 0: set total number of training steps to perform. Override num_train_epochs.",
    )
    parser.add_argument("--warmup_steps", default=0, type=int, help="Linear warmup over warmup_steps.")
    parser.add_argument("--warmup_ratio", default=0.1, type=int, help="Linear warmup over warmup_steps.")

    parser.add_argument("--save_steps", type=int, default=1000, help="Save checkpoint every X updates steps.")
    parser.add_argument(
        "--eval_all_checkpoints",
        action="store_true",
        help="Evaluate all checkpoints starting with the same prefix as model_name ending and ending with step number",
    )
    parser.add_argument("--no_cuda", action="store_true", help="Avoid using CUDA when available")
    parser.add_argument(
        "--overwrite_output_dir", action="store_true", help="Overwrite the content of the output directory"
    )
    parser.add_argument(
        "--overwrite_cache", action="store_true", help="Overwrite the cached training and evaluation sets"
    )
    parser.add_argument("--seed", type=int, default=42, help="random seed for initialization")
    # set up log
    parser.add_argument("--logging_steps", type=int, default=1000, help="Log every X updates steps.")
    parser.add_argument("--run_name", default="roberta-snli-" + datetime.now().strftime("%m-%d_%H-%M"),
                        type=str, help="Name this run. run_name wil be used in tensorboard log and log file")

    parser.add_argument(
        "--fp16",
        action="store_true",
        help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit",
    )
    parser.add_argument(
        "--fp16_opt_level",
        type=str,
        default="O1",
        help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3']."
             "See details at https://nvidia.github.io/apex/amp.html",
    )
    parser.add_argument("--local_rank", type=int, default=-1, help="For distributed training: local_rank")
    parser.add_argument("--server_ip", type=str, default="", help="For distant debugging.")
    parser.add_argument("--server_port", type=str, default="", help="For distant debugging.")
    args = parser.parse_args()

    args.output_dir = os.path.join(args.output_dir, args.run_name)

    if (
            os.path.exists(args.output_dir)
            and os.listdir(args.output_dir)
            and args.do_train
            and not args.overwrite_output_dir
    ):
        raise ValueError(
            "Output directory ({}) already exists and is not empty. Use --overwrite_output_dir to overcome.".format(
                args.output_dir
            )
        )

    # Setup distant debugging if needed
    if args.server_ip and args.server_port:
        # Distant debugging - see https://code.visualstudio.com/docs/python/debugging#_attach-to-a-local-script
        import ptvsd

        print("Waiting for debugger attach")
        ptvsd.enable_attach(address=(args.server_ip, args.server_port), redirect_output=True)
        ptvsd.wait_for_attach()

    # Setup CUDA, GPU & distributed training
    if args.local_rank == -1 or args.no_cuda:
        device = torch.device("cuda" if torch.cuda.is_available() and not args.no_cuda else "cpu")
        args.n_gpu = torch.cuda.device_count()
    else:  # Initializes the distributed backend which will take care of sychronizing nodes/GPUs
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        torch.distributed.init_process_group(backend="nccl")
        args.n_gpu = 1
    args.device = device

    # Setup logging
    # logging.basicConfig(
    #     format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    #     datefmt="%m/%d/%Y %H:%M:%S",
    #     level=logging.INFO if args.local_rank in [-1, 0] else logging.WARN,
    # )
    logger = logging.getLogger()
    logger.setLevel(logging.INFO if args.local_rank in [-1, 0] else logging.WARN)
    log_path = os.path.join(args.log_dir, args.run_name, "bert-snli.log")
    logger = print_and_log(logger, log_path)
    logger = logging.getLogger(__name__)

    # Setup Tensorboad Run Name
    args.tensorboard_log_path = os.path.join(args.tensorboard_dir, args.run_name)

    logger.warning(
        "Process rank: %s, device: %s, n_gpu: %s, distributed training: %s, 16-bits training: %s",
        args.local_rank,
        device,
        args.n_gpu,
        bool(args.local_rank != -1),
        args.fp16,
    )

    # Set seed
    set_seed(args.seed)

    # Prepare SNLI task
    # args.task_name = "snli"
    if args.task_name not in processors:
        raise ValueError("Task not found: %s" % (args.task_name))
    processor = processors[args.task_name]()
    args.id2label_dict = processor.reader.id2label_dict
    args.output_mode = output_modes[args.task_name]
    label_list = processor.get_labels()
    num_labels = len(label_list)

    # Load pretrained model and tokenizer
    if args.local_rank not in [-1, 0]:
        torch.distributed.barrier()  # Make sure only the first process in distributed training will download model & vocab

    config = AutoConfig.from_pretrained(
        args.config_name if args.config_name else args.model_name_or_path,
        num_labels=num_labels,
        finetuning_task=args.task_name,
        cache_dir=args.cache_dir if args.cache_dir else None,
        hidden_dropout_prob=args.dropout,
    )
    # tokenizer = AutoTokenizer.from_pretrained(args.config_name if args.config_name else args.model_name_or_path, use_fast=False)
    tokenizer = AutoTokenizer.from_pretrained(
        args.tokenizer_name if args.tokenizer_name else args.model_name_or_path,
        # do_lower_case=args.do_lower_case,
        cache_dir=args.cache_dir if args.cache_dir else None,
    )
    # model = AutoModelForSequenceClassification.from_config(config)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name_or_path,
        from_tf=bool(".ckpt" in args.model_name_or_path),
        config=config,
        cache_dir=args.cache_dir if args.cache_dir else None,
    )
    # config = BertConfig.from_pretrained(
    #     args.config_name if args.config_name else args.model_name_or_path,
    #     num_labels=num_labels,
    #     finetuning_task=args.task_name,
    #     cache_dir=args.cache_dir if args.cache_dir else None,
    #     hidden_dropout_prob=args.dropout,
    # )
    # # tokenizer = AutoTokenizer.from_pretrained(args.config_name if args.config_name else args.model_name_or_path, use_fast=False)
    # tokenizer = BertTokenizer.from_pretrained(
    #     args.tokenizer_name if args.tokenizer_name else args.model_name_or_path,
    #     do_lower_case=args.do_lower_case,
    #     cache_dir=args.cache_dir if args.cache_dir else None,
    # )
    # # model = AutoModelForSequenceClassification.from_config(config)
    # model = BertForSequenceClassification.from_pretrained(
    #     args.model_name_or_path,
    #     from_tf=bool(".ckpt" in args.model_name_or_path),
    #     config=config,
    #     cache_dir=args.cache_dir if args.cache_dir else None,
    # )

    if args.local_rank == 0:
        torch.distributed.barrier()  # Make sure only the first process in distributed training will download model & vocab

    model.to(args.device)

    # # Copy file
    # if args.do_train:
    #     bk_dir = os.path.join(BK_DIR, args.run_name)
    #     if not os.path.exists(bk_dir):
    #         os.mkdir(bk_dir)
    #     filelist = ["scripts", "utils", "config"]
    #     for file_dir in filelist:
    #         shutil.copytree(os.path.join(BASE_DIR, file_dir), os.path.join(bk_dir, file_dir))

    logger.info("Training/evaluation parameters %s", args)

    # Training
    if args.do_train:
        train_dataset = load_and_cache_examples(args, args.task_name, tokenizer, "train")

        dev_dataset = None
        test_dataset = None
        if args.do_dev:
            dev_dataset = load_and_cache_examples(args, args.task_name, tokenizer, "dev")
        if args.do_test:
            test_dataset = load_and_cache_examples(args, args.task_name, tokenizer, "test")

        global_step, tr_loss = train(args, model, tokenizer, train_dataset, dev_dataset, test_dataset)
        logger.info(" global_step = %s, average loss = %s", global_step, tr_loss)

    # Saving best-practices: if you use defaults names for the model, you can reload it using from_pretrained()
    if args.do_train and (args.local_rank == -1 or torch.distributed.get_rank() == 0):
        # Create output directory if needed
        if not os.path.exists(args.output_dir) and args.local_rank in [-1, 0]:
            os.makedirs(args.output_dir)

        logger.info("Saving model checkpoint to %s", args.output_dir)
        # Save a trained model, configuration and tokenizer using `save_pretrained()`.
        # They can then be reloaded using `from_pretrained()`
        model_to_save = (
            model.module if hasattr(model, "module") else model
        )  # Take care of distributed/parallel training
        model_to_save.save_pretrained(args.output_dir)
        tokenizer.save_pretrained(args.output_dir)

        # Good practice: save your training arguments together with the trained model
        torch.save(args, os.path.join(args.output_dir, "training_args.bin"))

        # Load a trained model and vocabulary that you have fine-tuned
        model = AutoModelForSequenceClassification.from_pretrained(args.output_dir)
        tokenizer = AutoTokenizer.from_pretrained(args.output_dir)
        model.to(args.device)

    # Evaluation
    results = {}
    if args.do_test and not args.do_train and args.local_rank in [-1, 0]:
        tokenizer = AutoTokenizer.from_pretrained(args.output_dir)
        checkpoints = [args.output_dir]
        if args.eval_all_checkpoints:
            checkpoints = list(
                os.path.dirname(c) for c in sorted(glob.glob(args.output_dir + "/**/" + WEIGHTS_NAME, recursive=True))
            )
            logging.getLogger("transformers.modeling_utils").setLevel(logging.WARN)  # Reduce logging
        logger.info("Evaluate the following checkpoints: %s", checkpoints)
        for checkpoint in checkpoints:
            global_step = checkpoint.split("-")[-1] if len(checkpoints) > 1 else ""
            prefix = checkpoint.split("/")[-1] if checkpoint.find("checkpoint") != -1 else ""

            model = AutoModelForSequenceClassification.from_pretrained(checkpoint)
            model.to(args.device)
            result = evaluate(args, model, tokenizer, "test", prefix=prefix)
            result = dict((k + "_{}".format(global_step), v) for k, v in result.items())
            results.update(result)

    return results


if __name__ == "__main__":
    main()