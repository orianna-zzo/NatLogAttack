import os
import openai
import argparse
from datetime import datetime
import dill as pickle
from tqdm import tqdm

from config import *
from utils.data_utils import MedReader, SnliReader, SickReader


def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

def data2text(data):
    template = "Pair {pair_n}: {{s1: \"{s1}\"\t\ts2: \"{s2}\"}}\n"
    text = ""
    for d in data:
        text += template.format(pair_n=d['index'], s1=d['premise'], s2=d['hypothesis'])
    return text

def config_param():
    parser = argparse.ArgumentParser()
    # Required parameters

    parser.add_argument(
        "--data_dir",
        default=DATASET_DIR,
        type=str,
        # required=True,
        help="The input data dir. Should contain the .tsv files (or other data files) for the task.",
    )

    parser.add_argument(
        "--sample_name",
        default="med_down_chosen.txt",  # med_down_chosen.txt
        type=str,
        # required=True,
        help="",
    )

    parser.add_argument(
        "--data",
        default="med",  #med, snli, sick
        type=str,
        # required=True,
        help="",
    )

    parser.add_argument(
        "--group",
        action="store_true",
        # required=True,
        help="",
    )

    parser.add_argument(
        "--use_openai",
        action="store_true",
        # required=True,
        help="",
    )

    parser.add_argument(
        "--group_n",
        default=50,
        type=int,
        # required=True,
        help="",
    )

    parser.add_argument(
        "--model_name",
        default='tb', # "gpt-3.5-turbo":tb, "text-davinci-003":dc
        type=str,
        # required=True,
        help="Path to pre-trained model or shortcut name",
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = config_param()
    if not args.group:
        args.group_n = 1

    output_dir = os.path.join(OPENAI_DATA_DIR, args.data)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    date = datetime.now().strftime("%m-%d-%H-%M")
    input_file_name = "in_{dataset}_sample_up_{group_n}_{date}.txt".format(dataset=args.data, group_n=args.group_n, date=date)
    output_file_name = "out_{dataset}_sample_up_{group_n}_{model}_{date}.txt".format(dataset=args.data, group_n=args.group_n,model=args.model_name, date=date)
    output_pickle_name = "out_{dataset}_sample_up_{group_n}_{model}_{date}.pkl".format(dataset=args.data, group_n=args.group_n,model=args.model_name, date=date)

    if args.data == "snli":
        reader = SnliReader()
        prompt_task = "What is the logical relationship between the following several pairs of sentences? " \
                      "Reply \"Entailment, Neutral, Contradiction\" only. Consider s1 and s2 are two pictures. " \
                      "If s2 can be inferred from s1, reply \"Entailment\". " \
                      "If s2 contradicts s1 or they describe two different events, reply \"Contradiction\". " \
                      "If s2 provides information not provided in s1, reply \"Neutral\". The sentence pairs are:\n\n"
    elif args.data == "med":
        reader = MedReader()
        prompt_task = "What is the logical relationship between the following several pairs of sentences? " \
                      "Reply \"Entailment, Neutral\" only. " \
                      "If s2 is true under any situation that the s1 describes, reply \"Entailment\". " \
                      "If else, reply \"Neutral\". The sentence pairs are:\n\n"
    elif args.data == "sick":
        reader = SickReader()
        prompt_task = "What is the logical relationship between the following several pairs of sentences? Reply \"Entailment, Neutral, Contradiction\" only. The sentence pairs are::\n\n"
    prompt_post = "\nEach line of the answer should return the corresponding pair number and the answer. The anwser is:"
    label_list = reader.label2id_dict.keys()

    if args.sample_name == "":
        data = reader.get_test_examples(args.data_dir)
    else:
        args.data_dir = ATTACK_SAMPLE_DIR
        data = reader.get_test_examples(args.data_dir, args.sample_name)

    # data = data[:6]   # for debug

    prompt_list = list()
    data_chunk = chunks(data, args.group_n)
    for chunk in data_chunk:
        prompt_data = data2text(chunk)
        final_prompt = prompt_task + prompt_data + prompt_post
        prompt_list.append(final_prompt)

    with open(os.path.join(output_dir, input_file_name), "w") as f:
        for idx, d in enumerate(prompt_list):
            f.write("{}:\n".format(idx))
            f.write(d)
            f.write("\n\n\n")

    if args.use_openai:
        openai.organization = "org-udLQKjlz4HfJHiSR2xuFSJTA"
        openai.api_key = "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"
        # openai.Model.list()

        response = list()
        answers = list()
        if args.model_name == 'dc':
            for prompt in tqdm(prompt_list):
                r = openai.Completion.create(
                    model="text-davinci-003",
                    prompt=prompt,
                    temperature=0,
                    max_tokens=args.group_n*10,
                    top_p=1.0,
                    frequency_penalty=0.0,
                    presence_penalty=0.0
                )
                response.append(r)
                answers.append(r.choices[0]['text'])
        elif args.model_name == "tb":
            for prompt in tqdm(prompt_list):
                r = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": prompt}]
                )
                response.append(r)
                answers.append(r.choices[0]['message']['content'])

        with open(os.path.join(output_dir, output_pickle_name), 'wb') as file:
            pickle.dump([response, answers], file)

        with open(os.path.join(output_dir, output_file_name), "w") as f:
            for idx, d in enumerate(answers):
                f.write("{}:\n".format(idx))
                f.write(d)
                f.write("\n\n\n")

    print(1)