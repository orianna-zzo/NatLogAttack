import argparse
import os
import numpy as np
import pandas as pd
from config.data_config import HUMAN_DIR

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # attack_model = "bertattack"  #"clare", "textfooler", "ga", "pso", "pwws"
    # victim_model = "bert"  # "roberta"
    # dataset = "snli" #med"
    parser.add_argument("--attack_model", type=str, default="natlog12")   #"bertattack", "clare", "textfooler", "ga", "pso", "pwws", "natlog"
    parser.add_argument("--victim_model", type=str, default="roberta") # "bert", "roberta"
    parser.add_argument("--dataset", type=str, default="sick")    #"snli", "med"
    parser.add_argument("--polarity", type=str, default="up")   #"up", "down", "all" for med
    args = parser.parse_args()
    # dir_name = os.path.join(HUMAN_DIR, args.attack_model, "Turk")
    # run_name = '_'.join([args.victim_model, args.attack_model, args.dataset])

    dir_name = os.path.join(HUMAN_DIR, 'newdataset_final', args.dataset)
    run_name = '_'.join([args.victim_model, args.dataset, args.attack_model])
    # file_path = os.path.join(dir_name, run_name+'_ppl_error_trans.csv')
    file_path = os.path.join(dir_name, run_name+'_ppl_error.csv')
    print("Attack Model: {}".format(args.attack_model))
    print("Victim Model: {}".format(args.victim_model))
    print("Dataset: {}".format(args.dataset))
    print("Polarity: {}".format(args.polarity))

    print("========= Read CSV =========")
    data_df = pd.read_csv(file_path)

    #   change name
    data_df = data_df.rename(columns={
        "ori_label": "original_output", "query_num": "num_queries", "new_label": "ground_truth_output"
    })
    if args.attack_model[0:3] == "nat":
        data_df['result_type'] = data_df['success'].apply(lambda x: "Successful" if x == 1 else "Failed")

    if args.dataset == "med":
        data_df = data_df[data_df.original_output == 0]
        if args.polarity == "up":
            data_df = data_df[data_df.dir == 'up']
        if args.polarity == "down":
            data_df = data_df[data_df.dir == 'down']

    data_df['num_queries'] = data_df['num_queries'].apply(int)
    # data_df['error_diff'] = data_df['new_error'] - data_df['ori_error']


    # Success
    D_ex_num = len(data_df)
    df_ori_succ = data_df[data_df.result_type == 'Successful']
    df_500_succ = data_df[(data_df.result_type == 'Successful') & (data_df.num_queries < 500)]
    E_ori_succ_num = len(df_ori_succ)
    F_ori_succ_rate = E_ori_succ_num*1.0/D_ex_num
    G_500_succ_num = len(df_500_succ)
    H_500_succ_rate = G_500_succ_num * 1.0/D_ex_num
    # print("D_ex_num:\t", D_ex_num)
    print("E_ori_succ_num:\t", E_ori_succ_num)
    # print("F_ori_succ_rate:\t", F_ori_succ_rate)
    print("G_500_succ_num:\t", G_500_succ_num)
    # print("H_500_succ_rate:\t", H_500_succ_rate)
    print("")

    # Query Number
    L_query_avg = df_ori_succ['num_queries'].mean()
    M_500_query_avg = df_500_succ['num_queries'].mean()
    # print("L_query_avg:\t", L_query_avg)
    print("M_500_query_avg:\t", M_500_query_avg)
    print("")

    # PPL
    O_ppl_avg = df_ori_succ['ppl_sum'].mean()
    P_500_ppl_avg = df_500_succ['ppl_sum'].mean()
    # print("O_ppl_avg:\t", O_ppl_avg)
    print("P_500_ppl_avg:\t", P_500_ppl_avg)
    print("")

    # # Gram Error
    # R_error_avg = df_ori_succ['error_diff'].mean()
    # S_500_error_avg = df_500_succ['error_diff'].mean()
    # print("R_error_avg:\t", R_error_avg)
    # print("S_500_error_avg:\t", S_500_error_avg)
    # print("")
    #
    # # Trans
    # U_trans_num = len(df_ori_succ[df_ori_succ.ground_truth_output != df_ori_succ.trans2other])
    # V_trans_rate = U_trans_num*1.0/E_ori_succ_num
    # W_500_trans_num = len(df_500_succ[df_500_succ.ground_truth_output != df_500_succ.trans2other])
    # X_500_trans_rate = W_500_trans_num*1.0/G_500_succ_num
    # print("U_trans_num:\t", U_trans_num)
    # print("V_trans_rate:\t", V_trans_rate)
    # print("W_500_trans_num:\t", W_500_trans_num)
    # print("X_500_trans_rate:\t", X_500_trans_rate)
    # print("")

    print("done!")




