from stanza.server import CoreNLPClient
import re
from lemminflect import getInflection
import itertools


def parseTree2str(tree):
    tree_str = ''
    stack = [tree]
    token_num = 0
    assess = 0
    while len(stack) > 0:
        node = stack.pop()
        if node == ')':
            tree_str += ')'
            assess -= 1
            continue
        if len(node.child) == 0:
            # leaf node
            tree_str += node.value + ' ' + str(token_num)
            token_num += 1
        else:
            tree_str += '(' + node.value + ' '
            assess += 1
        if len(node.child) > 0:
            # reverse add to stack
            stack.append(')')
            stack.extend(node.child[::-1])

    assert assess == 0
    return tree_str

def find_parenthes(text):
    stack = []
    for i, c in enumerate(text):
        if c == '(':
            stack.append(i)
        elif c == ')' and stack:
            start = stack.pop()
            yield text[start + 1: i]



def find_node_idx_and_parent(text, np):
    for s in find_parenthes(text):
        idxes = [substr.start() for substr in re.finditer("\("+np, s)]
        # idx = s.find("("+np)
        for idx in idxes:
            if idx != -1:
                stack = []
                for prev in s[0:idx]:
                    if prev == "(":
                        stack.append([prev])
                    elif prev == ")":
                        stack.pop()
                if len(stack) == 0:
                    left_num = s[:idx+1].count('(') - s[:idx+1].count(')')
                    pp_text = ''
                    for right_idx, i in enumerate(s[idx+1:]):
                        if i == '(':
                            left_num += 1
                        elif i == ')':
                            left_num -= 1
                            if left_num == 0:
                                pp_text = s[idx+1: idx+1+right_idx]
                                break
                    num = re.findall(r' (\d+)\)', pp_text)
                    num = [int(i) for i in num]
                    yield (min(num), max(num), s[:s.find(' ')])


def find_node_and_parent(text, np):
    for s in find_parenthes(text):
        idx = s.find("("+np)
        if idx != -1:
            stack = []
            for prev in s[0:idx]:
                if prev == "(":
                    stack.append([prev])
                elif prev == ")":
                    stack.pop()
            if len(stack) == 0:
                c = re.findall(r" [a-z0-9']+[^ \)]", s[idx+1:])
                yield ((''.join(c)).strip(), s[:s.find(' ')])


def token2sentence(tokens):
    return ' '.join(tokens).replace(" n't", "n't").replace(" ,", ",").replace(" - ", "-").replace(" '", "'")


def get_n(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        if idx >0:
            if pos_list[idx-1] == "HYPH":
                continue
        if pos_list[idx][0:2] == 'NN' and pos_list[idx+1][0:2] != 'NN':
            idx_list.append(idx)

    if pos_list[-1][0:2] == 'NN':
        if len(pos_list) == 1 or pos_list[-2] != "HYPH":
            idx_list.append(len(pos_list)-1)
    return idx_list

def get_prp(pos_list):
    idx_list = []
    for idx in range(len(pos_list)):
        if pos_list[idx] == 'PRP':
            idx_list.append(idx)
    return idx_list

def get_cd(pos_list):
    idx_list = []
    length = len(pos_list)
    for idx in range(length-1):

        if pos_list[idx][0:2] == 'CD':
            if pos_list[idx+1][0:2] not in ['CD', "HYPH"]: # not "twenty one man" or "twenty-one-man"
                idx_list.append(idx)
            elif pos_list[idx+1] == "HYPH" and idx+2 < length:
                if pos_list[idx+2][0:2] != 'CD':
                    idx_list.append(idx)
    if pos_list[-1][0:2] == 'CD':
        idx_list.append(length-1)
    return idx_list


def get_v(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        if pos_list[idx][0:2] == 'VB' and pos_list[idx+1][0:2] != 'VB':
            idx_list.append(idx)
    if pos_list[-1][0:2] == 'VB':
        idx_list.append(len(pos_list)-1)
    return idx_list

def get_adj(pos_list):
    idx_list = []
    for idx in range(len(pos_list)-1):
        # adj
        if pos_list[idx][0:2] == 'JJ':
            idx_list.append(idx)
        # n as adj
        if pos_list[idx][0:2] == 'NN' and pos_list[idx+1][0:2] == 'NN':
            idx_list.append(idx)
    # if pos_list[-1][0:2] == 'JJ':
    #     idx_list.append(len(pos_list)-1)
    return idx_list

def get_adv(pos_list):
    idx_list = []
    for idx in range(len(pos_list)):
        # adv
        if pos_list[idx][0:2] == 'RB':
            idx_list.append(idx)
    return idx_list


def get_not_sentence(tokens, lemma, pos_list):
    v_idx = [i for i in range(len(tokens)) if pos_list[i][0:2] == 'VB']
    not_idx = []  # add not in front of the idx in this list
    do_idx = [] # add do/does in front of not
    res = []
    not_rb = ["never", "not", "hardly", "scarcely"]
    neg_lemma = not_rb + ["no"]

    # check not in the original sentence
    for not_w in neg_lemma:
        if not_w in lemma:
            idx = lemma.index(not_w)
            res.append((token2sentence(tokens[:idx] + tokens[idx+1:]),
                        list(range(0,idx)) + list(range(idx+1, len(lemma))),
                        lemma[:idx] + lemma[idx+1:]))
            return res

    # wether need to seperate do
    for i in v_idx:
        # could/will v, do v, be, have do
        # v to v, v ving
        # v -> do not v


        # # if (i+1) not in v_idx:
        # #     not_idx.append(i)
        # #     if pos_list[i-1][0:2] == "MD":  # could will
        # #         not_idx.append(i)
        # #     elif (i-1) not in v_idx:
        # #         do_idx.append(i)
        #
        # if (i+1) not in v_idx:
        #     # not_idx.append(i)
        #     if pos_list[i-1][0:2] == "MD" or lemma[i-1] == 'do' or tokens[i-1] == 'to':  # could/will v, do v, to v
        #         not_idx.append(i)   # add not before the v directly
        #     elif (i-1) not in v_idx:
        #         do_idx.append(i)    # v -> do v

        if i == 0:
            not_idx.append(i)
            break
        else:
            if (i-1) not in v_idx and lemma[i-1] != 'do' and tokens[i-1] != 'to' and lemma[i]!= 'be':  # v to v, v ving, v -> do not v
                do_idx.append(i)
                break
            elif pos_list[i-1][0:2] == "MD" or lemma[i-1] == 'do' or lemma[i] == 'be': # could/will v, do v, be -> not v
                not_idx.append(i)
                break
            else:
                not_idx.append(i)
                break


    for not_w in not_rb:
        s = ''
        s_idx = [] # ori idx
        new_lemma = []
        for i in range(len(tokens)):
            if i in do_idx:
                # have not v
                if lemma[i] == "have":
                    s = s + ' ' + tokens[i] + ' ' + not_w
                    s_idx.append(i)
                    s_idx.append(-1)
                    new_lemma.append(lemma[i])
                    new_lemma.append(not_w)

                else:
                    # do not v  "done not made of?"
                    w = getInflection("do", pos_list[i])
                    if len(w) > 0:
                        s = s + ' ' + w[0]
                        s_idx.append(-1)
                        new_lemma.append('do')
                    else:
                        s = s + ' do'
                        s_idx.append(-1)
                        new_lemma.append('do')

                    s = s + ' ' + not_w + ' ' + lemma[i]
                    s_idx.append(-1)
                    s_idx.append(i)
                    new_lemma.append(not_w)
                    new_lemma.append(lemma[i])
                # if pos_list[i][0:3] == 'VBD':
                #     s += ' did'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
                # elif pos_list[i][0:3] in ['VBP', 'VBZ']:
                #     s += ' does'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
                # elif pos_list[i][0:3] not in ['VBG', 'VBN']:
                #     s += ' do'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
            elif i in not_idx:
                if lemma[i] == 'be':
                    s = s + ' ' + tokens[i] + ' ' + not_w
                    s_idx.append(i)
                    s_idx.append(-1)
                    new_lemma.append(lemma[i])
                    new_lemma.append(not_w)
                else:
                    s = s + ' ' + not_w + ' ' + tokens[i]
                    s_idx.append(-1)
                    s_idx.append(i)
                    new_lemma.append(not_w)
                    new_lemma.append(lemma[i])
            else:
                s = s + ' ' + tokens[i]
                s_idx.append(i)
                new_lemma.append(lemma[i])
        res.append((s.strip(), s_idx, new_lemma))
    return res

def get_simple_not_sentence(tokens, lemma, pos_list):
    v_idx = [i for i in range(len(tokens)) if pos_list[i][0:2] == 'VB']
    not_idx = []  # add not in front of the idx in this list
    do_idx = [] # add do/does in front of not
    res = []
    not_rb = ["not"]
    neg_lemma = not_rb + ["no"]

    # check not in the original sentence
    for not_w in neg_lemma:
        if not_w in lemma:
            idx = lemma.index(not_w)
            res.append((token2sentence(tokens[:idx] + tokens[idx+1:]),
                        list(range(0,idx)) + list(range(idx+1, len(lemma))),
                        lemma[:idx] + lemma[idx+1:]))
            return res

    # wether need to seperate do
    for i in v_idx:
        # could/will v, do v, be, have do
        # v to v, v ving
        # v -> do not v


        # # if (i+1) not in v_idx:
        # #     not_idx.append(i)
        # #     if pos_list[i-1][0:2] == "MD":  # could will
        # #         not_idx.append(i)
        # #     elif (i-1) not in v_idx:
        # #         do_idx.append(i)
        #
        # if (i+1) not in v_idx:
        #     # not_idx.append(i)
        #     if pos_list[i-1][0:2] == "MD" or lemma[i-1] == 'do' or tokens[i-1] == 'to':  # could/will v, do v, to v
        #         not_idx.append(i)   # add not before the v directly
        #     elif (i-1) not in v_idx:
        #         do_idx.append(i)    # v -> do v

        if i == 0:
            not_idx.append(i)
            break
        else:
            if (i-1) not in v_idx and lemma[i-1] != 'do' and tokens[i-1] != 'to' and lemma[i]!= 'be':  # v to v, v ving, v -> do not v
                do_idx.append(i)
                break
            elif pos_list[i-1][0:2] == "MD" or lemma[i-1] == 'do' or lemma[i] == 'be': # could/will v, do v, be -> not v
                not_idx.append(i)
                break
            else:
                not_idx.append(i)
                break


    for not_w in not_rb:
        s = ''
        s_idx = [] # ori idx
        new_lemma = []
        for i in range(len(tokens)):
            if i in do_idx:
                # have not v
                if lemma[i] == "have":
                    s = s + ' ' + tokens[i] + ' ' + not_w
                    s_idx.append(i)
                    s_idx.append(-1)
                    new_lemma.append(lemma[i])
                    new_lemma.append(not_w)

                else:
                    # do not v
                    w = getInflection("do", pos_list[i])
                    if len(w) > 0:
                        s = s + ' ' + w[0]
                        s_idx.append(-1)
                        new_lemma.append('do')
                    else:
                        s = s + ' do'
                        s_idx.append(-1)
                        new_lemma.append('do')

                    s = s + ' ' + not_w + ' ' + lemma[i]
                    s_idx.append(-1)
                    s_idx.append(i)
                    new_lemma.append(not_w)
                    new_lemma.append(lemma[i])
                # if pos_list[i][0:3] == 'VBD':
                #     s += ' did'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
                # elif pos_list[i][0:3] in ['VBP', 'VBZ']:
                #     s += ' does'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
                # elif pos_list[i][0:3] not in ['VBG', 'VBN']:
                #     s += ' do'
                #     s_idx.append(-1)
                #     new_lemma.append('do')
            elif i in not_idx:
                if lemma[i] == 'be':
                    s = s + ' ' + tokens[i] + ' ' + not_w
                    s_idx.append(i)
                    s_idx.append(-1)
                    new_lemma.append(lemma[i])
                    new_lemma.append(not_w)
                else:
                    s = s + ' ' + not_w + ' ' + tokens[i]
                    s_idx.append(-1)
                    s_idx.append(i)
                    new_lemma.append(not_w)
                    new_lemma.append(lemma[i])
            else:
                s = s + ' ' + tokens[i]
                s_idx.append(i)
                new_lemma.append(lemma[i])
        res.append((s.strip(), s_idx, new_lemma))
    return res

def simple_tokenize(s):
    t = s.split()
    tokens = []
    for i in t:
        if i[-3:] == "n't":
            tokens.append(i[:-3])
            tokens.append(i[-3:])
        elif "-" in i:
            tmp = i.split('-')
            tokens.append(tmp[0])
            for j in range(len(tmp)-1):
                tokens.append('-')
                tokens.append(tmp[j+1])
        else:
            tokens.append(i)

    return tokens

def get_subsentence(s, lemma):
    # let s after another sentence, lemma is the lemma of the first token
    if lemma in ['NNP', 'NNPS']:
        return s
    else:
        return s[0].lower() + s[1:]

def find_cc_start(s, idx):  # idx is CC's idx
    span = [i.split() for i in find_parenthes(s)]
    span_end = [int(re.findall(r'\d+', i[-1])[0]) for i in span if len(re.findall(r'\d+', i[-1])) > 0]
    span_num = [i for i in range(len(span_end)) if span_end[i] == idx-1]
    spans = [' '.join(span[i]) for i in span_num]
    start_num = list()
    for i in spans:
        if '(' not in i:
            start_num.append(int(i.split()[-1]))
        else:
            start_num.append(int(re.findall(r'\d+\)', i)[0].split(')')[0]))
    return min(start_num)


if __name__ == "__main__":
    # ori = "A man in a white striped shirt and blue jeans using a water hose to spray water on the ground of concrete ruins.Fo".split()
    # s = "(ROOT (NP (NP (DT A 0)(NN man 1))(PP (IN in 2)(NP (NP (DT a 3)(JJ white 4)(JJ striped 5)(NN shirt 6))(CC and 7)(S (NP (JJ blue 8)(NNS jeans 9))(VP (VBG using 10)(NP (DT a 11)(NN water 12)(NN hose 13))(PP (IN to 14)(NP (NN spray 15)(NN water 16)))(PP (IN on 17)(NP (NP (DT the 18)(NN ground 19))(PP (IN of 20)(NP (JJ concrete 21)(NN ruins.Fo 22)))))))))))"
    # pp = list(find_node_idx_and_parent(s, 'PP '))
    # print(pp)
    # for i in pp:
    #     print(' '.join(ori[i[0]:i[1]+1]))

    t = '(ROOT (S (NP (NP (DT no 0)(NN food 1))(CC or 2)(NP (DT no 3)(NN drink 4)))(VP (VBZ makes 5)(S (NP (NNP John 6))(NP (DT a 7)(JJ dull 8)(NN boy 9))))))'
    # num = [list(itertools.chain(*[re.findall(r'\d+', i) for i in p.split() ]) )for p in find_parenthes(t)]
    # s = min([int(a[0]) for a in num if int(a[-1]) == 1])
    # s = list(find_node_idx_and_parent(t, 'CC '))
    # print(s)

    # t = '(ROOT (S (NP (DT An 0)(JJ Italian 1)(NN sommelier 2))(VP (VBZ knows 3)(NP (NP (DT the 4)(NN difference 5))(PP (IN between 6)(NP (NP (DT the 7)(QP (CD 2009 8)(CC and 9)(CD 2013 10))(NN vintage 11))(PP (IN of 12)(NP (DT a 13)(JJ German 14)(NN riesling 15)))))))))'
    # s = find_node_idx_and_parent(t, "CC")

    # span = [i.split() for i in find_parenthes(t)]
    # span_end = [int(re.findall(r'\d+', i[-1])[0]) for i in span]
    # span_num = [i for i in range(len(span_end)) if span_end[i] == 2-1]
    # spans = [' '.join(span[i]) for i in span_num]
    # start_num = list()
    # for i in spans:
    #     if '(' not in i:
    #         start_num.append(int(i.split()[-1]))
    #     else:
    #         start_num.append(int(re.findall(r'\d+\)', i)[0].split(')')[0]))

    p = find_cc_start(t, 2)
    print(p)





