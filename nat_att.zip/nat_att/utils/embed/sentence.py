import numpy as np

def avg_embed(fea_s, mask_s):
    """
    fea_s: shape: (batch_size, sentence_size, dim)
    mask_s: shape: (batch_size, sentence_size)
    """
    fea_masked = mask_s[:, :, None] * fea_s
    return np.sum(fea_masked, axis=1, keepdims=True) / (np.sum(mask_s, axis=1, keepdims=True)[:, :, None])