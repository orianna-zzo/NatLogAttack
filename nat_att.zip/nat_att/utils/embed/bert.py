import torch
from torch.utils.data import Dataset, DataLoader, SequentialSampler
import numpy as np
from transformers import BertConfig, BertTokenizer, BertModel, BERT_PRETRAINED_MODEL_ARCHIVE_LIST
# from transformers import BertConfig, BertTokenizer, BertModel, BERT_PRETRAINED_MODEL_ARCHIVE_MAP
from tqdm import tqdm
from . import Embed

import logging
logger = logging.getLogger(__name__)

BERT_MODEL_LIST = BERT_PRETRAINED_MODEL_ARCHIVE_LIST
# BERT_MODEL_LIST = BERT_PRETRAINED_MODEL_ARCHIVE_MAP.keys()

class BertEmbed(Embed):
    def __init__(self, model_name, max_length=None, unk=0, padding=0,
                 no_cuda=False, do_lower_case=False, cache_dir=None):
        """
        Get Bert Embedding
        :param model_name: Which Bert model to use
        :param max_length: Max length of sequence. If None, then it will be the max length of the input sequences.
        :param no_cuda: cpu only
        :param do_lower_case:
        :param cache_dir: cache dir for transformer models
        """
        assert model_name in BERT_MODEL_LIST, "Not Found this model: " + model_name
        self.model_name = model_name
        self.config = BertConfig.from_pretrained(model_name, cache_dir=cache_dir if cache_dir else None)
        self.tokenizer = BertTokenizer.from_pretrained(model_name, do_lower_case=do_lower_case,
                                                       cache_dir=cache_dir if cache_dir else None)
        self.model = BertModel.from_pretrained(model_name, config=self.config,
                                               cache_dir=cache_dir if cache_dir else None)
        self.device = torch.device("cuda" if torch.cuda.is_available() and not no_cuda else "cpu")
        self.model.to(self.device)
        self.dim = self.config.hidden_size
        self.unk = unk   # no use here
        self.padding = padding   # no use here
        self.max_length = max_length
        logger.info("BertEmbed: device: %s", self.device)


    def get_tokenized_word(self, examples) -> list:
        """
        Tokenize the examples
        :param examples:
        :return: list of tokenized examples. [['Birds', 'fly', '.'], ['So', 'as', 'planes', '.']]
        """
        word_list = []
        for ex in examples:
            word_list.append(self.tokenizer.tokenize(ex))
        return word_list


    def _get_inputs(self, examples):
        """
        Get tokens input ids and masks of the examples
        :param examples:
        :return:
        """
        ids = []
        masks = []
        for ex in examples:
            this_tensor = torch.tensor(self.tokenizer.encode(ex, add_special_tokens=False))
            ids.append(this_tensor)
            masks.append(torch.tensor([1] * this_tensor.shape[0]))
        ids = torch.nn.utils.rnn.pad_sequence(ids, batch_first=True)
        masks = torch.nn.utils.rnn.pad_sequence(masks, batch_first=True)
        if self.max_length is not None:
            ids = ids[:, :self.max_length]
            masks = masks[:, :self.max_length]
        return ids, masks


    def get_output_embeddings(self, examples, batch_size=64, split_sentence=False) -> (np.array, np.array):
        """
        Get Bert Embedding
        :param examples:
        :return: fea: output embeddings, shape: (example_num, max_length, dim)
                mask: if it is a token then mark as 1, else 0. shape: (example_num, max_length)
        """
        if batch_size is None:
            batch_size = 64
        output_fea = None
        output_mask = None

        input_ids, masks = self._get_inputs(examples)
        dataset = BertEmbedDataset(input_ids, masks)
        sampler = SequentialSampler(dataset)

        dataloader = DataLoader(dataset, sampler=sampler, batch_size=batch_size)
        for batch in tqdm(dataloader, desc="get_output_embeddings"):
            self.model.eval()

            with torch.no_grad():
                inputs = {'input_ids': batch['input_ids'].to(self.device),
                          "attention_mask": batch['attention_mask'].to(self.device)}
                last_hidden_states = self.model(**inputs)
                fea = batch['attention_mask'][:, :, None].to(self.device) * last_hidden_states[0]
            if output_fea is None:
                output_fea = fea.cpu().numpy()
                output_mask = batch['attention_mask'].cpu().numpy()
            else:
                output_fea = np.append(output_fea, fea.cpu().numpy(), axis=0)
                output_mask = np.append(output_mask, batch['attention_mask'].cpu().numpy(), axis=0)
        return output_fea, output_mask

    def to_cpu(self):
        """
        Move bert model into cpu
        :return:
        """
        self.model.to(torch.device("cpu"))


class BertEmbedDataset(Dataset):
    def __init__(self, input_ids, masks):

        self.data = {
            'input_ids': input_ids,
            'attention_mask': masks
        }

    def __len__(self):
        return len(self.data["input_ids"])

    def __getitem__(self, index):
        return {
            'input_ids': self.data["input_ids"][index],
            'attention_mask': self.data["attention_mask"][index]
        }



if __name__ == "__main__":
    sentence_list = ["Who was Jim Henson ?", "I just want to have a test of the code.", "I just want to have a test of the code."]
    bertembed = BertEmbed('bert-base-cased', no_cuda=True)
    output, mask = bertembed.get_output_embeddings(sentence_list)
    print(output.shape)
    print(mask.shape)
    print(output)
    print(mask)
    print(mask[:, :, None] * output)
