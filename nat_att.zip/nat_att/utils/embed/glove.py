import os
import stanfordnlp
import numpy as np
import itertools
from collections import OrderedDict

from . import Embed


import logging
logger = logging.getLogger(__name__)

# GLOVE_MODEL_LIST = ["glove.840B.300d"]

class GloveEmbed(Embed):
    def __init__(self, model_path, max_length=None, unk=0, padding=0,
                 no_cuda=False, tokenize=True, stanford_models_dir=None, do_lower_case=False):
        """
        Get Glove Embedding
        :param model_path: Glove Model File Path. The model file should be like,
                token   embedding
                token   embedding
        :param max_length: Max length of sequence. If None, then it will be the max length of the input sequences.
        :param unk: unknown token
        :param padding: padding
        :param no_cuda: cpu only, for stanfordnlp using in tokenization process
        :param tokenize: whether need tokenize. If input is tokenized, then it could be False.
                (e.g.[['Birds', 'fly', '.'], ['So', 'as', 'planes', '.']])
        :param stanford_models_dir: Where is the stanford model ('en')
        :param do_lower_case:
        """

        assert os.path.isfile(model_path), "Not Found this model: " + model_path
        self.do_lower_case = do_lower_case
        self.tokenize = tokenize
        self.max_length = max_length
        self.unk = unk
        self.padding = padding
        if self.tokenize:
            if stanford_models_dir is not None:
                self.tokenizer = stanfordnlp.Pipeline(processors="tokenize", use_gpu=(not no_cuda),
                                                      models_dir=stanford_models_dir)
            else:
                self.tokenizer = stanfordnlp.Pipeline(processors="tokenize", use_gpu=(not no_cuda))
        self.model, self.dim = self._get_embed_matrix(model_path)
        self.model_name = os.path.splitext(os.path.basename(model_path))[0]


    def _get_embed_matrix(self, model_path):
        """
        Load the word embeddings in a model file.
        :param model_path: Glove Model File Path. The model file should be like,
                token   embedding
                token   embedding
        :return: embeddings: OrderedDict, dim
        """
        embeddings = OrderedDict()
        with open(model_path, "r", encoding="utf8") as input_data:
            for idx, line in enumerate(input_data):
                line = line.split()
                if idx == 2:
                    dim = len(line) - 1

                try:
                    # Check that the second element on the line is the start
                    # of the embedding and not another word. Necessary to
                    # ignore multiple word lines.
                    float(line[1])
                    word = line[0]
                    embeddings[word] = line[1:]

                # Ignore lines corresponding to multiple words separated
                # by spaces.
                except ValueError:
                    print("ValueError: ", line)
                    continue

        return embeddings, dim


    def _get_embedding(self, word) -> list:
        """
        Return the embedding of the input word.
        If the word is not in the vocab, then use the unk vector
        :param word:
        :return: embedding of the input word: list, length should be equal to self.dim
        """
        if word in self.model.keys():
            return self.model[word]
        else:
            return [self.unk] * self.dim


    def get_tokenized_word(self, examples, split_sentence=False) -> list:
        """
        Tokenize the examples
        Use Stanfordnlp.
        If there are several sentences in one example,
        then they will be seperated into several examples.
        :param examples:
        :return: list of tokenized examples. e.g. [['Birds', 'fly', '.'], ['So', 'as', 'planes', '.']]
        """
        token_list = []
        if self.tokenize:
            for ex in examples:
                if self.do_lower_case:
                    ex = ex.lower()
                tokens = map(lambda x: [i.text for i in x.tokens], self.tokenizer(ex).sentences)
                if not split_sentence:
                    tokens = [list(itertools.chain(*tokens))]
                # token_list.append(list(itertools.chain(*tokens)))   # flat sentences in one doc
                token_list.extend(list(tokens))
        return token_list


    def get_output_embeddings(self, examples, batch_size=None, split_sentence=False) -> (np.array, np.array):
        """
        Get output embeddings and the mask of the input examples
        unknown token will be mark as self.unk.
        Less than self.max_length will be mark as self.padding.
        :param examples:
        :return: output: output embeddings, shape: (example_num, max_length, dim)
                 mask: if it is a token then mark as 1, else 0. shape: (example_num, max_length)
        """
        if self.tokenize:
            token_list = self.get_tokenized_word(examples, split_sentence)
        else:
            token_list = examples
        if self.max_length is None:
            length = max(map(len, token_list))
        else:
            length = self.max_length
        output = np.zeros((len(token_list), length, self.dim))
        mask = np.zeros((len(token_list), length))
        for idx, ex in enumerate(token_list):
            s = np.array([self.padding] * (length * self.dim), dtype=float).reshape(length, self.dim)
            for iidx, t in enumerate(ex):
                if iidx < length:
                    if self.do_lower_case:
                        t = t.lower()
                    s[iidx, :] = self._get_embedding(t)
            output[idx, :] = s
            mask[idx, :len(ex)] = [1] * len(ex)
        return output, mask



if __name__ == "__main__":
    from config import *
    sentence_list = ["Who was Jim Henson ? I don't like you.", "I just want to have a test of the code."]
    embed_model = GloveEmbed(os.path.join(EMBED_DIR, "glove.6B.50d.txt"), stanford_models_dir=STANFORD_NLP_HOME, do_lower_case=True)
    output, mask = embed_model.get_output_embeddings(sentence_list)
    print(output.shape)
    print(mask.shape)
    print(output)
    print(mask)
    print(mask[:,:,None]*output)

