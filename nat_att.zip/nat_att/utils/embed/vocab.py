import logging
import numpy as np
from collections import Counter, OrderedDict

logger = logging.getLogger(__name__)

def build_vocab(word_list, vocab_size=None, vocab_path=None):
    counts = Counter(word_list)
    if vocab_size is None:
        vocab_size = len(counts)

    word2id = OrderedDict()

    # Special indices are used for padding, out-of-vocabulary words, and
    # beginning and end of sentence tokens.
    word2id["[PAD]"] = 0
    word2id["[UNK]"] = 1
    word2id["[SEP]"] = 2
    word2id["[CLS]"] = 3
    word2id["[MASK]"] = 4
    word2id["[BOS]"] = 5
    word2id["[EOS]"] = 6

    offset = 10

    for i, word in enumerate(counts.most_common(vocab_size)):
        word2id[word[0]] = i + offset

    id2word = {id: word for word, id in word2id.items()}

    if vocab_path is not None:
        with open(vocab_path, 'w') as f:
            for i in range(max(id2word.keys()) + 1):
                if i in id2word.keys():
                    f.write(id2word[i] + "\n")
                else:
                    f.write("[unused]\n")

    return word2id, id2word


def load_vocab(vocab_path):
    word2id = OrderedDict()
    id2word = OrderedDict()
    with open(vocab_path, 'r') as f:
        for (i, line) in enumerate(f):
            if line.strip() == "[unused]":
                continue
            word2id[line.strip()] = i
            id2word[i] = line.strip()

    return word2id, id2word


def build_embedding_matrix(word2id, embeddings_path):

    # Load the word embeddings in a dictionnary.
    embeddings = OrderedDict()
    with open(embeddings_path, "r", encoding="utf8") as input_data:
        for idx, line in enumerate(input_data):
            line = line.split()
            if idx == 2:
                dim = len(line) - 1

            try:
                # Check that the second element on the line is the start
                # of the embedding and not another word. Necessary to
                # ignore multiple word lines.
                float(line[1])
                word = line[0]
                if word in word2id.keys():
                    embeddings[word] = line[1:]

            # Ignore lines corresponding to multiple words separated
            # by spaces.
            except ValueError:
                continue

    vocab_size = max(word2id.values()) + 1
    embedding_matrix = np.zeros((vocab_size, dim))

    # Actual building of the embedding matrix.
    missed = 0
    for word, i in word2id.items():
        if word in embeddings:
            embedding_matrix[i] = np.array(embeddings[word], dtype=float)
        else:
            if word in ["[PAD]", "[UNK]", "[SEP]", "[CLS]", "[MASK]", "[BOS]", "[EOS]"]:
                continue
            missed += 1
            # Out of vocabulary words are initialised with random gaussian
            # samples.
            embedding_matrix[i] = np.random.normal(size=(dim))
    print("Missed words: ", missed)

    return embedding_matrix


def find_word_id(word2id_dict, word):
    if word in word2id_dict:
        return word2id_dict[word]
    else:
        return word2id_dict["[UNK]"]


def find_sentence_ids(word2id_dict, sentence, max_length=None):
    ids = [find_word_id(word2id_dict, i) for i in sentence]
    if max_length is None:
        return ids
    elif len(ids) > max_length:
        return ids[0:max_length]