

def swap_list_pos(l, pos1, pos2):
    # swap the pos1 and pos2 in the list
    # eg.
    # l = [1, 2, 3, 4, 5]
    # swap_list_pos(l, 0, 1)
    # l: [2, 1, 3, 4, 5]
    l[pos1], l[pos2] = l[pos2], l[pos1]
    return l


def has_sublist(l, sublist):
    # whether the list l has the sublist
    return any(l[idx: idx + len(sublist)] == sublist
              for idx in range(len(l) - len(sublist) + 1))

def has_sublist_idx(l, sublist):
    # return idx if the list l has the sublist
    return [idx for idx in range(len(l) - len(sublist) + 1) if l[idx: idx + len(sublist)] == sublist]