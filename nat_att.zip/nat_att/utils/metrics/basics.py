from sklearn.metrics import f1_score, accuracy_score, precision_recall_fscore_support
from scipy.stats import pearsonr, spearmanr

def simple_accuracy(preds, labels):
    return {"acc": accuracy_score(y_true=labels, y_pred=preds)}

def acc_and_f1(preds, labels, id2label_dict):
    result = simple_accuracy(preds, labels)
    f1 = f1_score(y_true=labels, y_pred=preds, average=None)
    result['f1'] = f1
    for id in id2label_dict.keys():
        result["f1_" + id2label_dict[id]] = f1[id]
    return result

def pearson_and_spearman(preds, labels):
    pearson_corr = pearsonr(preds, labels)[0]
    spearman_corr = spearmanr(preds, labels)[0]
    return {
        "pearson": pearson_corr,
        "spearmanr": spearman_corr,
        "corr": (pearson_corr + spearman_corr) / 2,
}

def acc_and_pr(preds, labels, id2label_dict):
    result = simple_accuracy(preds, labels)
    metrics = precision_recall_fscore_support(y_true=labels, y_pred=preds, average=None)

    name_dict = dict()
    if len(metrics[0]) < len(id2label_dict):
        # miss samples for specific label
        diff = 0
        for i in id2label_dict.keys():
            if i not in set(labels):
                diff += 1
            else:
                k = i-diff
                name_dict.update({k: id2label_dict[i]})
    else:
        name_dict = id2label_dict

    for id in range(len(metrics[0])):
        result["p_" + name_dict[id]] = metrics[0][id]
        result["r_" + name_dict[id]] = metrics[1][id]
        result["f1_" + name_dict[id]] = metrics[2][id]
        result["support_" + name_dict[id]] = metrics[3][id]
    return result