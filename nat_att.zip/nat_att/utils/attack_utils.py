import torch
import os
import numpy as np
import time
from config import WORDNET_DIR, STANFORD_CORENLP_HOME, HUMAN_DIR
import transformers
from transformers import (
    DistilBertConfig, DistilBertForMaskedLM, DistilBertTokenizer
)
from utils.data import read_tsv
from utils.data_utils import NatlogWordNet
import itertools
from utils.text.parse import parseTree2str, find_parenthes, find_node_idx_and_parent, find_cc_start, token2sentence, \
    get_n, get_v, get_adj, get_adv, get_cd, get_prp, get_not_sentence, get_simple_not_sentence, simple_tokenize, get_subsentence#, first_lower
from utils.basic.string import *

# from config import STANFORD_CORENLP_HOME
os.environ['CORENLP_HOME'] = STANFORD_CORENLP_HOME
from stanza.server import CoreNLPClient

# import spacy
from lemminflect import getInflection
# spacy_nlp = spacy.load()

import re
import math
import logging

logger = logging.getLogger(__name__)

class Natlog_Attack(object):
    def __init__(self, victim_model, tokenizer, victim_model_args, victim_model_predict_fn, max_queries=500,
                 pp_file_dir=None, method_pp=True, method_insert_delete=True, method_natlog=True, tag='',
                 device='cpu'):
        self.max_queries = max_queries
        self.method_pp = method_pp
        self.method_insert_delete=method_insert_delete
        self.method_natlog = method_natlog
        self.PP_NUM = 80
        self.BERT_EQ = 30
        self.EQ_THRE = 0.98
        self.ALT_THRE = 0.7
        # self.INS_DEL = 20
        self.NUM_PER_STEP = 100
        self.adv_ex =["n't", 'not', 'no', "never", "hardly", "scarcely", "rarely", "seldomly"]
        self.neg_prefix = ['It is not true that',
                           'It is false that',
                           'It is not correct that',
                           'It is not that',
                           'It is not right that',
                           'It is untrue that',
                           'It is not true to say that',
                           'It is wrong to say that',
                           # 'no clue shows that',
                           # 'it is unconfirmed that',
                           # 'there is no evidence that'
                           ]

        # for victim model
        self.victim_model = victim_model
        self.tokenizer = tokenizer
        self.victim_model_predict_fn = victim_model_predict_fn
        self.victim_model_args = victim_model_args

        # for lm
        lm_model_name = "distilbert-base-uncased"
        lm_config = DistilBertConfig.from_pretrained(lm_model_name)
        self.lm_device = device
        self.lm_tokenizer = DistilBertTokenizer.from_pretrained(lm_model_name)
        self.lm_model = DistilBertForMaskedLM.from_pretrained(lm_model_name, config=lm_config).to(self.lm_device)
        # self.mask = '[MASK]'
        # # for insert
        # self.gen_model = BertPreTrainedModel.from_pretrained(lm_model_name, config=lm_config)

        # for natlog
        self.map_project_dir = {"up": 1, "down": 2, 'flat': 0}
        self.wordnet = NatlogWordNet(WORDNET_DIR, self.lm_model, self.lm_device)
        self.client = CoreNLPClient(annotators=['parse', 'natlog'], timeout=60000, memory='16G', threads=64)

        # for pp
        thre = 200
        # self.p_e = []
        # self.p_n = []
        # self.p_c = []
        # self.h_e = []
        # self.h_n = []
        # self.h_c = []
        # if pp_file_dir is not None:
        #     p_e_all = read_tsv(os.path.join(pp_file_dir, "p_e_pp.txt"))
        #     p_n_all = read_tsv(os.path.join(pp_file_dir, "p_n_pp.txt"))
        #     p_c_all = read_tsv(os.path.join(pp_file_dir, "p_c_pp.txt"))
        #     h_e_all = read_tsv(os.path.join(pp_file_dir, "h_e_pp.txt"))
        #     h_n_all = read_tsv(os.path.join(pp_file_dir, "h_n_pp.txt"))
        #     h_c_all = read_tsv(os.path.join(pp_file_dir, "h_c_pp.txt"))
        #     self.p_e = [(i[0], i[1]) for i in p_e_all if int(i[2]) > thre]
        #     self.p_n = [(i[0], i[1]) for i in p_n_all if int(i[2]) > thre]
        #     self.p_c = [(i[0], i[1]) for i in p_c_all if int(i[2]) > thre]
        #     self.h_e = [(i[0], i[1]) for i in h_e_all if int(i[2]) > thre]
        #     self.h_n = [(i[0], i[1]) for i in h_n_all if int(i[2]) > thre]
        #     self.h_c = [(i[0], i[1]) for i in h_c_all if int(i[2]) > thre]
        self.vp_pp_db = []
        self.np_pp_db = []
        if pp_file_dir is not None:
            pp_all = read_tsv(os.path.join(pp_file_dir, "all_pp_2.txt"))
        self.vp_pp_db = [i[0] for i in pp_all if int(i[-1]) > thre and i[1] == 'VP']
        self.np_pp_db = [i[0] for i in pp_all if int(i[-1]) > thre and i[1] == 'NP']
        self.this_vp = []
        self.this_np = []

        # for log
        # self.s1_file_name = "same_label_"+tag+"12.txt"
        self.s1_file_name = "debug.txt"
        # self.s2_c2e_file_name = "c2e_"+tag+"12.txt"
        # self.s2_e2c_file_name = "e2c_"+tag+"12.txt"
        # self.s2_e2n_file_name = "e2n_"+tag+"12.txt"
        self.s2_c2e_file_name = "debug.txt"
        self.s2_e2c_file_name = "debug.txt"
        self.s2_e2n_file_name = "debug.txt"
        method1 = "natlog12"
        method2 = "natlog12s2"
        self.dir1 = os.path.join(HUMAN_DIR, method1)
        self.dir2 = os.path.join(HUMAN_DIR, method2)
        if not os.path.exists(self.dir1):
            os.mkdir(self.dir1)
        if not os.path.exists(self.dir2):
            os.mkdir(self.dir2)
        # for continue


    def attack(self, examples, setting=1):
        if setting == 1:
            with open(os.path.join(self.dir1, self.s1_file_name), "w") as f:
                f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
        if setting == 2:
            with open(os.path.join(self.dir2, self.s2_c2e_file_name), "w") as f:
                f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
            with open(os.path.join(self.dir2, self.s2_e2c_file_name), "w") as f:
                f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
            with open(os.path.join(self.dir2, self.s2_e2n_file_name), "w") as f:
                f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")


        for (idx, ex) in enumerate(examples):
            # if int(ex['idx']) not in [42, 867, 495, 3685, 2872, 2672, 991, 3310]: # med
            #     continue
            # if int(ex['idx']) not in [657]: #snli
            #     continue

            # if int(ex['idx']) not in [1813, 2442, 4070, 4193, 4745, 4836, 4960, 5605, 5856, 5942, 6946, 7101, 7198, 7835, 7892, 8549, 9402, 9640]: #snli failed
            #     continue
            # if idx < 621:
            #     continue
            # if idx < 813:
            #     continue
            # p = ex['text_a']
            # h = ex['text_b']
            ori_label = ex['label']
            # new_text = [((p, h), ori_label)]

            if setting == 1:
                target_label = ori_label
                # # !!!!only for debug
                # if self.victim_model_args.id2label_dict[ori_label] != 'entailment':
                #     continue

                with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
                    f.write("{}\t".format(idx))
                logger.info("------------{}------------".format(idx))
                attack_text, n_query, success = self._attack_same_label(ex)
                # print("{idx}: success: {success}, n_query: {n_query}, text: {attack_text}".format(
                #     idx=idx, success=success, n_query=n_query, attack_text=attack_text))

            elif setting == 2:
                if self.victim_model_args.id2label_dict[ori_label] == 'neutral':
                    continue
                elif self.victim_model_args.id2label_dict[ori_label] == 'contradiction':
                    # target_label = self.victim_model_args.label2id_dict['entailment']
                    with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
                        f.write("{}\t".format(idx))
                    logger.info("------------{}: C2E ------------".format(idx))
                    attack_text, n_query, success = self._attack_C2E(ex)


                elif self.victim_model_args.id2label_dict[ori_label] == 'entailment':
                    # target_label = self.victim_model_args.label2id_dict['neutral']
                    with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
                        f.write("{}\t".format(idx))
                    logger.info("------------{}: E2N ------------".format(idx))
                    attack_text, n_query, success  = self._attack_E2N(ex)


                    # target_label = self.victim_model_args.label2id_dict['contradiction']
                    with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
                        f.write("{}\t".format(idx))
                    logger.info("------------{}: E2C ------------".format(idx))
                    attack_text, n_query, success  = self._attack_E2C(ex)


    def _attack_same_label(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []

        self.this_vp = []
        self.this_np = []

        if self.victim_model_args.id2label_dict[ori_label] != 'entailment':
            # add p's pp to the database
            p_0_annotation = self.client.annotate(p_0).sentence[0]
            p_tokens = [t.word for t in p_0_annotation.token]
            p_pp = set(find_node_idx_and_parent(parseTree2str(p_0_annotation.parseTree),  'PP '))
            for pp in p_pp:
                if pp[1] - pp[0] < len(p_tokens) * 0.7:
                    if pp[-1] == 'VP':
                        self.this_vp.append(' '.join(p_tokens[pp[0]:pp[1]+1]))
                    elif pp[-1] == 'NP':
                        self.this_np.append(' '.join(p_tokens[pp[0]:pp[1]+1]))


        while (n_query < self.max_queries):
            # h_order = self._attack_order(p, h, ori_label, h_fea)
            # n_query += len(h_order)
            # query_text = []
            save_text1 = []
            save_method1 = []
            save_score1 = []
            save_text2 = []
            save_method2 = []
            save_score2 = []
            if self.victim_model_args.id2label_dict[ori_label] == 'entailment':
                new_text1 = []
                method1 = []
                score1 = []

                # # one time
                # new_text1, method1, score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                #                                            ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                #                                            pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                #                                            op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                #                                            relations=h_fea['natlog_relations'], done=done)
                # find h ent_f
                new_text2, method2, score2, \
                save_text2, save_method2, save_score2 = self._find_ent_f(text=h, tokens=h_fea['tokens'], lemma=h_fea['lemma'],
                                                    ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                    pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                    op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                    relations=h_fea['natlog_relations'], done=done, eq=True)

                # two time
                if stg > 1:
                    # two time process
                    # one time
                    new_text1, method1, score1, \
                    save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                               ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                               pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                               op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                               relations=h_fea['natlog_relations'], done=done, eq=True)

                new_text = new_text1 + new_text2
                method = method1 + method2
                score = score1 + score2

                save_text = save_text1 + save_text2
                save_mehod = save_method1 + save_method2
                save_score = save_score1 + save_score2

                lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
                new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
                method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
                score = save_score + [score[sidx] for sidx in lm_scores_idx]

            else:

                new_text1 = []
                method1 = []
                score1 = []

                # new_text1, method1, score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                #                                            ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                #                                            pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                #                                            op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                #                                            relations=h_fea['natlog_relations'], done=done)

                # find h ent_r
                new_text2, method2, score2, \
                save_text2, save_method2, save_score2 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                    ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                    pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                    op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                    relations=h_fea['natlog_relations'], done=done, eq=True)
                # two time
                if stg > 1:
                    # two time process
                    new_text1, method1, score1, \
                    save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                               ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                               pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                               op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                               relations=h_fea['natlog_relations'], done=done, eq=True)
                new_text = new_text1+new_text2
                method = method1+method2
                score = score1+score2

                save_text = save_text1 + save_text2
                save_mehod = save_method1 + save_method2
                save_score = save_score1 + save_score2

                lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
                new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
                method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
                score = save_score + [score[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), ori_label)  for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)
                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != ori_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1
            else:
                if stg == 1:
                    stg +=1
                    continue

                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h="", ori_label=ori_label,
                    new_label=ori_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h="", ori_label=ori_label,
                        new_label=ori_label, predit=-1, query_num=n_query, method=done, success=0
                    ))


                return "", n_query, 0


        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=ori_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=ori_label, predit=predict, query_num=n_query, method=done, success=success
            ))


        return attack_text, n_query, success


    def _find_eq(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                 op, project_matrix, relations, done, eq=False):
        candidate = []
        new_text = []
        method = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # neg prefix + not
        # add not
        do_neg_prefix_eq = True
        for i in done:
            if 'neg_prefix' in i[0]:
                do_neg_prefix_eq = False
                break
        if do_neg_prefix_eq:
            # not_s, not_s_idx, lemma = get_not_sentence(tokens, lemma, pos)
            # candidate.extend([(i+' ' + get_subsentence(not_s, lemma), ('neg_prefix_eq', [-1]*len(simple_tokenize(i)) + not_s_idx))
            #                   for i in self.neg_prefix])
            for (not_s, not_s_idx, lemma) in get_not_sentence(tokens, lemma, pos):
                candidate.extend([(i+' ' + get_subsentence(not_s, lemma), ('neg_prefix_eq', [-1]*len(simple_tokenize(i)) + not_s_idx))
                                  for i in self.neg_prefix])

        # # bert find eq
        # for t in range(len(tokens)):
        #     if pos[t] in ['NN', 'JJ', 'RB', 'VB']:
        #         bert_input = token2sentence(tokens[:t] + ['[MASK]'] +tokens[t+1:])
        #         ins_token = self._lm_predict(bert_input)
        #
        #         # word_range = [self._lm_sentence_sim(tokens[t], i) for i in ins_token ]
        #         # bert_token = ins_token
        #         ins_token = [i for i in ins_token if i!=tokens[t] and self._lm_sentence_sim(tokens[t], i) > self.EQ_THRE]
        #         bert_text = [token2sentence(tokens[:t] + [ins_t] +tokens[t+1:]) for ins_t in ins_token]
        #         # candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t+1:]))
        #         #                   for s in bert_text
        #         #                   if self.client.annotate(s).sentence[0].token[t].pos[0:2] == pos[t] and self._lm_sim(text, s)>self.EQ_THRE])
        #         candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t+1:]))
        #                             for s in bert_text
        #                             if self.client.annotate(s).sentence[0].token[t].pos[0:2] == pos[t]])

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.BERT_EQ]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.BERT_EQ])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_ent_f(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                    op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        scores = []
        candidate = []
        candidate_pp = []
        candidate_save_pp = []
        saved_text = []
        saved_method = []
        saved_scores = []

        if self.method_pp:
            # 1. structure pp
            # structure if up then delete pp
            # structure if down then add pp
            # (1, [0,1,2,...,-1])
            do_pp = True
            for i in done:
                if i[0] == 'pp':
                    do_pp = False
            if do_pp:
                n_idx_list = get_n(pos) + get_prp(pos)
                # n_idx_list = get_n(pos)
                pp = set(find_node_idx_and_parent(parseTree, 'PP '))
                # structure if up then delete pp
                for t in pp:
                    if polarity_dirs[t[0]] == self.map_project_dir['up']:
                        if len(lemma) < 2:
                            continue
                        if lemma[t[0]-1] == 'be' or (lemma[t[0]-2] == 'be' and pos[t[0]-1] == 'JJ'):
                            continue
                        if t[0] == 0:
                            this_t = token2sentence(tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                        else:
                            this_t = token2sentence(tokens[:t[0]] + tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[:t[0]] + ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                # structure if down then add pp
                # down monotone, for n/v without pp only
                # candidate_method = []
                for idx in range(len(tokens)):
                    if (polarity_dirs[idx] == self.map_project_dir['down']) and (idx in n_idx_list):  # v简化为句子结尾
                        # (idx in n_idx_list + v_idx_list):

                        if (idx < len(tokens)-1) and pos[idx+1] == 'IN':
                            continue

                        #add pp   np后加pp, vp后加pp，简化为n后加pp，句子结尾加pp
                        # if pos[idx][0:2] == 'NN':
                        if idx in n_idx_list:
                            pre_c = token2sentence(tokens[:idx+1])
                            pre_idx = ori_token_idx[:idx+1]
                            if (idx < len(tokens)-1):
                                after_c = token2sentence(tokens[idx+1:])
                                after_idx = ori_token_idx[idx+1:]
                            else:
                                after_c = ''
                                after_idx=[]
                            for pp in self.this_np:
                                if pp in text:
                                    continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m =("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_save_pp:
                                    candidate_save_pp.append((content, content_m))

                            for pp in self.np_pp_db:
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m = ("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_pp:
                                    candidate_pp.append((content, content_m))
                                    # candidate_method.append()
                        # # 应该为vp后加pp，简化为句子结尾加pp
                        # if pos[idx][0:2] == 'VB':
                        #     insert_idx = idx
                        #     # vt + n
                        #     if (idx < len(tokens)-1):
                        #         for insert_tmp in range(idx+1,len(tokens)):
                        #             if pos[insert_tmp][0:2] in ('NN', 'DT', 'CD'):
                        #                 insert_idx = insert_tmp
                        #             else:
                        #                 break
                        #         after_c = token2sentence(tokens[insert_idx+1:])
                        #         after_idx = ori_token_idx[insert_idx+1:]
                        #     else:
                        #         insert_idx = len(tokens)-1
                        #         after_c = ''
                        #         after_idx=[]
                        #
                        #     pre_c = token2sentence(tokens[:insert_idx+1])
                        #     pre_idx = ori_token_idx[:insert_idx+1]
                        #     for pp in self.vp_pp_db:
                        #         n = len(pp.split())
                        #         candidate.append((pre_c + ' ' + pp + ' ' + after_c).strip())
                        #         candidate_method.append(("pp", pre_idx + [-1]*n + after_idx))

                # vp pp
                if polarity_dirs[-1] == self.map_project_dir['down']:
                    for pp in self.this_vp:
                        if pp in text:
                            continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_save_pp:
                            candidate_save_pp.append((content, content_m))

                    for pp in self.vp_pp_db:
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_pp:
                            candidate_pp.append((content, content_m))
                            # candidate_method.append()

                # Use bert to choose first .
                lm_scores = [self._lm_score(cand[0]) for cand in candidate_pp]

                lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.PP_NUM]


                new_text.extend([candidate_pp[sidx][0] for sidx in lm_scores_idx])
                method.extend([candidate_pp[sidx][1] for sidx in lm_scores_idx])
                scores.extend(sorted(lm_scores)[0:self.PP_NUM])

                lm_save_scores = [self._lm_score(cand[0]) for cand in candidate_save_pp]
                save_num = len(lm_save_scores)//2
                lm_save_scores_idx = sorted(range(len(lm_save_scores)), key=lambda k: lm_save_scores[k], reverse=False)[0:save_num]
                saved_text.extend([candidate_save_pp[sidx][0] for sidx in lm_save_scores_idx])
                saved_method.extend([candidate_save_pp[sidx][1] for sidx in lm_save_scores_idx])
                saved_scores.extend(sorted(lm_save_scores)[0:save_num])


        if self.method_insert_delete:
            # 2. insert/delete
            # bert_insert if n/v down
            # delete NN/Adj/adv if up
            # (2, v) (2, n)
            adj_list = get_adj(pos)
            adv_list = get_adv(pos)
            for t in adj_list+adv_list:
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if tokens[t] in self.adv_ex or len(lemma) < 2:
                    continue
                # delete NN/Adj/adv if up
                if polarity_dirs[t] == self.map_project_dir['up']:
                    if len(lemma) < 2:
                        continue
                    if t > 0 and lemma[t-1] == 'be':
                        continue
                    content = token2sentence(tokens[:t] + tokens[t + 1:])
                    saved_text.append(content)
                    saved_method.append(("ins_del", ori_token_idx[:t] + ori_token_idx[t + 1:]))
                    saved_scores.append(self._lm_score(content))

            n_list = get_n(pos)
            v_list = get_v(pos)

            for t in n_list:
                # bert_insert if n/v down
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['down']:
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i)]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] + self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'JJ'])

            for t in v_list:
                # bert_insert if n/v down
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['down']:
                    # before
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] +self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] +tokens[t:]) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'RB'])
                    # after
                    bert_input = token2sentence(tokens[:t+1] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t+1] + [ins_t] +tokens[t+1:]) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t+1].pos[0:2] == 'RB'])

            # # bert score candidates
            # lm_scores = [self._lm_score(cand[0]) for cand in candidate]
            # lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.INS_DEL]
            #
            # new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
            # method.extend([candidate[sidx][1] for sidx in lm_scores_idx])

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            # a man/woman/lady/person/ -> someone somebody
            #

            for i in range(len(tokens)):
                if relations[i] is not None and 1 in project_matrix[i]:
                    if project_matrix[i].index(1) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(1) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(1) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(1) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(1) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(1) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores

    def _find_ent_r(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                    op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        scores = []
        candidate = []
        candidate_pp = []
        candidate_save_pp = []
        saved_text = []
        saved_method = []
        saved_scores = []


        if self.method_pp:
            # 1. structure pp
            # structure if down then delete pp
            # structure if up then add pp
            # (1, [0,1,2,...,-1])
            do_pp = True
            for i in done:
                if i[0] == 'pp':
                    do_pp = False
                    break
            if do_pp:
                n_idx_list = get_n(pos) + get_prp(pos)
                # n_idx_list = get_n(pos)
                pp = set(find_node_idx_and_parent(parseTree, 'PP '))
                # structure if down then delete pp
                for t in pp:
                    if len(lemma) < 2:
                        continue
                    if polarity_dirs[t[0]] == self.map_project_dir['down']:
                        if lemma[t[0]-1] == 'be' or (lemma[t[0]-2] == 'be' and pos[t[0]-1] == 'JJ'):
                            continue
                        if t[0] == 0:
                            this_t = token2sentence(tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                        else:
                            this_t = token2sentence(tokens[:t[0]] + tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[:t[0]] + ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))

                # structure if up then add pp
                # down monotone, for n/v without pp only
                # candidate_method = []
                for idx in n_idx_list:
                    if (polarity_dirs[idx] == self.map_project_dir['up']):  # v简化为句子结尾
                        # (idx in n_idx_list + v_idx_list):

                        if (idx < len(tokens)-1) and pos[idx+1] == 'IN':
                            continue

                        #add pp   np后加pp, vp后加pp，简化为n后加pp，句子结尾加pp
                        if idx in n_idx_list:
                        # if pos[idx][0:2] in == 'NN':
                            pre_c = token2sentence(tokens[:idx+1])
                            pre_idx = ori_token_idx[:idx+1]
                            if (idx < len(tokens)-1):
                                after_c = token2sentence(tokens[idx+1:])
                                after_idx = ori_token_idx[idx+1:]
                            else:
                                after_c = ''
                                after_idx=[]

                            for pp in self.this_np:
                                if pp in text:
                                    continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m =("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_save_pp:
                                    candidate_save_pp.append((content, content_m))

                            for pp in self.np_pp_db:
                                # if pp in text:
                                #     continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m = ("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_pp:
                                    candidate_pp.append((content, content_m))
                                    # candidate_method.append()
                        # # 应该为vp后加pp，简化为句子结尾加pp
                        # if pos[idx][0:2] == 'VB':
                        #     insert_idx = idx
                        #     # vt + n
                        #     if (idx < len(tokens)-1):
                        #         for insert_tmp in range(idx+1,len(tokens)):
                        #             if pos[insert_tmp][0:2] in ('NN', 'DT', 'CD'):
                        #                 insert_idx = insert_tmp
                        #             else:
                        #                 break
                        #         after_c = token2sentence(tokens[insert_idx+1:])
                        #         after_idx = ori_token_idx[insert_idx+1:]
                        #     else:
                        #         insert_idx = len(tokens)-1
                        #         after_c = ''
                        #         after_idx=[]
                        #
                        #     pre_c = token2sentence(tokens[:insert_idx+1])
                        #     pre_idx = ori_token_idx[:insert_idx+1]
                        #     for pp in self.vp_pp_db:
                        #         n = len(pp.split())
                        #         candidate.append((pre_c + ' ' + pp + ' ' + after_c).strip())
                        #         candidate_method.append(("pp", pre_idx + [-1]*n + after_idx))

                # vp pp
                if polarity_dirs[-1] == self.map_project_dir['up']:

                    for pp in self.this_vp:
                        if pp in text:
                            continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_save_pp:
                            candidate_save_pp.append((content, content_m))

                    for pp in self.vp_pp_db:
                        # if pp in text:
                        #     continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_pp:
                            candidate_pp.append((content, content_m))
                            # candidate_method.append()

                # Use bert to choose first 20.
                lm_scores = [self._lm_score(cand[0]) for cand in candidate_pp]
                lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.PP_NUM]
                new_text.extend([candidate_pp[sidx][0] for sidx in lm_scores_idx])
                method.extend([candidate_pp[sidx][1] for sidx in lm_scores_idx])
                scores.extend(sorted(lm_scores)[0:self.PP_NUM])

                lm_save_scores = [self._lm_score(cand[0]) for cand in candidate_save_pp]
                save_num = len(lm_save_scores)//2
                lm_save_scores_idx = sorted(range(len(lm_save_scores)), key=lambda k: lm_save_scores[k], reverse=False)[0:save_num]
                saved_text.extend([candidate_save_pp[sidx][0] for sidx in lm_save_scores_idx])
                saved_method.extend([candidate_save_pp[sidx][1] for sidx in lm_save_scores_idx])
                saved_scores.extend(sorted(lm_save_scores)[0:save_num])



        if self.method_insert_delete:
            # 2. insert/delete
            # bert_insert if n/v up
            # delete NN/Adj/adv if down
            # (2, v) (2, n)
            adj_list = get_adj(pos)
            adv_list = get_adv(pos)
            for t in adj_list+adv_list:
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if tokens[t] in self.adv_ex:
                    continue
                # delete NN/Adj/adv if down
                if polarity_dirs[t] == self.map_project_dir['down']:
                    if len(lemma) < 2:
                        continue
                    if t > 0 and lemma[t-1] == 'be':
                        continue
                    content = token2sentence(tokens[:t] + tokens[t + 1:])
                    saved_text.append(content)
                    saved_method.append(("ins_del", ori_token_idx[:t] + ori_token_idx[t + 1:]))
                    saved_scores.append(self._lm_score(content))

            n_list = get_n(pos)
            v_list = get_v(pos)

            for t in n_list:
                # bert_insert if n/v up
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['up']:
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) ]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] + self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'JJ'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                    #                   for s in bert_text
                    #                   ])

            for t in v_list:
                # bert_insert if n/v up
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['up']:
                    # if the v is be then skip
                    if lemma[t] == 'be':
                        continue

                    # before
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] +self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'RB'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                    #                   for s in bert_text
                    #                   ])
                    # after
                    bert_input = token2sentence(tokens[:t+1] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t+1] + [ins_t] +self._first_lower(tokens[t+1:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t+1].pos[0:2] == 'RB'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                    #                   for s in bert_text
                    #                   ])

            # # bert score candidates
            # lm_scores = [self._lm_score(cand[0]) for cand in candidate]
            # lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.INS_DEL]
            #
            # new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
            # method.extend([candidate[sidx][1] for sidx in lm_scores_idx])

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if relations[i] is not None and 2 in project_matrix[i]:
                    if project_matrix[i].index(2) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] +
                                                [-1]*len(simple_tokenize(j)) +
                                                ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(2) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(2) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(2) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(2) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(2) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_neg(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                    op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # add neg prefix
        do_neg_prefix_neg = True
        for i in done:
            if 'neg_prefix' in i[0]:
                do_neg_prefix_neg = False
                break
        if do_neg_prefix_neg:
            candidate.extend([(i+' ' + get_subsentence(text, lemma), ('neg_prefix_neg', [-1]*len(simple_tokenize(i)) + ori_token_idx))
                              for i in self.neg_prefix])

        do_not_neg= True
        for i in done:
            if 'not_neg' in i[0]:
                do_not_neg = False
                break
        if do_not_neg:
            # not_s, not_s_idx, lemma = get_not_sentence(tokens, lemma, pos)
            # candidate.extend([(not_s, ('not_neg', not_s_idx))])
            for (not_s, not_s_idx, lemma) in get_not_sentence(tokens, lemma, pos):
                candidate.extend([(not_s, ('not_neg', not_s_idx))])


        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if relations[i] is not None and 3 in project_matrix[i]:
                    if project_matrix[i].index(3) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(3) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(3) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(3) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(3) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(3) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_alt(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                  op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # bert find alt
        for t in range(len(tokens)):
            if ori_token_idx[t] == -1: # if you do alt twice on the same word, you can't predict the result
                continue
            if pos[t] in ['NN', 'JJ', 'RB', 'VB']:
                bert_input = token2sentence(tokens[:t] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
                ins_token = self._lm_predict(bert_input)

                # word_range = [self._lm_sentence_sim(tokens[t], i) for i in ins_token ]
                # bert_token = ins_token
                ins_token = [i for i in ins_token if self._is_word(i) and i!=tokens[t] and self._lm_word_sim(tokens[t], i) < self.ALT_THRE]
                bert_text = [token2sentence(tokens[:t] + [ins_t] +self._first_lower(tokens[t+1:])) for ins_t in ins_token]
                # candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                #                   for s in bert_text
                #                   if self.client.annotate(bert_text[0]).sentence[0].token[t].pos[0:2] == pos[t] and self._lm_sim(text, s)>self.EQ_THRE])
                candidate.extend([(s, ('bert_alt', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                  for s in bert_text
                                  if self.client.annotate(bert_text[0]).sentence[0].token[t].pos[0:2] == pos[t]])



        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if ori_token_idx[i] == -1: # if you do alt twice on the same word, you can't predict the result
                    continue
                if relations[i] is not None and 4 in project_matrix[i]:
                    if project_matrix[i].index(4) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(4) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(4) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(4) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(4) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(4) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_cov(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                  op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if ori_token_idx[i] == -1: # if you do cov twice on the same word, you can't predict the result
                    continue
                if relations[i] is not None and 5 in project_matrix[i]:
                    if project_matrix[i].index(5) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(5) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(5) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(5) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(5) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(5) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _attack_E2C(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['contradiction']


        while (n_query < self.max_queries):
            save_text = []
            save_method = []
            save_score = []
            save_text2 = []
            save_method2 = []
            save_score2 = []

            # one time
            if n_query == 0: # only do the first time
                new_text, method, score, \
                save_text, save_method, save_score = self._find_neg(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                       ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                       pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                       op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                       relations=h_fea['natlog_relations'], done=done)

            new_text2, method2, score2, \
            save_text2, save_method2, save_score2 = self._find_alt(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                          ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                          pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                          op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                          relations=h_fea['natlog_relations'], done=done)

            # two time
            if stg > 1:
                # two time process
                pass

            # new_text = new_text1+new_text2
            # method = method1+method2
            # score = score1+score2
            save_text = save_text + save_text2
            save_mehod = save_method + save_method2
            save_score = save_score + save_score2

            lm_scores_idx = sorted(range(len(score2)), key=lambda k: score2[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
            new_text = save_text + new_text+ [new_text2[sidx] for sidx in lm_scores_idx]
            method = save_mehod + method + [method2[sidx] for sidx in lm_scores_idx]
            score = save_score + score + [score2[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)

                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != target_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1
            else:
                if stg == 1:
                    stg +=1
                    continue
                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                        new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                    ))

                return "", n_query, 0

        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))

        return attack_text, n_query, success


    def _attack_E2N(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['neutral']

        while (n_query < self.max_queries):
            save_text1 = []
            save_method1 = []
            save_score1 = []
            save_text2 = []
            save_method2 = []
            save_score2 = []

            # one time
            new_text1, method1, score1, \
            save_text1, save_method1, save_score1 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                        ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                        pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                        op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                        relations=h_fea['natlog_relations'], done=done, eq=False)



            new_text2, method2, score2, \
            save_text2, save_method2, save_score2 = self._find_cov(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                        ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                        pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                        op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                        relations=h_fea['natlog_relations'], done=done)

            # two time
            if stg > 1:
                # two time process
                pass

            new_text = new_text1+new_text2
            method = method1+method2
            score = score1+score2

            save_text = save_text1 + save_text2
            save_mehod = save_method1 + save_method2
            save_score = save_score1 + save_score2

            lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
            new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
            method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
            score = save_score + [score[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)
                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != target_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1

            else:
                if stg == 1:
                    stg +=1
                    continue
                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                        new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                    ))
                return "", n_query, 0

        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))

        return attack_text, n_query, success

    def _attack_C2E(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['entailment']

        while (n_query < self.max_queries):
            save_text1 = []
            save_method1 = []
            save_score1 = []
            save_text2 = []
            save_method2 = []
            save_score2 = []

            if n_query == 0:
                new_text = [i+' ' + get_subsentence(h, h_fea["lemma"]) for i in self.neg_prefix]
                method = [("neg_prefix", [-1]*len(simple_tokenize(i))+h_token_idx)
                          for i in self.neg_prefix]
            else:
                # one time
                new_text1, method1, score1, \
                save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                           ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                           pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                           op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                           relations=h_fea['natlog_relations'], done=done)

                new_text2, method2, score2, \
                save_text2, save_method2, save_score2 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                              ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                              pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                              op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                              relations=h_fea['natlog_relations'], done=done)

                # two time
                if stg > 1:
                    # two time process
                    pass

                new_text = new_text1+new_text2
                method = method1+method2
                score = score1+score2

                save_text = save_text1 + save_text2
                save_mehod = save_method1 + save_method2
                save_score = save_score1 + save_score2

                lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
                new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
                method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
                score = save_score + [score[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)

                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != target_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1
            else:
                if stg == 1:
                    stg +=1
                    continue
                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                        new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                    ))


                return "", n_query, 0


        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))


        return attack_text, n_query, success


    def _attack_order(self, p, h, ori_label, h_fea):
        # p = ex['text']
        # # h = ex['text_b']
        # ori_label = ex['label']
        mask = '[MASK]'
        h_list = h_fea['tokens'].copy()

        # # # test
        # # ex['h_tokens'][5] = mask
        # ######## multitimes order
        # change_idx = []
        #
        #
        # for j in range(len(h_list)):
        #     new_text = list()
        #     for i in range(len(h_list)):
        #         newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
        #         new_text.append(((p, newh), 0))
        #     _, pred_probs, _, _ = self.victim_model_predict_fn(new_text,
        #                                                                                 self.victim_model,
        #                                                                                 self.tokenizer,
        #                                                                                 self.victim_model_args)
        #
        #     probs = pred_probs[:, ori_label]
        #     probs_idx = sorted(range(len(probs)), key=lambda k: probs[k], reverse=False)
        #     probs_idx = [k for k in probs_idx if k not in change_idx]
        #     change_idx.append(probs_idx[0])
        #     h_list[probs_idx[0]] = mask
        #     change_idx.append(probs_idx[0])
        # return change_idx

        ######## onetime order
        new_text = list()
        for i in range(len(h_list)):
            newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
            new_text.append(((p, newh), 0))
        pred_logits, _, _ = self.victim_model_predict_fn(new_text,
                                                           self.victim_model,
                                                           self.tokenizer,
                                                           self.victim_model_args)

        logits = pred_logits[:, ori_label]
        logits_idx = sorted(range(len(logits)), key=lambda k: logits[k], reverse=False)

        return logits_idx

    def _trans_word_list(self, lemma_list, pos):
        new_list = []
        for w in lemma_list:
            new_w = getInflection(w, pos)
            if len(new_w) > 0:
                new_list.append(new_w[0])
            else:
                new_list.append(w)
        return new_list

    def _find_wordnet_relations(self, example):
        relations = []
        for(i, (postag, token, lemma, polarity, project_matrix, op)) in enumerate(zip(example['pos'],
                                                                        example['tokens'],
                                                                        example['lemma'],
                                                                        example['polarity_dirs'],
                                                                        example['project_matrix'],
                                                                        example['operators'])):

            if postag[0:2] in ['NN', 'JJ', 'RB', 'VB']:  # n, adj, adv, v
                pos_map = {'NN': 'n', 'JJ': 'a', 'RB': 'r', 'VB': 'v'}
                # synset_id = self.wordnet.get_synset_id(token, example['text'], i, pos_map[postag[0:2]])
                if lemma == 'be' and postag[0:2] == 'VB':
                    relations.append(None)
                    continue
                if lemma in ["Tom", "John"]:
                    relations.append(None)
                    continue
                if lemma in ["none", "no"]:
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ["some", "all"], 'alt': []})
                if lemma == "nobody":
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ["some people"], 'alt': []})
                elif lemma == "not":
                    relations.append({'eq': ['never'], 'ent_f': [], 'ent_r': ['hardly', "scarcely"], 'neg': ["some", "all"], 'alt': []})
                elif lemma == "never":
                    relations.append({'eq': ['not'], 'ent_f': ['hardly', "scarcely"], 'ent_r': [], 'neg': ["some", "all"], 'alt': []})
                elif lemma == "several":
                    relations.append({'eq': ["some", "a few"], 'ent_f': [],
                                      'ent_r': ['three', 'four', 'five', 'six', 'seven', '3', '4', '5', '6', '7'],
                                      'neg': ["no"], 'alt': []})

                else:
                    eq = self.wordnet.get_eq(lemma, pos_map[postag[0:2]])
                    ent_f = self.wordnet.get_ent_f(lemma, pos_map[postag[0:2]], stack=2)
                    ent_r = self.wordnet.get_ent_r(lemma, pos_map[postag[0:2]], stack=2)
                    neg = self.wordnet.get_neg(lemma, pos_map[postag[0:2]])
                    alt = self.wordnet.get_alt(lemma, pos_map[postag[0:2]], stack=2)
                    relations.append({'eq': self._trans_word_list(eq, postag),
                                      'ent_f': self._trans_word_list(ent_f, postag),
                                      'ent_r': self._trans_word_list(ent_r, postag),
                                      'neg': [],
                                      'alt': self._trans_word_list(neg + alt, postag)})

                # search the wn
            elif postag[0:2] == 'IN': # before, after, inside, outside, with, within, without
                if lemma == 'before':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['after']})
                elif lemma == 'after':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['before']})
                if lemma == 'above':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['below']})
                elif lemma == 'below':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['above']})
                elif lemma == 'inside':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['outside']})
                elif lemma == 'outside':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': ['inside']})
                elif lemma == 'within':
                    relations.append({'eq': ['with'], 'ent_f': [], 'ent_r': [], 'neg': ['without'], 'alt': []})
                elif lemma == 'with':
                    relations.append({'eq': ['within'], 'ent_f': [], 'ent_r': [], 'neg': ['without'], 'alt': []})
                elif lemma == 'without':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': [], 'neg': ['with', 'within'], 'alt': []})
                else:
                    relations.append(None)

            elif postag[0:2] == 'CD': # cardinal number
                number_text = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']
                number = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
                one_other = ['a', 'an']
                order = 'non'
                some = ['some', 'a few', 'several', 'a group of', 'many']
                ent_f = []
                if lemma not in number_text and lemma not in number:
                    relations.append(None)
                else:
                    if lemma in number_text:
                        num_idx = number_text.index(lemma)
                        eq = [number[num_idx]]
                    elif lemma in number:
                        num_idx = int(lemma)-1
                        eq = [number_text[num_idx]]
                    if num_idx == 0:
                        eq.extend(one_other)
                    else:
                        ent_f.extend(some)

                    rels = {'eq': eq, 'ent_f': [], 'ent_r': [], 'neg': [], 'alt': []}
                    # Only
                    if "only" in example["tokens"] or "exactly" in example["tokens"]:
                        order = 'non'
                    else:
                        if i > 0:
                            if example['lemma'][i-1] == 'least':
                                order = 'small_highest'
                            elif example['lemma'][i-1] == 'most':
                                order = 'big_highest'
                            if i > 2:
                                if example['lemma'][i-2:i] == ['more', 'than']:
                                    order = 'small_highest'
                                elif example['lemma'][i-2:i] == ['less', 'than']:
                                    order = 'big_highest'
                            if i > 3:
                                if example['lemma'][i-3:i] == ['no', 'less', 'than']:
                                    order = 'small_highest'
                                elif example['lemma'][i-3:i] == ['no', 'more', 'than']:
                                    order = 'big_highest'

                            big = number_text[num_idx+1:] + number[num_idx+1:]
                            small = number_text[:num_idx] + number[:num_idx] + one_other
                            if order == 'big_highest':
                                rels = {'eq': eq, 'ent_f': big , 'ent_r': small, 'neg': ['no'], 'alt': []}
                            elif order == 'small_highest':
                                rels = {'eq': eq, 'ent_f': small + ['some', 'a few', 'several', 'a group of', 'many'], 'ent_r': big, 'neg': ['no'], 'alt': []}
                            elif order == 'non':
                                rels = {'eq': eq, 'ent_f': [] , 'ent_r': [], 'neg': ['no'], 'alt': []}

                    relations.append(rels)


            elif postag[0:2] == 'DT': # determinator
                if lemma == 'a':
                    if example['pos'][i+1][0] == 'N':
                        relations.append({'eq': ['one', 'the'], 'ent_f': [],
                                          'ent_r': ['some', 'a few', 'several', 'a group of', 'many', 'every', 'all', 'each'],
                                          'neg': ['no'], 'alt': []})
                    else:
                        relations.append(None)
                elif lemma == 'the':
                    relations.append({'eq': ['one', 'a', 'an'], 'ent_f': [],
                                      'ent_r': ['some', 'a few', 'several', 'a group of', 'many', 'every', 'all', 'each'],
                                      'neg': ['no'], 'alt': []})
                elif lemma == 'every':
                    relations.append({'eq': ['all', 'each'],
                                      'ent_f': ['some', 'a few', 'several', 'a group of', 'many', 'one', 'the', 'a', 'an'],
                                      'ent_r': [], 'neg': ['no'], 'alt': ['']})
                elif lemma == 'all':
                    relations.append({'eq': ['every', 'each'],
                                      'ent_f': ['some', 'a few', 'several', 'a group of', 'many', 'one', 'the', 'a', 'an'],
                                      'ent_r': [], 'neg': ['no'], 'alt': ['']})
                elif lemma == 'each':
                    relations.append({'eq': ['every', 'all'],
                                      'ent_f': ['some', 'a few', 'several', 'a group of', 'many', 'one', 'the', 'a', 'an'],
                                      'ent_r': [], 'neg': ['no'], 'alt': ['']})
                elif lemma == 'some':
                    relations.append({'eq': ['a few', 'several', 'a group of', 'many'],
                                      'ent_f': ['one', 'the', 'a', 'an'],
                                      'ent_r': ["all", 'every', 'each', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
                                                '3', '4', '5', '6', '7', '8', '9', '10'],
                                      'neg': ['no'], 'alt': ['']})
                elif lemma == 'none':
                    relations.append({'eq': ['no one'],
                                      'ent_f': [], 'ent_r': [], 'neg': ['some', 'all'], 'alt': ['']})
                else:
                    eq = self.wordnet.get_eq(lemma)
                    ent_f = self.wordnet.get_ent_f(lemma, stack=2)
                    ent_r = self.wordnet.get_ent_r(lemma,  stack=2)
                    neg = self.wordnet.get_neg(lemma)
                    alt = self.wordnet.get_alt(lemma, stack=2)
                    relations.append({'eq':  self._trans_word_list(eq, postag),
                                      'ent_f':  self._trans_word_list(ent_f, postag),
                                      'ent_r':  self._trans_word_list(ent_r, postag),
                                      'neg':  self._trans_word_list(neg, postag),  #should be fine
                                      'alt':   self._trans_word_list(alt, postag)})

            else:
                if token == 'he':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["they", "Sam", "Tom", "Harry", "Ben"], 'neg': [], 'alt': ['she']})
                elif token == 'she':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["they", "Mary", "Susan", "Alice"], 'neg': [], 'alt': ['he']})
                elif token == 'his':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["their"], 'neg': [], 'alt': ['her']})
                elif token == 'him':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["them"], 'neg': [], 'alt': ['her']})
                elif token == 'her':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["their"], 'neg': [], 'alt': ['his']})
                elif token == 'I':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["we"], 'neg': [], 'alt': ["he", "she", "Sam", "Tom", "Harry", "Ben", "Mary", "Susan", "Alice"]})
                elif token == 'my':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["our"], 'neg': [], 'alt': ["his", "her"]})
                elif token == 'me':
                    relations.append({'eq': [], 'ent_f': [], 'ent_r': ["us"], 'neg': [], 'alt': ["them"]})
                elif token == 'we':
                    relations.append({'eq': [], 'ent_f': ["I"], 'ent_r': [], 'neg': [], 'alt': []})
                elif token == 'they':
                    relations.append({'eq': [], 'ent_f': ["one person", "people"], 'ent_r': [], 'neg': [], 'alt': []})

                else:
                    relations.append(None)

        return  relations


    def _analyze_example_with_corenlp(self, text):
        feature = dict()
        feature['parseTree'] = None
        feature['basicDependencies'] = None
        feature["tokens"] = []
        feature["lemma"] = []
        feature["pos"] = []
        # feature["h_polarities"] = []
        feature["polarity_dirs"] = []
        feature["operators"] = []
        feature["project_matrix"] = []
        for s in self.client.annotate(text).sentence:  # acutually only return the first sent
            feature['parseTree'] = parseTree2str(s.parseTree)
            feature["tokens"].extend([t.word for t in s.token])
            feature["lemma"].extend([t.lemma for t in s.token])
            feature["pos"].extend([t.pos for t in s.token])
            feature["polarity_dirs"].extend([self.map_project_dir[t.polarity_dir] for t in s.token])
            feature["basicDependencies"] = s.basicDependencies

            for t in s.token:
                op = dict()
                polarity = dict()
                project_matrix = list()
                op["name"] = t.operator.name
                op["quant_span_s"] = t.operator.quantifierSpanBegin
                op["quant_span_e"] = t.operator.quantifierSpanEnd
                op["sub_span_s"] = t.operator.subjectSpanBegin
                op["sub_span_e"] = t.operator.subjectSpanEnd
                op["obj_span_s"] = t.operator.objectSpanBegin
                op["obj_span_e"] = t.operator.objectSpanEnd

                polarity["project_eq"] = t.polarity.projectEquivalence
                polarity["project_ent_f"] = t.polarity.projectForwardEntailment
                polarity["project_ent_r"] = t.polarity.projectReverseEntailment
                polarity["project_neg"] = t.polarity.projectNegation
                polarity["project_alt"] = t.polarity.projectAlternation
                polarity["project_cov"] = t.polarity.projectCover
                polarity["project_ind"] = t.polarity.projectIndependence

                if op["name"] == '':
                    op = {}
                # else:
                #     op["quant_span_s"] += feature["h_length"]
                #     op["quant_span_e"] += feature["h_length"]
                #     op["sub_span_s"] += feature["h_length"]
                #     op["sub_span_e"] += feature["h_length"]
                #     op["obj_span_s"] += feature["h_length"]
                #     op["obj_span_e"] += feature["h_length"]

                for key in ["project_eq", "project_ent_f", "project_ent_r",
                            "project_neg", "project_alt", "project_cov", "project_ind"]:
                    project_matrix.append(polarity[key])

                feature["operators"].append(op)
                # feature['h_polarities'].append(polarity)
                feature["project_matrix"].append(project_matrix)

            # feature = self._correct_natlog_corenlp(s, feature)

            return feature

    def _correct_natlog_corenlp(self, ex):

        # no longer, never, hardly
        never_idx_list = has_sublist_idx(ex['tokens'], ['never'])
        hardly_idx_list = has_sublist_idx(ex['tokens'], ['hardly'])
        scarcely_idx_list = has_sublist_idx(ex['tokens'], ['scarcely'])
        one_token_idx_list = never_idx_list+hardly_idx_list+scarcely_idx_list
        no_longer_idx_list = has_sublist_idx(ex['tokens'], ['no', 'longer'])
        two_token_idx_list = no_longer_idx_list
        not_list = one_token_idx_list + two_token_idx_list
        if len(not_list) > 0:
            not_map = []   #[(ori_s, ori_e, new_s, new_d, same_word_or_not)]  ori: no longer,, new: not
            not_tokens = []
            ori_s = 0
            ori_e = 0
            new_s = 0
            new_e = 0
            skip = 0
            for idx in range(len(ex['tokens'])):
                if skip != 0:
                    skip -= 1
                    continue
                if idx not in not_list:
                    ori_e += 1
                    new_e += 1
                    not_tokens.append(ex['tokens'][idx])
                else:
                    not_map.append((ori_s, ori_e-1, new_s, new_e-1, True))
                    not_tokens.append("not")
                    # not word
                    if idx in one_token_idx_list:
                        not_map.append((ori_e, ori_e, new_e, new_e, False))
                        ori_s = ori_e+1
                        ori_e = ori_s
                        new_s = new_e+1
                        new_e = new_s
                    elif idx in two_token_idx_list:
                        skip = 1
                        not_map.append((ori_e, ori_e+1, new_e, new_e, False))
                        ori_s = ori_e+2
                        ori_e = ori_s
                        new_s = new_e+1
                        new_e = new_s
            not_map.append((ori_s, ori_e-1, new_s, new_e-1, True))
            not_sent = token2sentence(not_tokens)
            not_fea = self._analyze_example_with_corenlp(not_sent)
            new_dirs = []
            new_project = []
            for (o_1, o_2, n_1, n_2, same) in not_map:
                if same:
                    for i in range(n_1, n_2+1):
                        new_dirs.append(not_fea['polarity_dirs'][i])
                        new_project.append(not_fea['project_matrix'][i])
                else:
                    for i in range(o_1, o_2+1):
                        new_dirs.append(not_fea['polarity_dirs'][n_1])
                        new_project.append(not_fea['project_matrix'][n_1])
            ex['polarity_dirs'] = new_dirs
            ex['project_matrix'] = new_project

        # alien -> NN
        if "alien" in ex['tokens']:
            flag = False
            idx_list = has_sublist_idx(ex['tokens'], ['alien'])
            new_tokens = ex['tokens'].copy()
            for idx in idx_list:
                if idx+1 < len(ex['tokens']) and ex['pos'][idx+1][0:2] in ["VB", "PO", "IN"]:
                    new_tokens[idx] = 'foreigner'
                    flag = True
            if flag:
                new_fea = self._analyze_example_with_corenlp(token2sentence(new_tokens))
                ex['pos'] = new_fea['pos']
                ex['polarity_dirs'] = new_fea['polarity_dirs']
                ex['project_matrix'] = new_fea['project_matrix']
                ex['operators'] = new_fea['operators']

        # like -> vb
        if "like" in ex['tokens']:
            flag = False
            idx_list = has_sublist_idx(ex['tokens'], ['like'])
            new_tokens = ex['tokens'].copy()
            for idx in idx_list:
                if idx +1 >= len(ex['tokens']):
                    continue
                if idx+1 < len(ex['tokens']) and ex['pos'][idx+1][0:2] in ["TO"]:
                    new_tokens[idx] = 'love'
                    flag = True
                elif idx-1>0 and ex['pos'][idx+1][0:2] in ["NN"]:
                    new_tokens[idx] = 'love'
                    flag = True
            if flag:
                new_fea = self._analyze_example_with_corenlp(token2sentence(new_tokens))
                ex['pos'] = new_fea['pos']
                ex['polarity_dirs'] = new_fea['polarity_dirs']
                ex['project_matrix'] = new_fea['project_matrix']
                ex['operators'] = new_fea['operators']


        # CD
        # two man laugh in the park
        cd_list = get_cd(ex['pos'])
        if len(cd_list) > 0:
            for cd_idx in cd_list:
                if len(ex["operators"][cd_idx]) > 0:
                    nn_idx_list = range(ex["operators"][cd_idx]['sub_span_s'], ex["operators"][cd_idx]['sub_span_e'])
                else:
                    edge = [e for e in ex["basicDependencies"].edge if e.dep == "nummod"]
                    if len(edge) > 0:
                        nn_idx_list = [edge[0].source - 1]
                    else:
                        continue
                for nn_idx in nn_idx_list:
                    if ex['polarity_dirs'][cd_idx] != ex['polarity_dirs'][nn_idx]:
                        ex['polarity_dirs'][nn_idx] = ex['polarity_dirs'][cd_idx]
                        ex['project_matrix'][nn_idx] = swap_list_pos(ex['project_matrix'][nn_idx], 1, 2)

        # not -> all down e.g. Scientists haven't found a vaccine for carcinoma yet
        # it is not that a woman in red jacket do not put on makeup
        # no job and no play
        # not good currently
        neg_w = ['not', 'never', 'hardly', 'no', 'scarcely']
        flag = False
        if ex['polarity_dirs'][0] == self.map_project_dir['down'] and ex["lemma"][0] not in neg_w:
            ex['polarity_dirs'][0] = self.map_project_dir['up']
            ex['project_matrix'][0] = [0,1,2,3,4,5,6]
            if ex['pos'][0] != 'DT' and ex['tokens'][0] not in ['more', 'less']:
                flag = True
            if len(ex['pos']) > 1 and ex['tokens'][1] in ['most', 'least']:
                flag = False
        if flag:
            dir = 1
            s = 1
            not_num = 0
            for idx in range(1, len(ex["lemma"])):
                if ex["lemma"][idx] in neg_w:
                    not_num += 1
                    if dir == 1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['up']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,1,2,3,4,5,6]] * (idx + 1 - s)
                        s = idx + 1
                        dir = dir * (-1)
                    elif dir == -1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['down']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,2,1,4,6,4,6]] * (idx + 1 - s)
                        s = idx + 1
                        dir = dir * (-1)
                if ex["pos"][idx] == "CC":
                    if dir == 1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['up']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,1,2,3,4,5,6]] * (idx + 1 - s)
                        s = idx + 1
                    elif dir == -1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['down']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,2,1,4,6,4,6]] * (idx + 1 - s)
                        s = idx + 1


                    dir_idx = find_cc_start(ex['parseTree'], idx)
                    if ex['polarity_dirs'][dir_idx] == self.map_project_dir['up']:
                        dir = 1
                    elif ex['polarity_dirs'][dir_idx] == self.map_project_dir['down']:
                        dir = -1
            if not_num > 1:
                if dir == 1:
                    ex['polarity_dirs'][s:len(ex["lemma"])] = [self.map_project_dir['up']] * (len(ex["lemma"]) - s)
                    ex['project_matrix'][s:len(ex["lemma"])] = [[0,1,2,3,4,5,6]] * (len(ex["lemma"]) - s)
                elif dir == -1:
                    ex['polarity_dirs'][s:len(ex["lemma"])] = [self.map_project_dir['down']] * (len(ex["lemma"]) - s)
                    ex['project_matrix'][s:len(ex["lemma"])] = [[0,2,1,4,6,4,6]] * (len(ex["lemma"]) - s)

        else:
            if "CC" in ex["pos"]:
                idx = ex["pos"].index("CC")
                dir_idx = find_cc_start(ex['parseTree'], idx)

                if ex['polarity_dirs'][dir_idx] == self.map_project_dir['up']:
                    new_fea = self._analyze_example_with_corenlp(token2sentence(ex["tokens"][idx+1:]))
                    ex['polarity_dirs'][idx+1:] = new_fea['polarity_dirs']
                    ex['project_matrix'][idx+1:] = new_fea['project_matrix']
                elif ex['polarity_dirs'][dir_idx] == self.map_project_dir['down']:
                    new_fea = self._analyze_example_with_corenlp(token2sentence(ex["tokens"][idx+1:]))
                    tmp_dir = list()
                    tmp_project = list()
                    for i in new_fea['polarity_dirs']:
                        if i == self.map_project_dir["up"]:
                            tmp_dir.append(self.map_project_dir["down"])
                            tmp_project.append([0,2,1,4,6,4,6])
                        elif i == self.map_project_dir["down"]:
                            tmp_dir.append(self.map_project_dir["up"])
                            tmp_project.append([0,1,2,3,4,5,6])
                        else:
                            tmp_dir.append(self.map_project_dir["flat"])
                            tmp_project.append([0,6,6,6,6,6,6])
                    ex['polarity_dirs'][idx+1:] = tmp_dir
                    ex['project_matrix'][idx+1:] = tmp_project

        return ex


    def _process_text(self, text):
        ex = self._analyze_example_with_corenlp(text)
        ex['text'] = text
        ex = self._correct_natlog_corenlp(ex)
        ex['natlog_relations'] = self._find_wordnet_relations(ex)
        return ex



    def _lm_score(self, sentence):
        with torch.no_grad():
            tensor_input = self.lm_tokenizer.encode(sentence, return_tensors='pt').to(self.lm_device)
            repeat_input = tensor_input.repeat(tensor_input.size(-1)-2, 1)
            mask = torch.ones(tensor_input.size(-1) - 1).diag(1)[:-2].to(self.lm_device)
            masked_input = repeat_input.masked_fill(mask == 1, self.lm_tokenizer.encode('[MASK]')[1])
            labels = repeat_input.masked_fill(masked_input != self.lm_tokenizer.encode('[MASK]')[1], -100)

            loss = self.lm_model(masked_input, labels=labels)['loss']
            result = np.exp(loss.item())
            return result

    def _lm_predict(self, sentence):
        with torch.no_grad():
            inputs = self.lm_tokenizer.encode(sentence, return_tensors='pt')
            idx = torch.where((inputs == self.lm_tokenizer.encode('[MASK]')[1])>0)[-1].numpy()[0]
            pred_logits = self.lm_model(inputs.to(self.lm_device))['logits'].detach().cpu().numpy()
            pred = np.argsort(pred_logits.squeeze()[idx])[::-1][:self.NUM_PER_STEP]
            return [s.replace(' ', '') for s in self.lm_tokenizer.batch_decode(pred.tolist())]


    def _lm_word_sim(self, s1, s2):
        with torch.no_grad():
            tensor1 = self.lm_tokenizer.encode(s1, return_tensors='pt').to(self.lm_device)
            tensor2 = self.lm_tokenizer.encode(s2, return_tensors='pt').to(self.lm_device)
            embed1 = self.lm_model(tensor1, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[1,:]
            embed2 = self.lm_model(tensor2, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[1,:]
            return torch.nn.functional.cosine_similarity(embed1, embed2, dim=0).detach().cpu()

    def _lm_sentence_sim(self, s1, s2):
        with torch.no_grad():
            tensor1 = self.lm_tokenizer.encode(s1, return_tensors='pt').to(self.lm_device)
            tensor2 = self.lm_tokenizer.encode(s2, return_tensors='pt').to(self.lm_device)
            embed1 = self.lm_model(tensor1, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[0,:]
            embed2 = self.lm_model(tensor2, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[0,:]
            return torch.nn.functional.cosine_similarity(embed1, embed2, dim=0).detach().cpu()

    def _first_lower(self, t):
        s = [i for i in t]
        if len(s) > 0:
            s[0] = s[0].lower()
        return s

    def _is_word(self, t):
        if t[0].isalpha() or t[0].isdigit():
            return True
        else:
            return False


# class NegPrefix_Attack(object):
#     def __init__(self, victim_model, tokenizer, victim_model_args, victim_model_predict_fn, max_queries=500,
#                  pp_file_dir=None, method_pp=True, method_insert_delete=True, method_natlog=True, tag='',
#                  device='cpu'):
#         self.max_queries = max_queries
#         # self.method_pp = method_pp
#         # self.method_insert_delete=method_insert_delete
#         # self.method_natlog = method_natlog
#         # self.PP_NUM = 80
#         # self.BERT_EQ = 30
#         # self.EQ_THRE = 0.98
#         # self.ALT_THRE = 0.7
#         # # self.INS_DEL = 20
#         self.NUM_PER_STEP = 100
#         self.adv_ex =["n't", 'not', 'no', "never", "hardly", "scarcely", "rarely", "seldomly"]
#         self.neg_prefix = ['It is not true that',
#                            'It is false that',
#                            'It is not correct that',
#                            'It is not that',
#                            'It is not right that',
#                            'It is untrue that',
#                            'It is not true to say that',
#                            'It is wrong to say that',
#                            # 'no clue shows that',
#                            # 'it is unconfirmed that',
#                            # 'there is no evidence that'
#                            ]
#
#         # for victim model
#         self.victim_model = victim_model
#         self.tokenizer = tokenizer
#         self.victim_model_predict_fn = victim_model_predict_fn
#         self.victim_model_args = victim_model_args
#
#         # # for lm
#         # lm_model_name = "distilbert-base-uncased"
#         # lm_config = DistilBertConfig.from_pretrained(lm_model_name)
#         # self.lm_device = device
#         # self.lm_tokenizer = DistilBertTokenizer.from_pretrained(lm_model_name)
#         # self.lm_model = DistilBertForMaskedLM.from_pretrained(lm_model_name, config=lm_config).to(self.lm_device)
#         # # self.mask = '[MASK]'
#         # # # for insert
#         # # self.gen_model = BertPreTrainedModel.from_pretrained(lm_model_name, config=lm_config)
#
#         # # for natlog
#         # self.map_project_dir = {"up": 1, "down": 2, 'flat': 0}
#         # self.wordnet = NatlogWordNet(WORDNET_DIR, self.lm_model, self.lm_device)
#         # self.client = CoreNLPClient(annotators=['parse', 'natlog'], timeout=60000, memory='16G', threads=64)
#         #
#         # # for pp
#         # thre = 200
#         # # self.p_e = []
#         # # self.p_n = []
#         # # self.p_c = []
#         # # self.h_e = []
#         # # self.h_n = []
#         # # self.h_c = []
#         # # if pp_file_dir is not None:
#         # #     p_e_all = read_tsv(os.path.join(pp_file_dir, "p_e_pp.txt"))
#         # #     p_n_all = read_tsv(os.path.join(pp_file_dir, "p_n_pp.txt"))
#         # #     p_c_all = read_tsv(os.path.join(pp_file_dir, "p_c_pp.txt"))
#         # #     h_e_all = read_tsv(os.path.join(pp_file_dir, "h_e_pp.txt"))
#         # #     h_n_all = read_tsv(os.path.join(pp_file_dir, "h_n_pp.txt"))
#         # #     h_c_all = read_tsv(os.path.join(pp_file_dir, "h_c_pp.txt"))
#         # #     self.p_e = [(i[0], i[1]) for i in p_e_all if int(i[2]) > thre]
#         # #     self.p_n = [(i[0], i[1]) for i in p_n_all if int(i[2]) > thre]
#         # #     self.p_c = [(i[0], i[1]) for i in p_c_all if int(i[2]) > thre]
#         # #     self.h_e = [(i[0], i[1]) for i in h_e_all if int(i[2]) > thre]
#         # #     self.h_n = [(i[0], i[1]) for i in h_n_all if int(i[2]) > thre]
#         # #     self.h_c = [(i[0], i[1]) for i in h_c_all if int(i[2]) > thre]
#         #
#
#         # for log
#         # self.s1_file_name = "same_label_"+tag+"12.txt"
#         # self.s1_file_name = "debug.txt"
#         self.s2_c2e_file_name = "c2e_base.txt"
#         self.s2_e2c_file_name = "e2c_base.txt"
#         self.s2_e2n_file_name = "e2n_base.txt"
#         # self.s2_c2e_file_name = "debug.txt"
#         # self.s2_e2c_file_name = "debug.txt"
#         # self.s2_e2n_file_name = "debug.txt"
#         # method1 = "natlog12"
#         method2 = "natlog12s2"
#         # self.dir1 = os.path.join(HUMAN_DIR, method1)
#         self.dir2 = os.path.join(HUMAN_DIR, method2)
#         # if not os.path.exists(self.dir1):
#         #     os.mkdir(self.dir1)
#         if not os.path.exists(self.dir2):
#             os.mkdir(self.dir2)
#         # for continue
#
#
#     def attack(self, examples, setting=1):
#
#         with open(os.path.join(self.dir2, self.s2_c2e_file_name), "w") as f:
#             f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
#         with open(os.path.join(self.dir2, self.s2_e2c_file_name), "w") as f:
#             f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
#         with open(os.path.join(self.dir2, self.s2_e2n_file_name), "w") as f:
#             f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
#
#
#         for (idx, ex) in enumerate(examples):
#             # if int(ex['idx']) not in [42, 867, 495, 3685, 2872, 2672, 991, 3310]: # med
#             #     continue
#             # if int(ex['idx']) not in [657]: #snli
#             #     continue
#
#             # if int(ex['idx']) not in [1813, 2442, 4070, 4193, 4745, 4836, 4960, 5605, 5856, 5942, 6946, 7101, 7198, 7835, 7892, 8549, 9402, 9640]: #snli failed
#             #     continue
#             # if idx < 621:
#             #     continue
#             # if idx < 813:
#             #     continue
#             # p = ex['text_a']
#             # h = ex['text_b']
#             ori_label = ex['label']
#             # new_text = [((p, h), ori_label)]
#
#
#             if self.victim_model_args.id2label_dict[ori_label] == 'neutral':
#                 continue
#             elif self.victim_model_args.id2label_dict[ori_label] == 'contradiction':
#                 # target_label = self.victim_model_args.label2id_dict['entailment']
#                 with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
#                     f.write("{}\t".format(idx))
#                 logger.info("------------{}: C2E ------------".format(idx))
#                 attack_text, n_query, success = self._attack_C2E(ex)
#
#
#             elif self.victim_model_args.id2label_dict[ori_label] == 'entailment':
#                 # target_label = self.victim_model_args.label2id_dict['neutral']
#                 with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
#                     f.write("{}\t".format(idx))
#                 logger.info("------------{}: E2N ------------".format(idx))
#                 attack_text, n_query, success = self._attack_E2N(ex)
#
#
#                 # target_label = self.victim_model_args.label2id_dict['contradiction']
#                 with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
#                     f.write("{}\t".format(idx))
#                 logger.info("------------{}: E2C ------------".format(idx))
#                 attack_text, n_query, success  = self._attack_E2C(ex)
#
#     def _attack_E2C(self, ex):
#         attack_text = ''
#         p_0 = ex['text_a']
#         h_0 = ex['text_b']
#         h = ex['text_b']
#         ori_h = h
#         ori_label = ex['label']
#         h_fea = self._process_text(ex['text_b'])
#         h_token_idx = list(range(len(h_fea['tokens'])))
#         n_query = 0
#         idx_change = []
#         stg = 1
#         prev_ex = None
#         prev_h_fea = None
#         predict = ori_label
#         success = 0
#         done = []
#         target_label = self.victim_model_args.label2id_dict['contradiction']
#
#
#         while (n_query < self.max_queries):
#             save_text = []
#             save_method = []
#             save_score = []
#             save_text2 = []
#             save_method2 = []
#             save_score2 = []
#
#             # one time
#             if n_query == 0: # only do the first time
#
#                 new_text = []
#                 method = []
#                 candidate = []
#                 scores = []
#                 saved_text = []
#                 saved_method = []
#                 saved_scores = []
#
#                 # add neg prefix
#                 do_neg_prefix_neg = True
#                 for i in done:
#                     if 'neg_prefix' in i[0]:
#                         do_neg_prefix_neg = False
#                         break
#                 if do_neg_prefix_neg:
#                     candidate.extend([(i+' ' + get_subsentence(h, h_fea['lemma']), ('neg_prefix_neg', [-1]*len(simple_tokenize(i)) + h_token_idx))
#                                       for i in self.neg_prefix])
#
#                 do_not_neg= True
#                 for i in done:
#                     if 'not_neg' in i[0]:
#                         do_not_neg = False
#                         break
#                 if do_not_neg:
#                     # not_s, not_s_idx, lemma = get_not_sentence(tokens, lemma, pos)
#                     # candidate.extend([(not_s, ('not_neg', not_s_idx))])
#                     for (not_s, not_s_idx, h_fea['lemma']) in get_not_sentence(h_fea['tokens'], h_fea['lemma'], h_fea['pos']):
#                         candidate.extend([(not_s, ('not_neg', not_s_idx))])
#
#                 # bert score candidates
#                 lm_scores = [self._lm_score(cand[0]) for cand in candidate]
#                 lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]
#
#                 new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
#                 method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
#                 scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
#
#                 # new_text, method, score, \
#                 # save_text, save_method, save_score = self._find_neg(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
#                 #                                                     ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
#                 #                                                     pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
#                 #                                                     op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
#                 #                                                     relations=h_fea['natlog_relations'], done=done)
#
#
#             # # two time
#             # if stg > 1:
#             #     # two time process
#             #     pass
#             #
#             # # new_text = new_text1+new_text2
#             # # method = method1+method2
#             # # score = score1+score2
#             # save_text = save_text + save_text2
#             # save_mehod = save_method + save_method2
#             # save_score = save_score + save_score2
#             #
#             # lm_scores_idx = sorted(range(len(score2)), key=lambda k: score2[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
#             # new_text = save_text + new_text+ [new_text2[sidx] for sidx in lm_scores_idx]
#             # method = save_mehod + method + [method2[sidx] for sidx in lm_scores_idx]
#             # score = save_score + score + [score2[sidx] for sidx in lm_scores_idx]
#
#             # Remove the text same as p_0
#             remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
#             if len(remove_idx) > 0:
#                 new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
#                 method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
#                 score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]
#
#             # model attack
#             query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
#             if len(query_text) > 0:
#                 pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
#                                                                      self.tokenizer, self.victim_model_args)
#
#                 n_q_batch = -1
#                 for p_idx in range(len(preds)):
#                     if preds[p_idx] != target_label:   # Attack sucess
#                         n_q_batch = p_idx + 1
#                         attack_text = query_text[p_idx]
#                         done.append(method[p_idx])
#                         predict = preds[p_idx]
#                         success = 1
#                         break
#                 if n_q_batch != -1:
#                     # if attack sucess return
#                     n_query = n_query + n_q_batch
#                     break
#                 else:
#                     # else use the lowest one as the base
#                     n_query += len(preds)
#                     min_predict_idx = np.argmin(pred_logits[:,ori_label])
#                     prev_ex = ex
#                     prev_h_fea = h_fea
#                     ex['text_b'] = new_text[min_predict_idx]
#                     h = ex['text_b']
#                     h_fea = self._process_text(ex['text_b'])
#                     done.append(method[min_predict_idx])
#                     h_token_idx = method[min_predict_idx][-1]
#                     attack_text = query_text[min_predict_idx]
#                     # ex = lowest_one
#                     # h_fea = self._process_text(ex['text_b'])
#                     stg += 1
#             else:
#                 if stg == 1:
#                     stg +=1
#                     continue
#                 logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                     ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#                     new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#                 ))
#                 with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
#                     f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                         ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#                         new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#                     ))
#
#                 return "", n_query, 0
#
#         logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#             ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#             new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#         ))
#         with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
#             f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                 ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#                 new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#             ))
#
#         return attack_text, n_query, success
#
#
#     def _attack_E2N(self, ex):
#         attack_text = ''
#         p_0 = ex['text_a']
#         h_0 = ex['text_b']
#         h = ex['text_b']
#         ori_h = h
#         ori_label = ex['label']
#         h_fea = self._process_text(ex['text_b'])
#         h_token_idx = list(range(len(h_fea['tokens'])))
#         n_query = 0
#         idx_change = []
#         stg = 1
#         prev_ex = None
#         prev_h_fea = None
#         predict = ori_label
#         success = 0
#         done = []
#         target_label = self.victim_model_args.label2id_dict['neutral']
#
#         # while (n_query < self.max_queries):
#         #     save_text1 = []
#         #     save_method1 = []
#         #     save_score1 = []
#         #     save_text2 = []
#         #     save_method2 = []
#         #     save_score2 = []
#         #
#         #     # one time
#         #     new_text1, method1, score1, \
#         #     save_text1, save_method1, save_score1 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
#         #                                                              ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
#         #                                                              pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
#         #                                                              op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
#         #                                                              relations=h_fea['natlog_relations'], done=done, eq=False)
#         #
#         #
#         #
#         #     new_text2, method2, score2, \
#         #     save_text2, save_method2, save_score2 = self._find_cov(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
#         #                                                            ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
#         #                                                            pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
#         #                                                            op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
#         #                                                            relations=h_fea['natlog_relations'], done=done)
#         #
#         #     # two time
#         #     if stg > 1:
#         #         # two time process
#         #         pass
#         #
#         #     new_text = new_text1+new_text2
#         #     method = method1+method2
#         #     score = score1+score2
#         #
#         #     save_text = save_text1 + save_text2
#         #     save_mehod = save_method1 + save_method2
#         #     save_score = save_score1 + save_score2
#         #
#         #     lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
#         #     new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
#         #     method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
#         #     score = save_score + [score[sidx] for sidx in lm_scores_idx]
#         #
#         #     # Remove the text same as p_0
#         #     remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
#         #     if len(remove_idx) > 0:
#         #         new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
#         #         method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
#         #         score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]
#         #
#         #     # model attack
#         #     query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
#         #     if len(query_text) > 0:
#         #         pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
#         #                                                              self.tokenizer, self.victim_model_args)
#         #         n_q_batch = -1
#         #         for p_idx in range(len(preds)):
#         #             if preds[p_idx] != target_label:   # Attack sucess
#         #                 n_q_batch = p_idx + 1
#         #                 attack_text = query_text[p_idx]
#         #                 done.append(method[p_idx])
#         #                 predict = preds[p_idx]
#         #                 success = 1
#         #                 break
#         #         if n_q_batch != -1:
#         #             # if attack sucess return
#         #             n_query = n_query + n_q_batch
#         #             break
#         #         else:
#         #             # else use the lowest one as the base
#         #             n_query += len(preds)
#         #             min_predict_idx = np.argmin(pred_logits[:,ori_label])
#         #             prev_ex = ex
#         #             prev_h_fea = h_fea
#         #             ex['text_b'] = new_text[min_predict_idx]
#         #             h = ex['text_b']
#         #             h_fea = self._process_text(ex['text_b'])
#         #             done.append(method[min_predict_idx])
#         #             h_token_idx = method[min_predict_idx][-1]
#         #             attack_text = query_text[min_predict_idx]
#         #             # ex = lowest_one
#         #             # h_fea = self._process_text(ex['text_b'])
#         #             stg += 1
#         #
#         #     else:
#         #         if stg == 1:
#         #             stg +=1
#         #             continue
#         #         logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#         #                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#         #             ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#         #             new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#         #         ))
#         #         with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
#         #             f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#         #                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#         #                 ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#         #                 new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#         #             ))
#         #         return "", n_query, 0
#         #
#         # logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#         #             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#         #     ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#         #     new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#         # ))
#         # with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
#         #     f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#         #             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#         #         ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#         #         new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#         #     ))
#
#         return attack_text, n_query, success
#
#
#     def _attack_C2E(self, ex):
#         attack_text = ''
#         p_0 = ex['text_a']
#         h_0 = ex['text_b']
#         h = ex['text_b']
#         ori_h = h
#         ori_label = ex['label']
#         h_fea = self._process_text(ex['text_b'])
#         h_token_idx = list(range(len(h_fea['tokens'])))
#         n_query = 0
#         idx_change = []
#         stg = 1
#         prev_ex = None
#         prev_h_fea = None
#         predict = ori_label
#         success = 0
#         done = []
#         target_label = self.victim_model_args.label2id_dict['entailment']
#
#         while (n_query < self.max_queries):
#             save_text = []
#             save_method = []
#             save_score = []
#
#
#             if n_query == 0:
#                 new_text = [i+' ' + get_subsentence(h, h_fea["lemma"]) for i in self.neg_prefix]
#                 method = [("neg_prefix", [-1]*len(simple_tokenize(i))+h_token_idx)
#                           for i in self.neg_prefix]
#             # else:
#             #     # one time
#             #     new_text1, method1, score1, \
#             #     save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
#             #                                                           ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
#             #                                                           pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
#             #                                                           op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
#             #                                                           relations=h_fea['natlog_relations'], done=done)
#             #
#             #     new_text2, method2, score2, \
#             #     save_text2, save_method2, save_score2 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
#             #                                                              ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
#             #                                                              pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
#             #                                                              op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
#             #                                                              relations=h_fea['natlog_relations'], done=done)
#
#                 # two time
#                 if stg > 1:
#                     # two time process
#                     pass
#
#                 # new_text = new_text1+new_text2
#                 # method = method1+method2
#                 # score = score1+score2
#
#                 # save_text = save_text1 + save_text2
#                 # save_mehod = save_method1 + save_method2
#                 # save_score = save_score1 + save_score2
#
#                 lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
#                 new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
#                 method = save_method + [method[sidx] for sidx in lm_scores_idx]
#                 score = save_score + [score[sidx] for sidx in lm_scores_idx]
#
#             # Remove the text same as p_0
#             remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
#             if len(remove_idx) > 0:
#                 new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
#                 method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
#                 score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]
#
#             # model attack
#             query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
#             if len(query_text) > 0:
#                 pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
#                                                                      self.tokenizer, self.victim_model_args)
#
#                 n_q_batch = -1
#                 for p_idx in range(len(preds)):
#                     if preds[p_idx] != target_label:   # Attack sucess
#                         n_q_batch = p_idx + 1
#                         attack_text = query_text[p_idx]
#                         done.append(method[p_idx])
#                         predict = preds[p_idx]
#                         success = 1
#                         break
#                 if n_q_batch != -1:
#                     # if attack sucess return
#                     n_query = n_query + n_q_batch
#                     break
#                 else:
#                     # else use the lowest one as the base
#                     n_query += len(preds)
#                     min_predict_idx = np.argmin(pred_logits[:,ori_label])
#                     prev_ex = ex
#                     prev_h_fea = h_fea
#                     ex['text_b'] = new_text[min_predict_idx]
#                     h = ex['text_b']
#                     h_fea = self._process_text(ex['text_b'])
#                     done.append(method[min_predict_idx])
#                     h_token_idx = method[min_predict_idx][-1]
#                     attack_text = query_text[min_predict_idx]
#                     # ex = lowest_one
#                     # h_fea = self._process_text(ex['text_b'])
#                     stg += 1
#             else:
#                 if stg == 1:
#                     stg +=1
#                     continue
#                 logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                     ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#                     new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#                 ))
#                 with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
#                     f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                             "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                         ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
#                         new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
#                     ))
#
#
#                 return "", n_query, 0
#
#
#         logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#             ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#             new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#         ))
#         with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
#             f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
#                     "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
#                 ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
#                 new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
#             ))
#
#
#         return attack_text, n_query, success
#
#
#     def _attack_order(self, p, h, ori_label, h_fea):
#         # p = ex['text']
#         # # h = ex['text_b']
#         # ori_label = ex['label']
#         mask = '[MASK]'
#         h_list = h_fea['tokens'].copy()
#
#         # # # test
#         # # ex['h_tokens'][5] = mask
#         # ######## multitimes order
#         # change_idx = []
#         #
#         #
#         # for j in range(len(h_list)):
#         #     new_text = list()
#         #     for i in range(len(h_list)):
#         #         newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
#         #         new_text.append(((p, newh), 0))
#         #     _, pred_probs, _, _ = self.victim_model_predict_fn(new_text,
#         #                                                                                 self.victim_model,
#         #                                                                                 self.tokenizer,
#         #                                                                                 self.victim_model_args)
#         #
#         #     probs = pred_probs[:, ori_label]
#         #     probs_idx = sorted(range(len(probs)), key=lambda k: probs[k], reverse=False)
#         #     probs_idx = [k for k in probs_idx if k not in change_idx]
#         #     change_idx.append(probs_idx[0])
#         #     h_list[probs_idx[0]] = mask
#         #     change_idx.append(probs_idx[0])
#         # return change_idx
#
#         ######## onetime order
#         new_text = list()
#         for i in range(len(h_list)):
#             newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
#             new_text.append(((p, newh), 0))
#         pred_logits, _, _ = self.victim_model_predict_fn(new_text,
#                                                          self.victim_model,
#                                                          self.tokenizer,
#                                                          self.victim_model_args)
#
#         logits = pred_logits[:, ori_label]
#         logits_idx = sorted(range(len(logits)), key=lambda k: logits[k], reverse=False)
#
#         return logits_idx
#
#     def _trans_word_list(self, lemma_list, pos):
#         new_list = []
#         for w in lemma_list:
#             new_w = getInflection(w, pos)
#             if len(new_w) > 0:
#                 new_list.append(new_w[0])
#             else:
#                 new_list.append(w)
#         return new_list
#
#
#
#     def _process_text(self, text):
#         ex = self._analyze_example_with_corenlp(text)
#         ex['text'] = text
#         ex = self._correct_natlog_corenlp(ex)
#         ex['natlog_relations'] = self._find_wordnet_relations(ex)
#         return ex
#
#
#
#
#     def _first_lower(self, t):
#         s = [i for i in t]
#         if len(s) > 0:
#             s[0] = s[0].lower()
#         return s
#
#     def _is_word(self, t):
#         if t[0].isalpha() or t[0].isdigit():
#             return True
#         else:
#             return False


class NegPrefix_Attack(object):
    def __init__(self, victim_model, tokenizer, victim_model_args, victim_model_predict_fn, max_queries=500,
                 pp_file_dir=None, method_pp=True, method_insert_delete=True, method_natlog=True, tag='',
                 device='cpu'):
        self.max_queries = max_queries
        self.method_pp = method_pp
        self.method_insert_delete=method_insert_delete
        self.method_natlog = method_natlog
        self.PP_NUM = 80
        self.BERT_EQ = 30
        self.EQ_THRE = 0.98
        self.ALT_THRE = 0.7
        # self.INS_DEL = 20
        self.NUM_PER_STEP = 100
        self.adv_ex =["n't", 'not', 'no']
        self.neg_prefix = ['It is not true that',
                           'It is false that',
                           'It is not correct that',
                           'It is not that',
                           'It is not right that',
                           'It is untrue that',
                           'It is not true to say that',
                           'It is wrong to say that',
                           # 'no clue shows that',
                           # 'it is unconfirmed that',
                           # 'there is no evidence that'
                           ]

        # for victim model
        self.victim_model = victim_model
        self.tokenizer = tokenizer
        self.victim_model_predict_fn = victim_model_predict_fn
        self.victim_model_args = victim_model_args

        # for lm
        lm_model_name = "distilbert-base-uncased"
        lm_config = DistilBertConfig.from_pretrained(lm_model_name)
        self.lm_device = device
        self.lm_tokenizer = DistilBertTokenizer.from_pretrained(lm_model_name)
        self.lm_model = DistilBertForMaskedLM.from_pretrained(lm_model_name, config=lm_config).to(self.lm_device)
        # self.mask = '[MASK]'
        # # for insert
        # self.gen_model = BertPreTrainedModel.from_pretrained(lm_model_name, config=lm_config)

        # for natlog
        self.map_project_dir = {"up": 1, "down": 2, 'flat': 0}
        self.wordnet = NatlogWordNet(WORDNET_DIR, self.lm_model, self.lm_device)
        self.client = CoreNLPClient(annotators=['parse', 'natlog'], timeout=60000, memory='16G', threads=64)

        # for pp
        thre = 200
        # self.p_e = []
        # self.p_n = []
        # self.p_c = []
        # self.h_e = []
        # self.h_n = []
        # self.h_c = []
        # if pp_file_dir is not None:
        #     p_e_all = read_tsv(os.path.join(pp_file_dir, "p_e_pp.txt"))
        #     p_n_all = read_tsv(os.path.join(pp_file_dir, "p_n_pp.txt"))
        #     p_c_all = read_tsv(os.path.join(pp_file_dir, "p_c_pp.txt"))
        #     h_e_all = read_tsv(os.path.join(pp_file_dir, "h_e_pp.txt"))
        #     h_n_all = read_tsv(os.path.join(pp_file_dir, "h_n_pp.txt"))
        #     h_c_all = read_tsv(os.path.join(pp_file_dir, "h_c_pp.txt"))
        #     self.p_e = [(i[0], i[1]) for i in p_e_all if int(i[2]) > thre]
        #     self.p_n = [(i[0], i[1]) for i in p_n_all if int(i[2]) > thre]
        #     self.p_c = [(i[0], i[1]) for i in p_c_all if int(i[2]) > thre]
        #     self.h_e = [(i[0], i[1]) for i in h_e_all if int(i[2]) > thre]
        #     self.h_n = [(i[0], i[1]) for i in h_n_all if int(i[2]) > thre]
        #     self.h_c = [(i[0], i[1]) for i in h_c_all if int(i[2]) > thre]
        self.vp_pp_db = []
        self.np_pp_db = []
        if pp_file_dir is not None:
            pp_all = read_tsv(os.path.join(pp_file_dir, "all_pp_2.txt"))
        self.vp_pp_db = [i[0] for i in pp_all if int(i[-1]) > thre and i[1] == 'VP']
        self.np_pp_db = [i[0] for i in pp_all if int(i[-1]) > thre and i[1] == 'NP']
        self.this_vp = []
        self.this_np = []

        # for log
        # self.s1_file_name = "same_label_"+tag+"12.txt"
        # self.s1_file_name = "debug.txt"
        self.s2_c2e_file_name = "c2e_base_ant_roberta.txt"
        self.s2_e2c_file_name = "e2c_base_ant_roberta.txt"
        self.s2_e2n_file_name = "e2n_base_ant_roberta.txt"
        # self.s2_c2e_file_name = "debug.txt"
        # self.s2_e2c_file_name = "debug.txt"
        # self.s2_e2n_file_name = "debug.txt"
        # method1 = "natlog12"
        method2 = "natlog12s2"
        # self.dir1 = os.path.join(HUMAN_DIR, method1)
        self.dir2 = os.path.join(HUMAN_DIR, method2)
        # if not os.path.exists(self.dir1):
        #     os.mkdir(self.dir1)
        if not os.path.exists(self.dir2):
            os.mkdir(self.dir2)
        # for continue


    def attack(self, examples, setting=1):
        # if setting == 1:
        #     with open(os.path.join(self.dir1, self.s1_file_name), "w") as f:
        #         f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
        # if setting == 2:
        with open(os.path.join(self.dir2, self.s2_c2e_file_name), "w") as f:
            f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
        with open(os.path.join(self.dir2, self.s2_e2c_file_name), "w") as f:
            f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")
        with open(os.path.join(self.dir2, self.s2_e2n_file_name), "w") as f:
            f.write("idx\tori_p\tori_h\tnew_p\tnew_h\tori_label\tnew_label\tpredit\tquery_num\tmethod\tsuccess\n")


        for (idx, ex) in enumerate(examples):
            # if int(ex['idx']) not in [42, 867, 495, 3685, 2872, 2672, 991, 3310]: # med
            #     continue
            # if int(ex['idx']) not in [657]: #snli
            #     continue

            # if int(ex['idx']) not in [1813, 2442, 4070, 4193, 4745, 4836, 4960, 5605, 5856, 5942, 6946, 7101, 7198, 7835, 7892, 8549, 9402, 9640]: #snli failed
            #     continue
            # if idx < 621:
            #     continue
            # if idx < 813:
            #     continue
            # p = ex['text_a']
            # h = ex['text_b']
            ori_label = ex['label']
            # new_text = [((p, h), ori_label)]

            # if setting == 1:
            #     target_label = ori_label
            #     # # !!!!only for debug
            #     # if self.victim_model_args.id2label_dict[ori_label] != 'entailment':
            #     #     continue
            #
            #     with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
            #         f.write("{}\t".format(idx))
            #     logger.info("------------{}------------".format(idx))
            #     attack_text, n_query, success = self._attack_same_label(ex)
            #     # print("{idx}: success: {success}, n_query: {n_query}, text: {attack_text}".format(
            #     #     idx=idx, success=success, n_query=n_query, attack_text=attack_text))
            #
            # elif setting == 2:
            if self.victim_model_args.id2label_dict[ori_label] == 'neutral':
                continue
            elif self.victim_model_args.id2label_dict[ori_label] == 'contradiction':
                # target_label = self.victim_model_args.label2id_dict['entailment']
                with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
                    f.write("{}\t".format(idx))
                logger.info("------------{}: C2E ------------".format(idx))
                attack_text, n_query, success = self._attack_C2E(ex)


            elif self.victim_model_args.id2label_dict[ori_label] == 'entailment':
                # # target_label = self.victim_model_args.label2id_dict['neutral']
                # with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
                #     f.write("{}\t".format(idx))
                # logger.info("------------{}: E2N ------------".format(idx))
                # attack_text, n_query, success  = self._attack_E2N(ex)


                # target_label = self.victim_model_args.label2id_dict['contradiction']
                with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
                    f.write("{}\t".format(idx))
                logger.info("------------{}: E2C ------------".format(idx))
                attack_text, n_query, success  = self._attack_E2C(ex)

    #
    # def _attack_same_label(self, ex):
    #     attack_text = ''
    #     p_0 = ex['text_a']
    #     h_0 = ex['text_b']
    #     h = ex['text_b']
    #     ori_h = h
    #     ori_label = ex['label']
    #     h_fea = self._process_text(ex['text_b'])
    #     h_token_idx = list(range(len(h_fea['tokens'])))
    #     n_query = 0
    #     idx_change = []
    #     stg = 1
    #     prev_ex = None
    #     prev_h_fea = None
    #     predict = ori_label
    #     success = 0
    #     done = []
    #
    #     self.this_vp = []
    #     self.this_np = []
    #
    #     if self.victim_model_args.id2label_dict[ori_label] != 'entailment':
    #         # add p's pp to the database
    #         p_0_annotation = self.client.annotate(p_0).sentence[0]
    #         p_tokens = [t.word for t in p_0_annotation.token]
    #         p_pp = set(find_node_idx_and_parent(parseTree2str(p_0_annotation.parseTree),  'PP '))
    #         for pp in p_pp:
    #             if pp[1] - pp[0] < len(p_tokens) * 0.7:
    #                 if pp[-1] == 'VP':
    #                     self.this_vp.append(' '.join(p_tokens[pp[0]:pp[1]+1]))
    #                 elif pp[-1] == 'NP':
    #                     self.this_np.append(' '.join(p_tokens[pp[0]:pp[1]+1]))
    #
    #
    #     while (n_query < self.max_queries):
    #         # h_order = self._attack_order(p, h, ori_label, h_fea)
    #         # n_query += len(h_order)
    #         # query_text = []
    #         save_text1 = []
    #         save_method1 = []
    #         save_score1 = []
    #         save_text2 = []
    #         save_method2 = []
    #         save_score2 = []
    #         if self.victim_model_args.id2label_dict[ori_label] == 'entailment':
    #             new_text1 = []
    #             method1 = []
    #             score1 = []
    #
    #             # # one time
    #             # new_text1, method1, score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
    #             #                                            ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #             #                                            pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #             #                                            op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #             #                                            relations=h_fea['natlog_relations'], done=done)
    #             # find h ent_f
    #             new_text2, method2, score2, \
    #             save_text2, save_method2, save_score2 = self._find_ent_f(text=h, tokens=h_fea['tokens'], lemma=h_fea['lemma'],
    #                                                                      ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #                                                                      pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #                                                                      op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #                                                                      relations=h_fea['natlog_relations'], done=done, eq=True)
    #
    #             # two time
    #             if stg > 1:
    #                 # two time process
    #                 # one time
    #                 new_text1, method1, score1, \
    #                 save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
    #                                                                       ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #                                                                       pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #                                                                       op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #                                                                       relations=h_fea['natlog_relations'], done=done, eq=True)
    #
    #             new_text = new_text1 + new_text2
    #             method = method1 + method2
    #             score = score1 + score2
    #
    #             save_text = save_text1 + save_text2
    #             save_mehod = save_method1 + save_method2
    #             save_score = save_score1 + save_score2
    #
    #             lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
    #             new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
    #             method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
    #             score = save_score + [score[sidx] for sidx in lm_scores_idx]
    #
    #         else:
    #
    #             new_text1 = []
    #             method1 = []
    #             score1 = []
    #
    #             # new_text1, method1, score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
    #             #                                            ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #             #                                            pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #             #                                            op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #             #                                            relations=h_fea['natlog_relations'], done=done)
    #
    #             # find h ent_r
    #             new_text2, method2, score2, \
    #             save_text2, save_method2, save_score2 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
    #                                                                      ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #                                                                      pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #                                                                      op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #                                                                      relations=h_fea['natlog_relations'], done=done, eq=True)
    #             # two time
    #             if stg > 1:
    #                 # two time process
    #                 new_text1, method1, score1, \
    #                 save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
    #                                                                       ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
    #                                                                       pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
    #                                                                       op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
    #                                                                       relations=h_fea['natlog_relations'], done=done, eq=True)
    #             new_text = new_text1+new_text2
    #             method = method1+method2
    #             score = score1+score2
    #
    #             save_text = save_text1 + save_text2
    #             save_mehod = save_method1 + save_method2
    #             save_score = save_score1 + save_score2
    #
    #             lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
    #             new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
    #             method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
    #             score = save_score + [score[sidx] for sidx in lm_scores_idx]
    #
    #         # Remove the text same as p_0
    #         remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
    #         if len(remove_idx) > 0:
    #             new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
    #             method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
    #             score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]
    #
    #         # model attack
    #         query_text = [((p_0, i[0].upper()+i[1:]), ori_label)  for i in new_text]
    #         if len(query_text) > 0:
    #             pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
    #                                                                  self.tokenizer, self.victim_model_args)
    #             n_q_batch = -1
    #             for p_idx in range(len(preds)):
    #                 if preds[p_idx] != ori_label:   # Attack sucess
    #                     n_q_batch = p_idx + 1
    #                     attack_text = query_text[p_idx]
    #                     done.append(method[p_idx])
    #                     predict = preds[p_idx]
    #                     success = 1
    #                     break
    #             if n_q_batch != -1:
    #                 # if attack sucess return
    #                 n_query = n_query + n_q_batch
    #                 break
    #             else:
    #                 # else use the lowest one as the base
    #                 n_query += len(preds)
    #                 min_predict_idx = np.argmin(pred_logits[:,ori_label])
    #                 prev_ex = ex
    #                 prev_h_fea = h_fea
    #                 ex['text_b'] = new_text[min_predict_idx]
    #                 h = ex['text_b']
    #                 h_fea = self._process_text(ex['text_b'])
    #                 done.append(method[min_predict_idx])
    #                 h_token_idx = method[min_predict_idx][-1]
    #                 attack_text = query_text[min_predict_idx]
    #                 # ex = lowest_one
    #                 # h_fea = self._process_text(ex['text_b'])
    #                 stg += 1
    #         else:
    #             if stg == 1:
    #                 stg +=1
    #                 continue
    #
    #             logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
    #                         "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
    #                 ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h="", ori_label=ori_label,
    #                 new_label=ori_label, predit=-1, query_num=n_query, method=done, success=0
    #             ))
    #             with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
    #                 f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
    #                         "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
    #                     ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h="", ori_label=ori_label,
    #                     new_label=ori_label, predit=-1, query_num=n_query, method=done, success=0
    #                 ))
    #
    #
    #             return "", n_query, 0
    #
    #
    #     logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
    #                 "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
    #         ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
    #         new_label=ori_label, predit=predict, query_num=n_query, method=done, success=success
    #     ))
    #     with open(os.path.join(self.dir1, self.s1_file_name), "a") as f:
    #         f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
    #                 "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
    #             ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
    #             new_label=ori_label, predit=predict, query_num=n_query, method=done, success=success
    #         ))
    #
    #
    #     return attack_text, n_query, success


    def _find_eq(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                 op, project_matrix, relations, done, eq=False):
        candidate = []
        new_text = []
        method = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # neg prefix + not
        # add not
        do_neg_prefix_eq = True
        for i in done:
            if 'neg_prefix' in i[0]:
                do_neg_prefix_eq = False
                break
        if do_neg_prefix_eq:
            # not_s, not_s_idx, lemma = get_not_sentence(tokens, lemma, pos)
            # candidate.extend([(i+' ' + get_subsentence(not_s, lemma), ('neg_prefix_eq', [-1]*len(simple_tokenize(i)) + not_s_idx))
            #                   for i in self.neg_prefix])
            for (not_s, not_s_idx, lemma) in get_not_sentence(tokens, lemma, pos):
                candidate.extend([(i+' ' + get_subsentence(not_s, lemma), ('neg_prefix_eq', [-1]*len(simple_tokenize(i)) + not_s_idx))
                                  for i in self.neg_prefix])

        # # bert find eq
        # for t in range(len(tokens)):
        #     if pos[t] in ['NN', 'JJ', 'RB', 'VB']:
        #         bert_input = token2sentence(tokens[:t] + ['[MASK]'] +tokens[t+1:])
        #         ins_token = self._lm_predict(bert_input)
        #
        #         # word_range = [self._lm_sentence_sim(tokens[t], i) for i in ins_token ]
        #         # bert_token = ins_token
        #         ins_token = [i for i in ins_token if i!=tokens[t] and self._lm_sentence_sim(tokens[t], i) > self.EQ_THRE]
        #         bert_text = [token2sentence(tokens[:t] + [ins_t] +tokens[t+1:]) for ins_t in ins_token]
        #         # candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t+1:]))
        #         #                   for s in bert_text
        #         #                   if self.client.annotate(s).sentence[0].token[t].pos[0:2] == pos[t] and self._lm_sim(text, s)>self.EQ_THRE])
        #         candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t+1:]))
        #                             for s in bert_text
        #                             if self.client.annotate(s).sentence[0].token[t].pos[0:2] == pos[t]])

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.BERT_EQ]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.BERT_EQ])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_ent_f(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                    op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        scores = []
        candidate = []
        candidate_pp = []
        candidate_save_pp = []
        saved_text = []
        saved_method = []
        saved_scores = []

        if self.method_pp:
            # 1. structure pp
            # structure if up then delete pp
            # structure if down then add pp
            # (1, [0,1,2,...,-1])
            do_pp = True
            for i in done:
                if i[0] == 'pp':
                    do_pp = False
            if do_pp:
                n_idx_list = get_n(pos) + get_prp(pos)
                # n_idx_list = get_n(pos)
                pp = set(find_node_idx_and_parent(parseTree, 'PP '))
                # structure if up then delete pp
                for t in pp:
                    if polarity_dirs[t[0]] == self.map_project_dir['up']:
                        if len(lemma) < 2:
                            continue
                        if lemma[t[0]-1] == 'be' or (lemma[t[0]-2] == 'be' and pos[t[0]-1] == 'JJ'):
                            continue
                        if t[0] == 0:
                            this_t = token2sentence(tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                        else:
                            this_t = token2sentence(tokens[:t[0]] + tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[:t[0]] + ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                # structure if down then add pp
                # down monotone, for n/v without pp only
                # candidate_method = []
                for idx in range(len(tokens)):
                    if (polarity_dirs[idx] == self.map_project_dir['down']) and (idx in n_idx_list):  # v简化为句子结尾
                        # (idx in n_idx_list + v_idx_list):

                        if (idx < len(tokens)-1) and pos[idx+1] == 'IN':
                            continue

                        #add pp   np后加pp, vp后加pp，简化为n后加pp，句子结尾加pp
                        # if pos[idx][0:2] == 'NN':
                        if idx in n_idx_list:
                            pre_c = token2sentence(tokens[:idx+1])
                            pre_idx = ori_token_idx[:idx+1]
                            if (idx < len(tokens)-1):
                                after_c = token2sentence(tokens[idx+1:])
                                after_idx = ori_token_idx[idx+1:]
                            else:
                                after_c = ''
                                after_idx=[]
                            for pp in self.this_np:
                                if pp in text:
                                    continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m =("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_save_pp:
                                    candidate_save_pp.append((content, content_m))

                            for pp in self.np_pp_db:
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m = ("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_pp:
                                    candidate_pp.append((content, content_m))
                                    # candidate_method.append()
                        # # 应该为vp后加pp，简化为句子结尾加pp
                        # if pos[idx][0:2] == 'VB':
                        #     insert_idx = idx
                        #     # vt + n
                        #     if (idx < len(tokens)-1):
                        #         for insert_tmp in range(idx+1,len(tokens)):
                        #             if pos[insert_tmp][0:2] in ('NN', 'DT', 'CD'):
                        #                 insert_idx = insert_tmp
                        #             else:
                        #                 break
                        #         after_c = token2sentence(tokens[insert_idx+1:])
                        #         after_idx = ori_token_idx[insert_idx+1:]
                        #     else:
                        #         insert_idx = len(tokens)-1
                        #         after_c = ''
                        #         after_idx=[]
                        #
                        #     pre_c = token2sentence(tokens[:insert_idx+1])
                        #     pre_idx = ori_token_idx[:insert_idx+1]
                        #     for pp in self.vp_pp_db:
                        #         n = len(pp.split())
                        #         candidate.append((pre_c + ' ' + pp + ' ' + after_c).strip())
                        #         candidate_method.append(("pp", pre_idx + [-1]*n + after_idx))

                # vp pp
                if polarity_dirs[-1] == self.map_project_dir['down']:
                    for pp in self.this_vp:
                        if pp in text:
                            continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_save_pp:
                            candidate_save_pp.append((content, content_m))

                    for pp in self.vp_pp_db:
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_pp:
                            candidate_pp.append((content, content_m))
                            # candidate_method.append()

                # Use bert to choose first .
                lm_scores = [self._lm_score(cand[0]) for cand in candidate_pp]

                lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.PP_NUM]


                new_text.extend([candidate_pp[sidx][0] for sidx in lm_scores_idx])
                method.extend([candidate_pp[sidx][1] for sidx in lm_scores_idx])
                scores.extend(sorted(lm_scores)[0:self.PP_NUM])

                lm_save_scores = [self._lm_score(cand[0]) for cand in candidate_save_pp]
                save_num = len(lm_save_scores)//2
                lm_save_scores_idx = sorted(range(len(lm_save_scores)), key=lambda k: lm_save_scores[k], reverse=False)[0:save_num]
                saved_text.extend([candidate_save_pp[sidx][0] for sidx in lm_save_scores_idx])
                saved_method.extend([candidate_save_pp[sidx][1] for sidx in lm_save_scores_idx])
                saved_scores.extend(sorted(lm_save_scores)[0:save_num])


        if self.method_insert_delete:
            # 2. insert/delete
            # bert_insert if n/v down
            # delete NN/Adj/adv if up
            # (2, v) (2, n)
            adj_list = get_adj(pos)
            adv_list = get_adv(pos)
            for t in adj_list+adv_list:
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if tokens[t] in self.adv_ex or len(lemma) < 2:
                    continue
                # delete NN/Adj/adv if up
                if polarity_dirs[t] == self.map_project_dir['up']:
                    if len(lemma) < 2:
                        continue
                    if t > 0 and lemma[t-1] == 'be':
                        continue
                    content = token2sentence(tokens[:t] + tokens[t + 1:])
                    saved_text.append(content)
                    saved_method.append(("ins_del", ori_token_idx[:t] + ori_token_idx[t + 1:]))
                    saved_scores.append(self._lm_score(content))

            n_list = get_n(pos)
            v_list = get_v(pos)

            for t in n_list:
                # bert_insert if n/v down
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['down']:
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i)]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] + self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'JJ'])

            for t in v_list:
                # bert_insert if n/v down
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['down']:
                    # before
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] +self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] +tokens[t:]) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'RB'])
                    # after
                    bert_input = token2sentence(tokens[:t+1] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t+1] + [ins_t] +tokens[t+1:]) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t+1].pos[0:2] == 'RB'])

            # # bert score candidates
            # lm_scores = [self._lm_score(cand[0]) for cand in candidate]
            # lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.INS_DEL]
            #
            # new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
            # method.extend([candidate[sidx][1] for sidx in lm_scores_idx])

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            # a man/woman/lady/person/ -> someone somebody
            #

            for i in range(len(tokens)):
                if relations[i] is not None and 1 in project_matrix[i]:
                    if project_matrix[i].index(1) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(1) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(1) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(1) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(1) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_f", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(1) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores

    def _find_ent_r(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                    op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        scores = []
        candidate = []
        candidate_pp = []
        candidate_save_pp = []
        saved_text = []
        saved_method = []
        saved_scores = []


        if self.method_pp:
            # 1. structure pp
            # structure if down then delete pp
            # structure if up then add pp
            # (1, [0,1,2,...,-1])
            do_pp = True
            for i in done:
                if i[0] == 'pp':
                    do_pp = False
                    break
            if do_pp:
                n_idx_list = get_n(pos) + get_prp(pos)
                # n_idx_list = get_n(pos)
                pp = set(find_node_idx_and_parent(parseTree, 'PP '))
                # structure if down then delete pp
                for t in pp:
                    if len(lemma) < 2:
                        continue
                    if polarity_dirs[t[0]] == self.map_project_dir['down']:
                        if lemma[t[0]-1] == 'be' or (lemma[t[0]-2] == 'be' and pos[t[0]-1] == 'JJ'):
                            continue
                        if t[0] == 0:
                            this_t = token2sentence(tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))
                        else:
                            this_t = token2sentence(tokens[:t[0]] + tokens[t[1] + 1:])
                            if len(this_t) > 0:
                                saved_text.append(this_t)
                                saved_method.append(("pp", ori_token_idx[:t[0]] + ori_token_idx[t[1] + 1:]))
                                saved_scores.append(self._lm_score(this_t))

                # structure if up then add pp
                # down monotone, for n/v without pp only
                # candidate_method = []
                for idx in n_idx_list:
                    if (polarity_dirs[idx] == self.map_project_dir['up']):  # v简化为句子结尾
                        # (idx in n_idx_list + v_idx_list):

                        if (idx < len(tokens)-1) and pos[idx+1] == 'IN':
                            continue

                        #add pp   np后加pp, vp后加pp，简化为n后加pp，句子结尾加pp
                        if idx in n_idx_list:
                            # if pos[idx][0:2] in == 'NN':
                            pre_c = token2sentence(tokens[:idx+1])
                            pre_idx = ori_token_idx[:idx+1]
                            if (idx < len(tokens)-1):
                                after_c = token2sentence(tokens[idx+1:])
                                after_idx = ori_token_idx[idx+1:]
                            else:
                                after_c = ''
                                after_idx=[]

                            for pp in self.this_np:
                                if pp in text:
                                    continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m =("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_save_pp:
                                    candidate_save_pp.append((content, content_m))

                            for pp in self.np_pp_db:
                                # if pp in text:
                                #     continue
                                n = len(simple_tokenize(pp))
                                content = (pre_c + ' ' + pp + ' ' + after_c).strip()
                                content_m = ("pp", pre_idx + [-1]*n + after_idx)
                                if (content, content_m) not in candidate_pp:
                                    candidate_pp.append((content, content_m))
                                    # candidate_method.append()
                        # # 应该为vp后加pp，简化为句子结尾加pp
                        # if pos[idx][0:2] == 'VB':
                        #     insert_idx = idx
                        #     # vt + n
                        #     if (idx < len(tokens)-1):
                        #         for insert_tmp in range(idx+1,len(tokens)):
                        #             if pos[insert_tmp][0:2] in ('NN', 'DT', 'CD'):
                        #                 insert_idx = insert_tmp
                        #             else:
                        #                 break
                        #         after_c = token2sentence(tokens[insert_idx+1:])
                        #         after_idx = ori_token_idx[insert_idx+1:]
                        #     else:
                        #         insert_idx = len(tokens)-1
                        #         after_c = ''
                        #         after_idx=[]
                        #
                        #     pre_c = token2sentence(tokens[:insert_idx+1])
                        #     pre_idx = ori_token_idx[:insert_idx+1]
                        #     for pp in self.vp_pp_db:
                        #         n = len(pp.split())
                        #         candidate.append((pre_c + ' ' + pp + ' ' + after_c).strip())
                        #         candidate_method.append(("pp", pre_idx + [-1]*n + after_idx))

                # vp pp
                if polarity_dirs[-1] == self.map_project_dir['up']:

                    for pp in self.this_vp:
                        if pp in text:
                            continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_save_pp:
                            candidate_save_pp.append((content, content_m))

                    for pp in self.vp_pp_db:
                        # if pp in text:
                        #     continue
                        n = len(simple_tokenize(pp))
                        content = token2sentence(tokens) + ' ' + pp
                        content_m = ("pp", ori_token_idx + [-1]*n)
                        if (content, content_m) not in candidate_pp:
                            candidate_pp.append((content, content_m))
                            # candidate_method.append()

                # Use bert to choose first 20.
                lm_scores = [self._lm_score(cand[0]) for cand in candidate_pp]
                lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.PP_NUM]
                new_text.extend([candidate_pp[sidx][0] for sidx in lm_scores_idx])
                method.extend([candidate_pp[sidx][1] for sidx in lm_scores_idx])
                scores.extend(sorted(lm_scores)[0:self.PP_NUM])

                lm_save_scores = [self._lm_score(cand[0]) for cand in candidate_save_pp]
                save_num = len(lm_save_scores)//2
                lm_save_scores_idx = sorted(range(len(lm_save_scores)), key=lambda k: lm_save_scores[k], reverse=False)[0:save_num]
                saved_text.extend([candidate_save_pp[sidx][0] for sidx in lm_save_scores_idx])
                saved_method.extend([candidate_save_pp[sidx][1] for sidx in lm_save_scores_idx])
                saved_scores.extend(sorted(lm_save_scores)[0:save_num])



        if self.method_insert_delete:
            # 2. insert/delete
            # bert_insert if n/v up
            # delete NN/Adj/adv if down
            # (2, v) (2, n)
            adj_list = get_adj(pos)
            adv_list = get_adv(pos)
            for t in adj_list+adv_list:
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if tokens[t] in self.adv_ex:
                    continue
                # delete NN/Adj/adv if down
                if polarity_dirs[t] == self.map_project_dir['down']:
                    if len(lemma) < 2:
                        continue
                    if t > 0 and lemma[t-1] == 'be':
                        continue
                    content = token2sentence(tokens[:t] + tokens[t + 1:])
                    saved_text.append(content)
                    saved_method.append(("ins_del", ori_token_idx[:t] + ori_token_idx[t + 1:]))
                    saved_scores.append(self._lm_score(content))

            n_list = get_n(pos)
            v_list = get_v(pos)

            for t in n_list:
                # bert_insert if n/v up
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['up']:
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) ]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] + self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'JJ'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                    #                   for s in bert_text
                    #                   ])

            for t in v_list:
                # bert_insert if n/v up
                # if ori_token_idx[t] == -1:  # not original word
                #     continue
                if polarity_dirs[t] == self.map_project_dir['up']:
                    # if the v is be then skip
                    if lemma[t] == 'be':
                        continue

                    # before
                    bert_input = token2sentence(tokens[:t] + ['[MASK]'] + self._first_lower(tokens[t:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t] + [ins_t] +self._first_lower(tokens[t:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t].pos[0:2] == 'RB'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
                    #                   for s in bert_text
                    #                   ])
                    # after
                    bert_input = token2sentence(tokens[:t+1] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
                    ins_token = [i for i in self._lm_predict(bert_input) if self._is_word(i) and i not in self.adv_ex]
                    bert_text = [token2sentence(tokens[:t+1] + [ins_t] +self._first_lower(tokens[t+1:])) for ins_t in ins_token]
                    candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                                      for s in bert_text
                                      if self.client.annotate(s).sentence[0].token[t+1].pos[0:2] == 'RB'])
                    # candidate.extend([(s, ('ins_del', ori_token_idx[:t+1] + [-1] + ori_token_idx[t+1:]))
                    #                   for s in bert_text
                    #                   ])

            # # bert score candidates
            # lm_scores = [self._lm_score(cand[0]) for cand in candidate]
            # lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.INS_DEL]
            #
            # new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
            # method.extend([candidate[sidx][1] for sidx in lm_scores_idx])

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if relations[i] is not None and 2 in project_matrix[i]:
                    if project_matrix[i].index(2) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] +
                                                [-1]*len(simple_tokenize(j)) +
                                                ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(2) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(2) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(2) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(2) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_ent_r", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(2) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_neg(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                  op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # add neg prefix
        do_neg_prefix_neg = True
        for i in done:
            if 'neg_prefix' in i[0]:
                do_neg_prefix_neg = False
                break
        if do_neg_prefix_neg:
            candidate.extend([(i+' ' + get_subsentence(text, lemma), ('neg_prefix_neg', [-1]*len(simple_tokenize(i)) + ori_token_idx))
                              for i in self.neg_prefix])

        do_not_neg= True
        for i in done:
            if 'not_neg' in i[0]:
                do_not_neg = False
                break
        if do_not_neg:
            # not_s, not_s_idx, lemma = get_not_sentence(tokens, lemma, pos)
            # candidate.extend([(not_s, ('not_neg', not_s_idx))])
            for (not_s, not_s_idx, lemma) in get_simple_not_sentence(tokens, lemma, pos):
                candidate.extend([(not_s, ('not_neg', not_s_idx))])


        # if self.method_natlog:
        #     # 3. wordnet
        #     # (3, wordidx)
        #     # return text and method
        #     for i in range(len(tokens)):
        #         if relations[i] is not None and 3 in project_matrix[i]:
        #             if project_matrix[i].index(3) == 0: # eq
        #                 if relations[i]['eq'] is not None:
        #                     # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
        #                     #                  for j in relations[i]['eq']])
        #                     # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
        #                     #           * (len(relations[i]['eq'])))
        #                     candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
        #                                        ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
        #                                       for j in relations[i]['eq']])
        #             if project_matrix[i].index(3) == 1: # ent_f
        #                 if relations[i]['ent_f'] is not None:
        #                     tmp = relations[i]['ent_f']
        #                     if eq and relations[i]['eq'] is not None:
        #                         tmp += relations[i]['eq']
        #                     # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
        #                     #                  for j in tmp])
        #                     # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
        #                     #                * len(tmp))
        #                     candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
        #                                        ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
        #                                       for j in tmp])
        #             if project_matrix[i].index(3) == 2: # ent_r
        #                 if relations[i]['ent_r'] is not None:
        #                     tmp = relations[i]['ent_r']
        #                     if eq and relations[i]['eq'] is not None:
        #                         tmp += relations[i]['eq']
        #                     # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
        #                     #                  for j in tmp])
        #                     # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
        #                     #               * len(tmp))
        #                     candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
        #                                        ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
        #                                       for j in tmp])
        #             if project_matrix[i].index(3) == 3: # neg
        #                 if relations[i]['neg'] is not None:
        #                     # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
        #                     #                  for j in relations[i]['neg']])
        #                     # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
        #                     #               * (len(relations[i]['neg']) ))
        #                     candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
        #                                        ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
        #                                       for j in relations[i]['neg']])
        #             if project_matrix[i].index(3) == 4: # alt
        #                 if relations[i]['alt'] is not None:
        #                     # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
        #                     #                  for j in relations[i]['alt']])
        #                     # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
        #                     #               * (len(relations[i]['alt']) ))
        #                     candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
        #                                        ("wn_neg", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
        #                                       for j in relations[i]['alt']])
        #             if project_matrix[i].index(3) in [5,6]: # cov, ind
        #                 pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_alt(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                  op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        # # bert find alt
        # for t in range(len(tokens)):
        #     if ori_token_idx[t] == -1: # if you do alt twice on the same word, you can't predict the result
        #         continue
        #     if pos[t] in ['NN', 'JJ', 'RB', 'VB']:
        #         bert_input = token2sentence(tokens[:t] + ['[MASK]'] +self._first_lower(tokens[t+1:]))
        #         ins_token = self._lm_predict(bert_input)
        #
        #         # word_range = [self._lm_sentence_sim(tokens[t], i) for i in ins_token ]
        #         # bert_token = ins_token
        #         ins_token = [i for i in ins_token if self._is_word(i) and i!=tokens[t] and self._lm_word_sim(tokens[t], i) < self.ALT_THRE]
        #         bert_text = [token2sentence(tokens[:t] + [ins_t] +self._first_lower(tokens[t+1:])) for ins_t in ins_token]
        #         # candidate.extend([(s, ('bert_eq', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
        #         #                   for s in bert_text
        #         #                   if self.client.annotate(bert_text[0]).sentence[0].token[t].pos[0:2] == pos[t] and self._lm_sim(text, s)>self.EQ_THRE])
        #         candidate.extend([(s, ('bert_alt', ori_token_idx[:t] + [-1] + ori_token_idx[t:]))
        #                           for s in bert_text
        #                           if self.client.annotate(bert_text[0]).sentence[0].token[t].pos[0:2] == pos[t]])



        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if ori_token_idx[i] == -1: # if you do alt twice on the same word, you can't predict the result
                    continue
                if relations[i] is not None and 4 in project_matrix[i]:
                    if project_matrix[i].index(4) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(4) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(4) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(4) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(4) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_alt", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(4) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _find_cov(self, text, tokens, lemma, ori_token_idx, parseTree, pos, polarity_dirs,
                  op, project_matrix, relations, done, eq=False):
        new_text = []
        method = []
        candidate = []
        scores = []
        saved_text = []
        saved_method = []
        saved_scores = []

        if self.method_natlog:
            # 3. wordnet
            # (3, wordidx)
            # return text and method
            for i in range(len(tokens)):
                if ori_token_idx[i] == -1: # if you do cov twice on the same word, you can't predict the result
                    continue
                if relations[i] is not None and 5 in project_matrix[i]:
                    if project_matrix[i].index(5) == 0: # eq
                        if relations[i]['eq'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['eq']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #           * (len(relations[i]['eq'])))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['eq']])
                    if project_matrix[i].index(5) == 1: # ent_f
                        if relations[i]['ent_f'] is not None:
                            tmp = relations[i]['ent_f']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #                * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(5) == 2: # ent_r
                        if relations[i]['ent_r'] is not None:
                            tmp = relations[i]['ent_r']
                            if eq and relations[i]['eq'] is not None:
                                tmp += relations[i]['eq']
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in tmp])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * len(tmp))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in tmp])
                    if project_matrix[i].index(5) == 3: # neg
                        if relations[i]['neg'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['neg']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['neg']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['neg']])
                    if project_matrix[i].index(5) == 4: # alt
                        if relations[i]['alt'] is not None:
                            # new_text.extend([token2sentence(tokens[:i]+[j]+tokens[i+1:])
                            #                  for j in relations[i]['alt']])
                            # method.extend([("wn", ori_token_idx[:i] + [-1] + ori_token_idx[i+1:])]
                            #               * (len(relations[i]['alt']) ))
                            candidate.extend([(token2sentence(tokens[:i]+[j]+tokens[i+1:]),
                                               ("wn_cov", ori_token_idx[:i] + [-1]*len(simple_tokenize(j)) + ori_token_idx[i+1:]))
                                              for j in relations[i]['alt']])
                    if project_matrix[i].index(5) in [5,6]: # cov, ind
                        pass

        # bert score candidates
        lm_scores = [self._lm_score(cand[0]) for cand in candidate]
        lm_scores_idx = sorted(range(len(lm_scores)), key=lambda k: lm_scores[k], reverse=False)[0:self.NUM_PER_STEP]

        new_text.extend([candidate[sidx][0] for sidx in lm_scores_idx])
        method.extend([candidate[sidx][1] for sidx in lm_scores_idx])
        scores.extend(sorted(lm_scores)[0:self.NUM_PER_STEP])
        return new_text, method, scores, saved_text, saved_method, saved_scores


    def _attack_E2C(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['contradiction']


        while (n_query < self.max_queries):
            save_text = []
            save_method = []
            save_score = []
            save_text2 = []
            save_method2 = []
            save_score2 = []

            # one time
            if n_query == 0: # only do the first time
                new_text, method, score, \
                save_text, save_method, save_score = self._find_neg(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                                    ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                                    pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                                    op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                                    relations=h_fea['natlog_relations'], done=done)

            new_text2, method2, score2, \
            save_text2, save_method2, save_score2 = self._find_alt(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                                   ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                                   pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                                   op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                                   relations=h_fea['natlog_relations'], done=done)

            # two time
            if stg > 1:
                # two time process
                pass

            # new_text = new_text1+new_text2
            # method = method1+method2
            # score = score1+score2
            save_text = save_text + save_text2
            save_mehod = save_method + save_method2
            save_score = save_score + save_score2

            lm_scores_idx = sorted(range(len(score2)), key=lambda k: score2[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
            new_text = save_text + new_text+ [new_text2[sidx] for sidx in lm_scores_idx]
            method = save_mehod + method + [method2[sidx] for sidx in lm_scores_idx]
            score = save_score + score + [score2[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)

                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != target_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1
            else:
                if stg == 1:
                    stg +=1
                    continue
                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                        new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                    ))

                return "", n_query, 0

        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_e2c_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))

        return attack_text, n_query, success


    def _attack_E2N(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['neutral']

        while (n_query < self.max_queries):
            save_text1 = []
            save_method1 = []
            save_score1 = []
            save_text2 = []
            save_method2 = []
            save_score2 = []

            # one time
            new_text1, method1, score1, \
            save_text1, save_method1, save_score1 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                                     ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                                     pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                                     op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                                     relations=h_fea['natlog_relations'], done=done, eq=False)



            new_text2, method2, score2, \
            save_text2, save_method2, save_score2 = self._find_cov(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
                                                                   ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
                                                                   pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
                                                                   op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
                                                                   relations=h_fea['natlog_relations'], done=done)

            # two time
            if stg > 1:
                # two time process
                pass

            new_text = new_text1+new_text2
            method = method1+method2
            score = score1+score2

            save_text = save_text1 + save_text2
            save_mehod = save_method1 + save_method2
            save_score = save_score1 + save_score2

            lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
            new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
            method = save_mehod + [method[sidx] for sidx in lm_scores_idx]
            score = save_score + [score[sidx] for sidx in lm_scores_idx]

            # Remove the text same as p_0
            remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
            if len(remove_idx) > 0:
                new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
                method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
                score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

            # model attack
            query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
            if len(query_text) > 0:
                pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                     self.tokenizer, self.victim_model_args)
                n_q_batch = -1
                for p_idx in range(len(preds)):
                    if preds[p_idx] != target_label:   # Attack sucess
                        n_q_batch = p_idx + 1
                        attack_text = query_text[p_idx]
                        done.append(method[p_idx])
                        predict = preds[p_idx]
                        success = 1
                        break
                if n_q_batch != -1:
                    # if attack sucess return
                    n_query = n_query + n_q_batch
                    break
                else:
                    # else use the lowest one as the base
                    n_query += len(preds)
                    min_predict_idx = np.argmin(pred_logits[:,ori_label])
                    prev_ex = ex
                    prev_h_fea = h_fea
                    ex['text_b'] = new_text[min_predict_idx]
                    h = ex['text_b']
                    h_fea = self._process_text(ex['text_b'])
                    done.append(method[min_predict_idx])
                    h_token_idx = method[min_predict_idx][-1]
                    attack_text = query_text[min_predict_idx]
                    # ex = lowest_one
                    # h_fea = self._process_text(ex['text_b'])
                    stg += 1

            else:
                if stg == 1:
                    stg +=1
                    continue
                logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))
                with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
                    f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                            "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                        ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                        new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                    ))
                return "", n_query, 0

        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_e2n_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))

        return attack_text, n_query, success

    def _attack_C2E(self, ex):
        attack_text = ''
        p_0 = ex['text_a']
        h_0 = ex['text_b']
        h = ex['text_b']
        ori_h = h
        ori_label = ex['label']
        h_fea = self._process_text(ex['text_b'])
        h_token_idx = list(range(len(h_fea['tokens'])))
        n_query = 0
        idx_change = []
        stg = 1
        prev_ex = None
        prev_h_fea = None
        predict = ori_label
        success = 0
        done = []
        target_label = self.victim_model_args.label2id_dict['entailment']

        # while (n_query < self.max_queries):
        save_text = []
        save_method = []
        save_score = []
        new_text = []
        method = []

        if n_query == 0:
            new_text = [i+' ' + get_subsentence(h, h_fea["lemma"]) for i in self.neg_prefix]
            method = [("neg_prefix", [-1]*len(simple_tokenize(i))+h_token_idx)
                      for i in self.neg_prefix]
        # else:
        #     # one time
        #     new_text1, method1, score1, \
        #     save_text1, save_method1, save_score1 = self._find_eq(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
        #                                                           ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
        #                                                           pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
        #                                                           op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
        #                                                           relations=h_fea['natlog_relations'], done=done)
        #
        #     new_text2, method2, score2, \
        #     save_text2, save_method2, save_score2 = self._find_ent_r(text=h, tokens=h_fea['tokens'],lemma=h_fea['lemma'],
        #                                                              ori_token_idx=h_token_idx, parseTree=h_fea['parseTree'],
        #                                                              pos=h_fea['pos'], polarity_dirs=h_fea['polarity_dirs'],
        #                                                              op=h_fea['operators'], project_matrix=h_fea['project_matrix'],
        #                                                              relations=h_fea['natlog_relations'], done=done)

            # two time
            # if stg > 1:
            #     # two time process
            #     pass

            # new_text = new_text1+new_text2
            # method = method1+method2
            # score = score1+score2

            # save_text = save_text1 + save_text2
            # save_mehod = save_method1 + save_method2
            # save_score = save_score1 + save_score2

        #     lm_scores_idx = sorted(range(len(score)), key=lambda k: score[k], reverse=False)[0:self.NUM_PER_STEP-len(save_score)]
        #     new_text = save_text + [new_text[sidx] for sidx in lm_scores_idx]
        #     method = save_method + [method[sidx] for sidx in lm_scores_idx]
        #     score = save_score + [score[sidx] for sidx in lm_scores_idx]
        #
        # # Remove the text same as p_0
        # remove_idx = [idx for idx in range(len(new_text)) if p_0 == new_text[idx]]
        # if len(remove_idx) > 0:
        #     new_text = [new_text[idx] for idx in range(len(new_text)) if idx not in remove_idx]
        #     method = [method[idx] for idx in range(len(method)) if idx not in remove_idx]
        #     score = [score[idx] for idx in range(len(score)) if idx not in remove_idx]

        # model attack
        query_text = [((p_0, i[0].upper()+i[1:]), target_label) for i in new_text]
        if len(query_text) > 0:
            pred_logits, preds, _ = self.victim_model_predict_fn(query_text, self.victim_model,
                                                                 self.tokenizer, self.victim_model_args)

            n_q_batch = -1
            for p_idx in range(len(preds)):
                if preds[p_idx] != target_label:   # Attack sucess
                    n_q_batch = p_idx + 1
                    attack_text = query_text[p_idx]
                    done.append(method[p_idx])
                    predict = preds[p_idx]
                    success = 1
                    break
            if n_q_batch != -1:
                # if attack sucess return
                n_query = n_query + n_q_batch
                # break
            else:
                # else use the lowest one as the base
                n_query += len(preds)
                min_predict_idx = np.argmin(pred_logits[:,ori_label])
                prev_ex = ex
                prev_h_fea = h_fea
                ex['text_b'] = new_text[min_predict_idx]
                h = ex['text_b']
                h_fea = self._process_text(ex['text_b'])
                done.append(method[min_predict_idx])
                h_token_idx = method[min_predict_idx][-1]
                attack_text = query_text[min_predict_idx]
                # ex = lowest_one
                # h_fea = self._process_text(ex['text_b'])
                stg += 1
        else:
            # if stg == 1:
            #     stg +=1
            #     continue
            logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                        "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
            ))
            with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
                f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                        "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                    ori_p=p_0, ori_h=h_0, new_p=p_0, new_h="", ori_label=ori_label,
                    new_label=target_label, predit=-1, query_num=n_query, method=done, success=0
                ))


            return "", n_query, 0


        logger.info("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
            ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
            new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
        ))
        with open(os.path.join(self.dir2, self.s2_c2e_file_name), "a") as f:
            f.write("{ori_p}\t{ori_h}\t{new_p}\t{new_h}\t{ori_label}\t{new_label}"
                    "\t{predit}\t{query_num}\t{method}\t{success}\n".format(
                ori_p=p_0, ori_h=h_0, new_p=attack_text[0][0], new_h=attack_text[0][1], ori_label=ori_label,
                new_label=target_label, predit=predict, query_num=n_query, method=done, success=success
            ))


        return attack_text, n_query, success


    def _attack_order(self, p, h, ori_label, h_fea):
        # p = ex['text']
        # # h = ex['text_b']
        # ori_label = ex['label']
        mask = '[MASK]'
        h_list = h_fea['tokens'].copy()

        # # # test
        # # ex['h_tokens'][5] = mask
        # ######## multitimes order
        # change_idx = []
        #
        #
        # for j in range(len(h_list)):
        #     new_text = list()
        #     for i in range(len(h_list)):
        #         newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
        #         new_text.append(((p, newh), 0))
        #     _, pred_probs, _, _ = self.victim_model_predict_fn(new_text,
        #                                                                                 self.victim_model,
        #                                                                                 self.tokenizer,
        #                                                                                 self.victim_model_args)
        #
        #     probs = pred_probs[:, ori_label]
        #     probs_idx = sorted(range(len(probs)), key=lambda k: probs[k], reverse=False)
        #     probs_idx = [k for k in probs_idx if k not in change_idx]
        #     change_idx.append(probs_idx[0])
        #     h_list[probs_idx[0]] = mask
        #     change_idx.append(probs_idx[0])
        # return change_idx

        ######## onetime order
        new_text = list()
        for i in range(len(h_list)):
            newh = (' '.join(h_list[:i]) + ' ' + mask + ' ' + ' '.join(h_list[i+1:])).strip()
            new_text.append(((p, newh), 0))
        pred_logits, _, _ = self.victim_model_predict_fn(new_text,
                                                         self.victim_model,
                                                         self.tokenizer,
                                                         self.victim_model_args)

        logits = pred_logits[:, ori_label]
        logits_idx = sorted(range(len(logits)), key=lambda k: logits[k], reverse=False)

        return logits_idx

    def _trans_word_list(self, lemma_list, pos):
        new_list = []
        for w in lemma_list:
            new_w = getInflection(w, pos)
            if len(new_w) > 0:
                new_list.append(new_w[0])
            else:
                new_list.append(w)
        return new_list

    def _find_wordnet_relations(self, example):
        relations = []
        for(i, (postag, token, lemma, polarity, project_matrix, op)) in enumerate(zip(example['pos'],
                                                                                      example['tokens'],
                                                                                      example['lemma'],
                                                                                      example['polarity_dirs'],
                                                                                      example['project_matrix'],
                                                                                      example['operators'])):

            neg = self.wordnet.get_neg(lemma)
            relations.append({'eq':  [],
                              'ent_f':  [],
                              'ent_r':  [],
                              'neg':  [],  #should be fine
                              'alt':   self._trans_word_list(neg, postag)})
                              # 'alt':   []})

        return  relations


    def _analyze_example_with_corenlp(self, text):
        feature = dict()
        feature['parseTree'] = None
        feature['basicDependencies'] = None
        feature["tokens"] = []
        feature["lemma"] = []
        feature["pos"] = []
        # feature["h_polarities"] = []
        feature["polarity_dirs"] = []
        feature["operators"] = []
        feature["project_matrix"] = []
        for s in self.client.annotate(text).sentence:  # acutually only return the first sent
            feature['parseTree'] = parseTree2str(s.parseTree)
            feature["tokens"].extend([t.word for t in s.token])
            feature["lemma"].extend([t.lemma for t in s.token])
            feature["pos"].extend([t.pos for t in s.token])
            feature["polarity_dirs"].extend([self.map_project_dir[t.polarity_dir] for t in s.token])
            feature["basicDependencies"] = s.basicDependencies

            for t in s.token:
                op = dict()
                polarity = dict()
                project_matrix = list()
                op["name"] = t.operator.name
                op["quant_span_s"] = t.operator.quantifierSpanBegin
                op["quant_span_e"] = t.operator.quantifierSpanEnd
                op["sub_span_s"] = t.operator.subjectSpanBegin
                op["sub_span_e"] = t.operator.subjectSpanEnd
                op["obj_span_s"] = t.operator.objectSpanBegin
                op["obj_span_e"] = t.operator.objectSpanEnd

                polarity["project_eq"] = t.polarity.projectEquivalence
                polarity["project_ent_f"] = t.polarity.projectForwardEntailment
                polarity["project_ent_r"] = t.polarity.projectReverseEntailment
                polarity["project_neg"] = t.polarity.projectNegation
                polarity["project_alt"] = t.polarity.projectAlternation
                polarity["project_cov"] = t.polarity.projectCover
                polarity["project_ind"] = t.polarity.projectIndependence

                if op["name"] == '':
                    op = {}
                # else:
                #     op["quant_span_s"] += feature["h_length"]
                #     op["quant_span_e"] += feature["h_length"]
                #     op["sub_span_s"] += feature["h_length"]
                #     op["sub_span_e"] += feature["h_length"]
                #     op["obj_span_s"] += feature["h_length"]
                #     op["obj_span_e"] += feature["h_length"]

                for key in ["project_eq", "project_ent_f", "project_ent_r",
                            "project_neg", "project_alt", "project_cov", "project_ind"]:
                    project_matrix.append(polarity[key])

                feature["operators"].append(op)
                # feature['h_polarities'].append(polarity)
                feature["project_matrix"].append(project_matrix)

            # feature = self._correct_natlog_corenlp(s, feature)

            return feature

    def _correct_natlog_corenlp(self, ex):

        # no longer, never, hardly
        never_idx_list = has_sublist_idx(ex['tokens'], ['never'])
        hardly_idx_list = has_sublist_idx(ex['tokens'], ['hardly'])
        scarcely_idx_list = has_sublist_idx(ex['tokens'], ['scarcely'])
        one_token_idx_list = never_idx_list+hardly_idx_list+scarcely_idx_list
        no_longer_idx_list = has_sublist_idx(ex['tokens'], ['no', 'longer'])
        two_token_idx_list = no_longer_idx_list
        not_list = one_token_idx_list + two_token_idx_list
        if len(not_list) > 0:
            not_map = []   #[(ori_s, ori_e, new_s, new_d, same_word_or_not)]  ori: no longer,, new: not
            not_tokens = []
            ori_s = 0
            ori_e = 0
            new_s = 0
            new_e = 0
            skip = 0
            for idx in range(len(ex['tokens'])):
                if skip != 0:
                    skip -= 1
                    continue
                if idx not in not_list:
                    ori_e += 1
                    new_e += 1
                    not_tokens.append(ex['tokens'][idx])
                else:
                    not_map.append((ori_s, ori_e-1, new_s, new_e-1, True))
                    not_tokens.append("not")
                    # not word
                    if idx in one_token_idx_list:
                        not_map.append((ori_e, ori_e, new_e, new_e, False))
                        ori_s = ori_e+1
                        ori_e = ori_s
                        new_s = new_e+1
                        new_e = new_s
                    elif idx in two_token_idx_list:
                        skip = 1
                        not_map.append((ori_e, ori_e+1, new_e, new_e, False))
                        ori_s = ori_e+2
                        ori_e = ori_s
                        new_s = new_e+1
                        new_e = new_s
            not_map.append((ori_s, ori_e-1, new_s, new_e-1, True))
            not_sent = token2sentence(not_tokens)
            not_fea = self._analyze_example_with_corenlp(not_sent)
            new_dirs = []
            new_project = []
            for (o_1, o_2, n_1, n_2, same) in not_map:
                if same:
                    for i in range(n_1, n_2+1):
                        new_dirs.append(not_fea['polarity_dirs'][i])
                        new_project.append(not_fea['project_matrix'][i])
                else:
                    for i in range(o_1, o_2+1):
                        new_dirs.append(not_fea['polarity_dirs'][n_1])
                        new_project.append(not_fea['project_matrix'][n_1])
            ex['polarity_dirs'] = new_dirs
            ex['project_matrix'] = new_project

        # alien -> NN
        if "alien" in ex['tokens']:
            flag = False
            idx_list = has_sublist_idx(ex['tokens'], ['alien'])
            new_tokens = ex['tokens'].copy()
            for idx in idx_list:
                if idx+1 < len(ex['tokens']) and ex['pos'][idx+1][0:2] in ["VB", "PO", "IN"]:
                    new_tokens[idx] = 'foreigner'
                    flag = True
            if flag:
                new_fea = self._analyze_example_with_corenlp(token2sentence(new_tokens))
                ex['pos'] = new_fea['pos']
                ex['polarity_dirs'] = new_fea['polarity_dirs']
                ex['project_matrix'] = new_fea['project_matrix']
                ex['operators'] = new_fea['operators']

        # like -> vb
        if "like" in ex['tokens']:
            flag = False
            idx_list = has_sublist_idx(ex['tokens'], ['like'])
            new_tokens = ex['tokens'].copy()
            for idx in idx_list:
                if idx +1 >= len(ex['tokens']):
                    continue
                if idx+1 < len(ex['tokens']) and ex['pos'][idx+1][0:2] in ["TO"]:
                    new_tokens[idx] = 'love'
                    flag = True
                elif idx-1>0 and ex['pos'][idx+1][0:2] in ["NN"]:
                    new_tokens[idx] = 'love'
                    flag = True
            if flag:
                new_fea = self._analyze_example_with_corenlp(token2sentence(new_tokens))
                ex['pos'] = new_fea['pos']
                ex['polarity_dirs'] = new_fea['polarity_dirs']
                ex['project_matrix'] = new_fea['project_matrix']
                ex['operators'] = new_fea['operators']


        # CD
        # two man laugh in the park
        cd_list = get_cd(ex['pos'])
        if len(cd_list) > 0:
            for cd_idx in cd_list:
                if len(ex["operators"][cd_idx]) > 0:
                    nn_idx_list = range(ex["operators"][cd_idx]['sub_span_s'], ex["operators"][cd_idx]['sub_span_e'])
                else:
                    edge = [e for e in ex["basicDependencies"].edge if e.dep == "nummod"]
                    if len(edge) > 0:
                        nn_idx_list = [edge[0].source - 1]
                    else:
                        continue
                for nn_idx in nn_idx_list:
                    if ex['polarity_dirs'][cd_idx] != ex['polarity_dirs'][nn_idx]:
                        ex['polarity_dirs'][nn_idx] = ex['polarity_dirs'][cd_idx]
                        ex['project_matrix'][nn_idx] = swap_list_pos(ex['project_matrix'][nn_idx], 1, 2)

        # not -> all down e.g. Scientists haven't found a vaccine for carcinoma yet
        # it is not that a woman in red jacket do not put on makeup
        # no job and no play
        # not good currently
        neg_w = ['not', 'never', 'hardly', 'no', 'scarcely']
        flag = False
        if ex['polarity_dirs'][0] == self.map_project_dir['down'] and ex["lemma"][0] not in neg_w:
            ex['polarity_dirs'][0] = self.map_project_dir['up']
            ex['project_matrix'][0] = [0,1,2,3,4,5,6]
            if ex['pos'][0] != 'DT' and ex['tokens'][0] not in ['more', 'less']:
                flag = True
            if len(ex['pos']) > 1 and ex['tokens'][1] in ['most', 'least']:
                flag = False
        if flag:
            dir = 1
            s = 1
            not_num = 0
            for idx in range(1, len(ex["lemma"])):
                if ex["lemma"][idx] in neg_w:
                    not_num += 1
                    if dir == 1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['up']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,1,2,3,4,5,6]] * (idx + 1 - s)
                        s = idx + 1
                        dir = dir * (-1)
                    elif dir == -1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['down']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,2,1,4,6,4,6]] * (idx + 1 - s)
                        s = idx + 1
                        dir = dir * (-1)
                if ex["pos"][idx] == "CC":
                    if dir == 1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['up']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,1,2,3,4,5,6]] * (idx + 1 - s)
                        s = idx + 1
                    elif dir == -1:
                        ex['polarity_dirs'][s:idx+1] = [self.map_project_dir['down']] * (idx + 1 - s)
                        ex['project_matrix'][s:idx+1] = [[0,2,1,4,6,4,6]] * (idx + 1 - s)
                        s = idx + 1


                    dir_idx = find_cc_start(ex['parseTree'], idx)
                    if ex['polarity_dirs'][dir_idx] == self.map_project_dir['up']:
                        dir = 1
                    elif ex['polarity_dirs'][dir_idx] == self.map_project_dir['down']:
                        dir = -1
            if not_num > 1:
                if dir == 1:
                    ex['polarity_dirs'][s:len(ex["lemma"])] = [self.map_project_dir['up']] * (len(ex["lemma"]) - s)
                    ex['project_matrix'][s:len(ex["lemma"])] = [[0,1,2,3,4,5,6]] * (len(ex["lemma"]) - s)
                elif dir == -1:
                    ex['polarity_dirs'][s:len(ex["lemma"])] = [self.map_project_dir['down']] * (len(ex["lemma"]) - s)
                    ex['project_matrix'][s:len(ex["lemma"])] = [[0,2,1,4,6,4,6]] * (len(ex["lemma"]) - s)

        else:
            if "CC" in ex["pos"]:
                idx = ex["pos"].index("CC")
                dir_idx = find_cc_start(ex['parseTree'], idx)

                if ex['polarity_dirs'][dir_idx] == self.map_project_dir['up']:
                    new_fea = self._analyze_example_with_corenlp(token2sentence(ex["tokens"][idx+1:]))
                    ex['polarity_dirs'][idx+1:] = new_fea['polarity_dirs']
                    ex['project_matrix'][idx+1:] = new_fea['project_matrix']
                elif ex['polarity_dirs'][dir_idx] == self.map_project_dir['down']:
                    new_fea = self._analyze_example_with_corenlp(token2sentence(ex["tokens"][idx+1:]))
                    tmp_dir = list()
                    tmp_project = list()
                    for i in new_fea['polarity_dirs']:
                        if i == self.map_project_dir["up"]:
                            tmp_dir.append(self.map_project_dir["down"])
                            tmp_project.append([0,2,1,4,6,4,6])
                        elif i == self.map_project_dir["down"]:
                            tmp_dir.append(self.map_project_dir["up"])
                            tmp_project.append([0,1,2,3,4,5,6])
                        else:
                            tmp_dir.append(self.map_project_dir["flat"])
                            tmp_project.append([0,6,6,6,6,6,6])
                    ex['polarity_dirs'][idx+1:] = tmp_dir
                    ex['project_matrix'][idx+1:] = tmp_project

        return ex


    def _process_text(self, text):
        ex = self._analyze_example_with_corenlp(text)
        ex['text'] = text
        ex = self._correct_natlog_corenlp(ex)
        ex['natlog_relations'] = self._find_wordnet_relations(ex)
        return ex



    def _lm_score(self, sentence):
        with torch.no_grad():
            tensor_input = self.lm_tokenizer.encode(sentence, return_tensors='pt').to(self.lm_device)
            repeat_input = tensor_input.repeat(tensor_input.size(-1)-2, 1)
            mask = torch.ones(tensor_input.size(-1) - 1).diag(1)[:-2].to(self.lm_device)
            masked_input = repeat_input.masked_fill(mask == 1, self.lm_tokenizer.encode('[MASK]')[1])
            labels = repeat_input.masked_fill(masked_input != self.lm_tokenizer.encode('[MASK]')[1], -100)

            loss = self.lm_model(masked_input, labels=labels)['loss']
            result = np.exp(loss.item())
            return result

    def _lm_predict(self, sentence):
        with torch.no_grad():
            inputs = self.lm_tokenizer.encode(sentence, return_tensors='pt')
            idx = torch.where((inputs == self.lm_tokenizer.encode('[MASK]')[1])>0)[-1].numpy()[0]
            pred_logits = self.lm_model(inputs.to(self.lm_device))['logits'].detach().cpu().numpy()
            pred = np.argsort(pred_logits.squeeze()[idx])[::-1][:self.NUM_PER_STEP]
            return [s.replace(' ', '') for s in self.lm_tokenizer.batch_decode(pred.tolist())]


    def _lm_word_sim(self, s1, s2):
        with torch.no_grad():
            tensor1 = self.lm_tokenizer.encode(s1, return_tensors='pt').to(self.lm_device)
            tensor2 = self.lm_tokenizer.encode(s2, return_tensors='pt').to(self.lm_device)
            embed1 = self.lm_model(tensor1, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[1,:]
            embed2 = self.lm_model(tensor2, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[1,:]
            return torch.nn.functional.cosine_similarity(embed1, embed2, dim=0).detach().cpu()

    def _lm_sentence_sim(self, s1, s2):
        with torch.no_grad():
            tensor1 = self.lm_tokenizer.encode(s1, return_tensors='pt').to(self.lm_device)
            tensor2 = self.lm_tokenizer.encode(s2, return_tensors='pt').to(self.lm_device)
            embed1 = self.lm_model(tensor1, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[0,:]
            embed2 = self.lm_model(tensor2, output_hidden_states=True)['hidden_states'][-1].squeeze(0)[0,:]
            return torch.nn.functional.cosine_similarity(embed1, embed2, dim=0).detach().cpu()

    def _first_lower(self, t):
        s = [i for i in t]
        if len(s) > 0:
            s[0] = s[0].lower()
        return s

    def _is_word(self, t):
        if t[0].isalpha() or t[0].isdigit():
            return True
        else:
            return False
