import os

# paths
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
# PRETRAINED_DIR = os.path.join(BASE_DIR, 'pretrained')
CHECKPOINT_DIR = os.path.join(BASE_DIR, 'checkpoint')
CACHE_DIR = os.path.join(BASE_DIR, 'cache')
LOG_DIR = os.path.join(BASE_DIR, 'log')
TENSORBOARD_DIR = os.path.join(LOG_DIR, "tensorboard")
PLOT_DIR = os.path.join(BASE_DIR, 'plot')
BK_DIR = os.path.join(BASE_DIR, "backup")
# victim models/trained victim models
VICTIM_MODEL_DIR = CHECKPOINT_DIR

DATA_BASE_DIR = os.path.join(BASE_DIR, 'data')
DATASET_DIR = os.path.join(BASE_DIR, 'data', 'dataset')
ATTACK_SAMPLE_DIR = os.path.join(BASE_DIR, 'data', 'attack_sample')
OPENAI_DATA_DIR = os.path.join(BASE_DIR, 'data', 'openai')
# PREPROCESS_DATA = os.path.join(BASE_DIR, 'data', 'preprocess_data')
EMBED_DIR = os.path.join(BASE_DIR, 'data', 'embed')
WORDNET_DIR = os.path.join(BASE_DIR, 'data', 'wordnet')
TEST_EX_DIR = os.path.join(DATASET_DIR, 'test_examples')

# dataset dir path
SNLI_DIR = os.path.join(DATASET_DIR, 'snli_1.0')
MNLI_DIR = os.path.join(DATASET_DIR, 'multinli_1.0')
HELP_DIR = os.path.join(DATASET_DIR, 'help')
MED_DIR = os.path.join(DATASET_DIR, 'med')

# human evaluation
HUMAN_DIR = os.path.join(BASE_DIR, 'human_evaluation')

# mini dev dir path
MINI_SNLI_DIR = os.path.join(BASE_DIR, 'data', 'devset', 'snli_1.0_dev')

# pretrained models
# BERT_BASE_CASED_DIR = os.path.join(PRETRAINED_DIR, 'bert-base-cased')
# STANFORD_NLP_HOME = os.path.join(PRETRAINED_DIR, 'stanford_corenlp')
# STANFORD_CORENLP_HOME = os.path.join(PRETRAINED_DIR, 'stanford_corenlp', 'stanford-corenlp-full-2018-10-05')
STANFORD_CORENLP_HOME = os.path.join(BASE_DIR, 'stanford_corenlp', 'stanford-corenlp-full-2020-04-20')

